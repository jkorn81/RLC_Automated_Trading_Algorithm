#######################################################################################
#######################################################################################
#######################################################################################
dir = getwd()
setwd(dir)
#######################################################################################
#######################################################################################
#######################################################################################
######################################################################################## Trade Capture ----
trades_p <- list.files(path = "trades/.", recursive = TRUE, # import stored csv files in set output folder as a list
                       pattern = "\\.csv$", 
                       full.names = TRUE)
for(i in seq_along(length(trades_p))) {
  trades_csv = lapply(trades_p, read.csv, header=TRUE, sep=",")
}
for(i in seq_along(length(trades_csv))) { 
  ptrades = data.frame(rbindlist(trades_csv))
}
n_last <- 5                               
ext = substr(trades_p, nchar(trades_p) - n_last + 1, nchar(trades_p)) 
require(stringr)
require(data.table)
ext = str_remove(ext,".csv")
print(paste0(length(ext)," existing positions ",ext[1]))
assign("ext",ext, envir = globalenv())
