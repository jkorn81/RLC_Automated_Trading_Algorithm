#######################################################################################
#######################################################################################
#######################################################################################
dir = getwd()
setwd(dir)
#######################################################################################
#######################################################################################
#######################################################################################
#######################################################################################
# Trade Capture ----

if(pv_med_value$x == "low_potential"){
  profit_value = safenet_values$profit[1]*0.0001
  print("total take profit check run.")
  if(last(ext,1) == 1 & first(ext,1) == 1 & length(ext) >= 1 & profit_sum > profit_value){
    trade_m15 = 98
    assign("trade_m15",trade_m15, envir = globalenv())
    print(paste0("close string of buy/s bc safety net, capture profit."))
  } else if(last(ext,1) == 4 & first(ext,1) == 4 & length(ext) >= 1 & profit_sum > profit_value){
    trade_m15 = 99
    assign("trade_m15",trade_m15, envir = globalenv())
    print(paste0("close string of sell/s bc safety net, capture profit."))
  } 
}
if(pv_med_value$x == "medium_potential"){
  profit_value = safenet_values$profit[2]*0.0001
  print("total take profit check run.")
  if(last(ext,1) == 1 & first(ext,1) == 1 & length(ext) >= 1 & profit_sum > profit_value){
    trade_m15 = 98
    assign("trade_m15",trade_m15, envir = globalenv())
    print(paste0("close string of buy/s bc safety net, capture profit."))
  } else if(last(ext,1) == 4 & first(ext,1) == 4 & length(ext) >= 1 & profit_sum > profit_value){
    trade_m15 = 99
    assign("trade_m15",trade_m15, envir = globalenv())
    print(paste0("close string of sell/s bc safety net, capture profit."))
  } 
}
if(pv_med_value$x == "high_potential"){
  profit_value = safenet_values$profit[3]*0.0001
  print("total take profit check run.")
  if(last(ext,1) == 1 & first(ext,1) == 1 & length(ext) >= 1 & profit_sum > profit_value){
    trade_m15 = 98
    assign("trade_m15",trade_m15, envir = globalenv())
    print(paste0("close string of buy/s bc safety net, capture profit."))
  } else if(last(ext,1) == 4 & first(ext,1) == 4 & length(ext) >= 1 & profit_sum > profit_value){
    trade_m15 = 99
    assign("trade_m15",trade_m15, envir = globalenv())
    print(paste0("close string of sell/s bc safety net, capture profit."))
  } 
}