profit_sums_list <- list.files(path = "outputs/profit_sums/.", recursive = TRUE, 
                    pattern = "\\.csv$", 
                    full.names = TRUE)
for(i in seq_along(length(profit_sums_list))) {
  ps_csv= lapply(profit_sums_list, read.csv, header=TRUE, sep=",")
}
for(i in seq_along(length(ps_csv))) {  
  ps_df = data.frame(rbindlist(ps_csv))
}

original = read_delim("rl_agent_crowder/data/df_rates_p2.csv", escape_double = FALSE, 
                      trim_ws = TRUE, delim=",")
original = data.frame(original)
colnames(original) = c("Account","Balance","Position",'Date', 'Open', 'High', 'Low', 'Close')
balance = last(original$Account,1)
equity = last(original$Balance,1)
percent_change = round((equity-balance)/balance,2)

ps_df_pos_count = sum(ps_df$x>0)
ps_df_neg_count = sum(ps_df$x<0)
ps_df_mean = sign(mean(ps_df$x))
ps_df_sign = last(sign(ps_df$x),1)
mean = mean(ps_df$x)

print(paste0("profit_sums positive count is ", ps_df_pos_count))
print(paste0("profit_sums negative count is ", ps_df_neg_count))
print(paste0("profit_sums average sign is ", ps_df_mean))
print(paste0("the last profit sum sign is ", ps_df_sign))
print(paste0("the profit sums mean is ", mean))

if(length(ps_df$x)>=sample(4:24,1)){
  if(ps_df_pos_count < ps_df_neg_count & ps_df_mean == -1 & ps_df_sign == -1 & profit_sum <= -0.0020){
    if(last(ext,1) == 1){
      trade_m15 = 98
      print("close the buy/s, bc it seems the position will continue to run to a loss.")
    }
    if(last(ext,1) == 4){
      trade_m15 = 99
      print("close the sell/s, bc it seems the position will continue to run to a loss.")
    }
  }
}