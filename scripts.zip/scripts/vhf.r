#######################################################################################
#######################################################################################
#######################################################################################
dir = getwd()
setwd(dir)
#######################################################################################
#######################################################################################
#######################################################################################
#######################################################################################
data = read_delim("rl_agent_crowder/data/df_rates_p2.csv", escape_double = FALSE, 
                  trim_ws = TRUE, delim=",")
data = data.frame(data)
colnames(data) = c('Account', 'Balance', 'Position_Count','Date', 'Open', 'High', 'Low', 'Close')
vhf = na.omit(VHF(data$Close, n = 28))
vhfd = na.omit(sign(diff(vhf)))
vhfd = ifelse(vhfd>0,"trending", "sideways")
vhf_level = ifelse(vhf>mean(vhf), "strong_trend", "weak_trend")



vhfd = last(vhfd,1)
vhf_level = last(vhf_level,1)