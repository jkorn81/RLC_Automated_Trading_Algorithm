#######################################################################################
#######################################################################################
#######################################################################################
dir = getwd()
setwd(dir)
#######################################################################################
#######################################################################################
#######################################################################################
#######################################################################################
# - [-] - Import Data ----
original = read_delim("rl_agent_crowder/data/df_rates_p2.csv", escape_double = FALSE, 
                      trim_ws = TRUE, delim=",")
original = data.frame(original)
colnames(original) = c("Account","Balance","Position",'Date', 'Open', 'High', 'Low', 'Close')
lastdate = last(original[,-c(1:3,5:8)],1)
lastdate = toString(lastdate)
lastdate = gsub(" ", "", lastdate, fixed = TRUE)
lastdate = gsub(":", "", lastdate, fixed = TRUE)
assign("lastdate",lastdate, envir = globalenv())
