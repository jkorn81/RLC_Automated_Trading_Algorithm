library(tidyverse)
library(lubridate)

original = read_delim("rl_agent_crowder/data/df_rates_p2.csv", escape_double = FALSE, 
                      trim_ws = TRUE, delim=",")
original = data.frame(original)
colnames(original) = c("Account","Balance","Position",'Date', 'Open', 'High', 'Low', 'Close')

original$Date = ymd_hm(original$Date)
daily = original %>% group_by(date(Date)) %>% 
  summarise(
    Open = Open[1],
    High = max(High),
    Low = min(Low),
    Close = Close[length(Close)],
    Mean = (Close - Open)/2
  )

daily = daily %>% data.frame 
write.csv(daily,"rl_agent_crowder/outputs/daily.csv", row.names = FALSE)


detach("package:tidyverse", unload=TRUE)
