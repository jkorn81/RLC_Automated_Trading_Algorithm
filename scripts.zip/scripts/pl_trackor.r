write.csv(profit_sum,paste0("outputs/profit_sums/","ps", lastdate,".csv"), row.names = FALSE) 
profit_sums_list <- list.files(path = "outputs/profit_sums/.", recursive = TRUE,
                    pattern = "\\.csv$", 
                    full.names = TRUE)

original = read_delim("rl_agent_crowder/data/df_rates_p2.csv", escape_double = FALSE, 
                      trim_ws = TRUE, delim=",")
original = data.frame(original)
colnames(original) = c("Account","Balance","Position",'Date', 'Open', 'High', 'Low', 'Close')
balance = last(original$Account,1)
equity = last(original$Balance,1)
percent_change = round((equity-balance)/balance,6)

if(pv_med_value$x == 'low_potential'){
  if(sl >= 500.01){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 10
  } else if(between(sl, 487.51, 500)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 9.75
  } else if(between(sl, 475.01,487.5)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 9.5
  } else if(between(sl, 462.51,475)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 9.25
  } else if(between(sl, 450.01,462.5)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 9
  } else if(between(sl, 437.51,450)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 8.75
  } else if(between(sl, 425.01,437.5)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 8.5
  } else if(between(sl, 412.51,425)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 8.25
  } else if(between(sl, 400.01,412.5)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 8
  } else if(between(sl, 387.51, 400)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 7.75
  } else if(between(sl, 375.01,387.5)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 7.5
  } else if(between(sl, 362.51,375)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 7.25
  } else if(between(sl, 350.01,362.5)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 7
  } else if(between(sl, 337.51,350)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 6.75
  } else if(between(sl, 325.01,337.5)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 6.5
  } else if(between(sl, 312.51,325)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 6.25
  } else if(between(sl, 300.01,312.5)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 6
  } else if(between(sl, 287.51, 300)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 5.75
  } else if(between(sl, 275.01,287.5)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 5.5
  } else if(between(sl, 262.51,275)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 5.25
  } else if(between(sl, 250.01,262.5)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 5
  } else if(between(sl, 237.51,250)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 4.75
  } else if(between(sl, 225.01,237.5)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 4.5
  } else if(between(sl, 212.51,225)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 4.25
  } else if(between(sl, 200.01,212.5)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 4
  } else if(between(sl, 187.51, 200)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 3.75
  } else if(between(sl, 175.01,187.5)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 3.5
  } else if(between(sl, 162.51,175)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 3.25
  } else if(between(sl, 150.01,162.5)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 3
  } else if(between(sl, 137.51,150)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 2.75
  } else if(between(sl, 125.01,137.5)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 2.5
  } else if(between(sl, 112.51,125)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 2.25
  } else if(between(sl, 100.01,112.5)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 2
  } else if(between(sl, 87.51,100)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 1.75
  } else if(between(sl, 75.01,87.5)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 1.5
  } else if(between(sl, 62.51,75)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 1.25
  } else if(between(sl, 50.01,62.5)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 1
  } else if(between(sl, 37.51,50)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 1
  } else if(between(sl, 25.01,37.5)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 1
  } else if(between(sl, 12.51,25)){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 1
  } else if(sl <= 12.5){
    low_eq = (sl*0.0001)*10
    low_eq = low_eq / 1
  }
  eq_target = low_eq
}

if(pv_med_value$x == 'medium_potential'){
  if(sl >= 500.01){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 5
  } else if(between(sl, 487.51, 500)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 4.875
  } else if(between(sl, 475.01,487.5)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 4.75
  } else if(between(sl, 462.51,475)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 4.625
  } else if(between(sl, 450.01,462.5)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 4.5
  } else if(between(sl, 437.51,450)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 4.375
  } else if(between(sl, 425.01,437.5)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 4.25
  } else if(between(sl, 412.51,425)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 4.125
  } else if(between(sl, 400.01,412.5)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 4
  } else if(between(sl, 387.51, 400)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 3.875
  } else if(between(sl, 375.01,387.5)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 3.75
  } else if(between(sl, 362.51,375)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 3.625
  } else if(between(sl, 350.01,362.5)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 3.5
  } else if(between(sl, 337.51,350)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 3.375
  } else if(between(sl, 325.01,337.5)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 3.25
  } else if(between(sl, 312.51,325)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 3.125
  } else if(between(sl, 300.01,312.5)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 3
  } else if(between(sl, 287.51, 300)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 2.875
  } else if(between(sl, 275.01,287.5)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 2.75
  } else if(between(sl, 262.51,275)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 2.625
  } else if(between(sl, 250.01,262.5)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 2.5
  } else if(between(sl, 237.51,250)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 2.375
  } else if(between(sl, 225.01,237.5)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 2.25
  } else if(between(sl, 212.51,225)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 2.125
  } else if(between(sl, 200.01,212.5)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 2
  } else if(between(sl, 187.51, 200)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 1.875
  } else if(between(sl, 175.01,187.5)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 1.75
  } else if(between(sl, 162.51,175)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 1.625
  } else if(between(sl, 150.01,162.5)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 1.5
  } else if(between(sl, 137.51,150)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 1.375
  } else if(between(sl, 125.01,137.5)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 1.25
  } else if(between(sl, 112.51,125)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 1.125
  } else if(between(sl, 100.01,112.5)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 1
  } else if(between(sl, 87.51,100)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 1
  } else if(between(sl, 75.01,87.5)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 1
  } else if(between(sl, 62.51,75)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 1
  } else if(between(sl, 50.01,62.5)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 1
  } else if(between(sl, 37.51,50)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 1
  } else if(between(sl, 25.01,37.5)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 1
  } else if(between(sl, 12.51,25)){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 1
  } else if(sl <= 12.5){
    med_eq = (sl*0.0001)*10
    med_eq = med_eq / 1
  }
  eq_target = med_eq
}
if(pv_med_value$x == 'high_potential'){
  if(sl >= 500.01){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 2.5
  } else if(between(sl, 487.51, 500)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 2.4375
  } else if(between(sl, 475.01,487.5)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 2.375
  } else if(between(sl, 462.51,475)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 2.3125
  } else if(between(sl, 450.01,462.5)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 2.25
  } else if(between(sl, 437.51,450)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 2.1875
  } else if(between(sl, 425.01,437.5)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 2.125
  } else if(between(sl, 412.51,425)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 2.0625
  } else if(between(sl, 400.01,412.5)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 2
  } else if(between(sl, 387.51, 400)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 1.9375
  } else if(between(sl, 375.01,387.5)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 1.875
  } else if(between(sl, 362.51,375)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 1.8125
  } else if(between(sl, 350.01,362.5)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 1.75
  } else if(between(sl, 337.51,350)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 1.6875
  } else if(between(sl, 325.01,337.5)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 1.625
  } else if(between(sl, 312.51,325)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 1.5625
  } else if(between(sl, 300.01,312.5)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 1.5
  } else if(between(sl, 287.51, 300)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 1.4375
  } else if(between(sl, 275.01,287.5)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 1.375
  } else if(between(sl, 262.51,275)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 1.3125
  } else if(between(sl, 250.01,262.5)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 1.25
  } else if(between(sl, 237.51,250)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 1.1875
  } else if(between(sl, 225.01,237.5)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 1.125
  } else if(between(sl, 212.51,225)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 1.0625
  } else if(between(sl, 200.01,212.5)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 1
  } else if(between(sl, 187.51, 200)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 1
  } else if(between(sl, 175.01,187.5)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 1
  } else if(between(sl, 162.51,175)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 1
  } else if(between(sl, 150.01,162.5)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 1
  } else if(between(sl, 137.51,150)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 1
  } else if(between(sl, 125.01,137.5)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 1.25
  } else if(between(sl, 112.51,125)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 1.125
  } else if(between(sl, 100.01,112.5)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 1
  } else if(between(sl, 87.51,100)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 1
  } else if(between(sl, 75.01,87.5)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 1
  } else if(between(sl, 62.51,75)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 1
  } else if(between(sl, 50.01,62.5)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 1
  } else if(between(sl, 37.51,50)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 1
  } else if(between(sl, 25.01,37.5)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 1
  } else if(between(sl, 12.51,25)){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 1
  } else if(sl <= 12.5){
    high_eq = (sl*0.0001)*10
    high_eq = high_eq / 1
  }
  eq_target = high_eq
}

if(length(fixed_marker2)>=1){
  if(percent_change < eq_target){
    if(length(profit_sums_list)>=3){
      for(i in seq_along(length(profit_sums_list))) {
        csv= lapply(profit_sums_list, read.csv, header=TRUE, sep=",")
      }
      for(i in seq_along(length(csv))) {  
        profit_sums_data = data.frame(rbindlist(csv))
      }
      colnames(profit_sums_data) = c("profit_sums")
      #print(paste0("the profit sums are ", c(profit_sums_data$profit_sums)))
      moving_average_st <- function(a, n=3){
        ret <- cumsum(a)
        result <- c()
        if(length(a) >= n){
          ret[(n+1):length(a)] <- ret[(n+1):length(a)] - ret[1:(length(a) - n)]
          result <- ret[n:length(a)]/n
        }
        initial_elements <- c()
        initial_length <- min(n, length(a)) - 1
        for(i in 1:initial_length){
          elements <- i
          sum <- ret[i]
          mean <- sum/elements
          initial_elements <- c(initial_elements, mean)
        }
        result <- c(initial_elements, result)
      }
      
      moving_average_mt <- function(a, n=6){
        ret <- cumsum(a)
        result <- c()
        if(length(a) >= n){
          ret[(n+1):length(a)] <- ret[(n+1):length(a)] - ret[1:(length(a) - n)]
          result <- ret[n:length(a)]/n
        }
        initial_elements <- c()
        initial_length <- min(n, length(a)) - 1
        for(i in 1:initial_length){
          elements <- i
          sum <- ret[i]
          mean <- sum/elements
          initial_elements <- c(initial_elements, mean)
        }
        result <- c(initial_elements, result)
      }
      
      moving_average_lt <- function(a, n=14){
        ret <- cumsum(a)
        result <- c()
        if(length(a) >= n){
          ret[(n+1):length(a)] <- ret[(n+1):length(a)] - ret[1:(length(a) - n)]
          result <- ret[n:length(a)]/n
        }
        initial_elements <- c()
        initial_length <- min(n, length(a)) - 1
        for(i in 1:initial_length){
          elements <- i
          sum <- ret[i]
          mean <- sum/elements
          initial_elements <- c(initial_elements, mean)
        }
        result <- c(initial_elements, result)
      }
      
      if(between(length(profit_sums_data$profit_sums), 2, 6)){
        st_mvg = moving_average_st(profit_sums_data$profit_sums)
        st_data = last(st_mvg,2)
        st_p = st_data[1]
        st_c = st_data[2]
        st_diff = st_c - st_p
        if(st_diff > 0){
          st_profit_sum_track = "gain"
        } else if(st_diff < 0){
          st_profit_sum_track = "loss"
        }
        print(paste0("the short profit sum track is ", st_profit_sum_track))
      } else if(between(length(profit_sums_data$profit_sums), 5, 13)){
        st_mvg = moving_average_st(profit_sums_data$profit_sums)
        st_data = last(st_mvg,2)
        st_p = st_data[1]
        st_c = st_data[2]
        st_diff = st_c - st_p
        if(st_diff > 0){
          st_profit_sum_track = "gain"
        } else if(st_diff < 0){
          st_profit_sum_track = "loss"
        }
        print(paste0("the short profit sum track is ", st_profit_sum_track))
        mt_mvg = moving_average_mt(profit_sums_data$profit_sums)
        mt_data = last(mt_mvg,2)
        mt_p = mt_data[1]
        mt_c = mt_data[2]
        mt_diff = mt_c - mt_p
        if(mt_diff > 0){
          mt_profit_sum_track = "gain"
        } else if(mt_diff < 0){
          mt_profit_sum_track = "loss"
        }
        print(paste0("the medium profit sum track is ", mt_profit_sum_track))
        
        if(st_profit_sum_track == "loss" & mt_profit_sum_track == "loss"){
          if(last(ext,1) == 1){
            if(o_trade_m15 == 1 & correction == 1 & bar_signal == 1){
              print("do not close the buy, a new buy will open right away.")
            } else {
              trade_m15 = 98
              print("force close buy/s, the pl tracking is showing short and medium loss momentum.")
            }
          } else if(last(ext,1) == 4){
            if(o_trade_m15 == 4 & correction == -1 & bar_signal == -1){
              print("do not close the sell, a new sell will open right away.")
            } else {
              trade_m15 = 99
              print("force close sell/s, the pl tracking is showing short and medium loss momentum.")
            }
          }
        }
      } else if(length(profit_sums_data$profit_sums)>13){
        st_mvg = moving_average_st(profit_sums_data$profit_sums)
        st_data = last(st_mvg,2)
        st_p = st_data[1]
        st_c = st_data[2]
        st_diff = st_c - st_p
        if(st_diff > 0){
          st_profit_sum_track = "gain"
        } else if(st_diff < 0){
          st_profit_sum_track = "loss"
        }
        print(paste0("the short profit sum track is ", st_profit_sum_track))
        mt_mvg = moving_average_mt(profit_sums_data$profit_sums)
        mt_data = last(mt_mvg,2)
        mt_p = mt_data[1]
        mt_c = mt_data[2]
        mt_diff = mt_c - mt_p
        if(mt_diff > 0){
          mt_profit_sum_track = "gain"
        } else if(mt_diff < 0){
          mt_profit_sum_track = "loss"
        }
        print(paste0("the medium profit sum track is ", mt_profit_sum_track))
        lt_mvg = moving_average_lt(profit_sums_data$profit_sums)
        lt_data = last(lt_mvg,2)
        lt_p = lt_data[1]
        lt_c = lt_data[2]
        lt_diff = lt_c - lt_p
        if(lt_diff > 0){
          lt_profit_sum_track = "gain"
        } else if(mt_diff < 0){
          lt_profit_sum_track = "loss"
        }
        print(paste0("the long profit sum track is ", lt_profit_sum_track))
        
        if(st_profit_sum_track == "loss" & mt_profit_sum_track == "loss" & lt_profit_sum_track == "gain"){
          if(last(ext,1) == 1){
            if(o_trade_m15 == 1 & correction == 1 & bar_signal == 1){
              print("do not close the buy, a new buy will open right away.")
            } else {
              trade_m15 = 98
              print("force close buy/s, the pl tracking is showing short, medium, and long loss momentum.")
            }
          } else if(last(ext,1) == 4){
            if(o_trade_m15 == 4 & correction == -1 & bar_signal == -1){
              print("do not close the sell, a new sell will open right away.")
            } else {
              trade_m15 = 99
              print("force close sell/s, the pl tracking is showing short, medium, and long loss momentum.")
            }
          }
        } else if(st_profit_sum_track == "loss" & mt_profit_sum_track == "loss" & lt_profit_sum_track == "loss"){
          if(last(ext,1) == 1){
            if(o_trade_m15 == 1 & correction == 1 & bar_signal == 1){
              print("do not close the buy, a new buy will open right away.")
            } else {
              trade_m15 = 98
              print("force close buy/s, the pl tracking is showing short, medium, and long loss momentum.")
            }
          } else if(last(ext,1) == 4){
            if(o_trade_m15 == 4 & correction == -1 & bar_signal == -1){
              print("do not close the sell, a new sell will open right away.")
            } else {
              trade_m15 = 99
              print("force close sell/s, the pl tracking is showing short, medium, and long loss momentum.")
            }
          }
        }
      }
    }
  }
}