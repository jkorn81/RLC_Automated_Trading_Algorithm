#######################################################################################
#######################################################################################
#######################################################################################
dir = getwd()
setwd(dir)
#######################################################################################
#######################################################################################
#######################################################################################
#######################################################################################
p = pos_positive_count
n = pos_negative_count
total_pop = p+n 
if(p>n){
  p_pop_perc = round(p/total_pop,4)
  n_pop_perc = round(n/total_pop,4)
  pop_perc_dif = round(p_pop_perc - n_pop_perc,4)
  print(paste0("positive population greater by ", pop_perc_dif," percent than negative population."))
}
if(p<n){
  p_pop_perc = round(p/total_pop,4)
  n_pop_perc = round(n/total_pop,4)
  pop_perc_dif = round(n_pop_perc - p_pop_perc,4)
  print(paste0("negative population greater by ", pop_perc_dif," percent than positive population."))
}
if(p==n){
  pop_perc_dif = 0
  print(paste0("populations equal, 0 percent difference."))
}
pop_perc_dif_df = data.frame(pop_perc_dif)
write.csv(pop_perc_dif_df,paste0("outputs/pop_perc_dif/ppd", lastdate,".csv"), row.names = FALSE)


ppd_list <- list.files(path = "outputs/pop_perc_dif/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)

if(length(ppd_list)>=2){
  prev_ppd = first(ppd_list,1)
  prev_ppd = read_csv(prev_ppd)
  assign("prev_ppd",prev_ppd$pop_perc_dif, envir = globalenv())
  last_ppd = last(ppd_list,1)
  last_ppd = read_csv(last_ppd)
  assign("current_ppd",last_ppd$pop_perc_dif, envir = globalenv())
} else if(length(ppd_list) <= 1){
  prev_ppd = first(ppd_list,1)
  prev_ppd = read_csv(prev_ppd)
  assign("prev_ppd",prev_ppd$pop_perc_dif, envir = globalenv())
  last_ppd = last(ppd_list,1)
  last_ppd = read_csv(last_ppd)
  assign("current_ppd",last_ppd$pop_perc_dif, envir = globalenv())
}


if(length(ppd_list)>=2){
  unlink(first(ppd_list,1))
}