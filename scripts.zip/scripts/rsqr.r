#######################################################################################
#######################################################################################
#######################################################################################
dir = getwd()
setwd(dir)
#######################################################################################
#######################################################################################
#######################################################################################
#######################################################################################
original = read_delim("rl_agent_crowder/data/df_rates_p2.csv", escape_double = FALSE, 
                      trim_ws = TRUE, delim=",")
original = data.frame(original)
colnames(original) = c('Account', 'Balance', 'Position_Count','Date', 'Open', 'High', 'Low', 'Close')
sub = data.frame(original[,-c(1:4)])
# - Entire Hist 
n = c(1:length(sub$Close))
lm = lm(Close ~ n, data = sub)
rsqr  = c(summary(lm)$r.squared) #model summary report...
# - Median of All Hists R^2 
days5 = c(seq(from = 96*5, to = length(sub$Close), by = 96*5))
days4 = c(seq(from = 96*4, to = length(sub$Close), by = 96*4))
days3 = c(seq(from = 96*3, to = length(sub$Close), by = 96*3))
days2 = c(seq(from = 96*2, to = length(sub$Close), by = 96*2))
days = c(seq(from = 96, to = length(sub$Close), by = 96))
half = c(seq(from = 48, to = length(sub$Close), by = 48))
quart = c(seq(from = 24, to = length(sub$Close), by = 24))
hours = c(seq(from = 12, to = length(sub$Close), by = 12))
mints = c(seq(from = 6, to = length(sub$Close), by = 6))
wins = unique(c(days,days2,days3,days4,days5,half,quart,hours,mints))
wins = sort(wins, decreasing = TRUE)
ind = createDataPartition(wins,p=0.9)
wins = wins[ind$Resample1]
for(i in c(wins)) {
  sub2 = last(sub,i)
  n = c(1:length(sub2$Close))
  lm = lm(Close ~ n, data = sub2)
  rsqr = round(c(rsqr,c(summary(lm)$r.squared)),3)
}
rsqr = rsqr[!rsqr %in% 0]
rsqr.med = round(median(rsqr),2)
rsqr.mean = round(mean(rsqr),2)
rule = abs(rsqr.mean - rsqr.med/rsqr.mean)
n = length(rsqr)
ci = mean(rsqr)+qt(0.90, df = n-1)*sd(rsqr)*sqrt(1/n)
if(rule<ci){
  write.csv(rsqr.med,"outputs/rsqr/rsqr.csv", row.names = FALSE)
} else if(rule>ci) {
  write.csv(rsqr.mean,"outputs/rsqr/rsqr.csv", row.names = FALSE)
}