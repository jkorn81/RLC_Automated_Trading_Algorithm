#######################################################################################
#######################################################################################
#######################################################################################
dir = getwd()
setwd(dir)
#######################################################################################
#######################################################################################
#######################################################################################
#######################################################################################
write.csv(bb_low,paste0("outputs/prev_bb_low/bb_low", lastdate,".csv"), row.names = FALSE)


c_bb_list <- list.files(path = "outputs/prev_bb_low/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)

if(length(c_bb_list)>=2){
  prev_c_bb = first(c_bb_list,1)
  prev_c_bb = read_csv(prev_c_bb)
  assign("prev_bb_low",prev_c_bb$x, envir = globalenv())
} else if(length(c_bb_list)<= 1){
  prev_c_bb = first(c_bb_list,1)
  prev_c_bb = read_csv(prev_c_bb)
  assign("prev_bb_low",prev_c_bb$x, envir = globalenv())
}

if(length(c_bb_list)>=2){
  unlink(first(c_bb_list,1))
}