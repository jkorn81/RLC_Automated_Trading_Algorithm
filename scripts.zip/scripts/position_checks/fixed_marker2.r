#######################################################################################
#######################################################################################
#######################################################################################
dir = getwd()
setwd(dir)
#######################################################################################
#######################################################################################
#######################################################################################
target = (marker_values_t1_t3$reverse[1]*0.0001)
num_trades = marker_values_t1_t3$num_trades[1]
if(length(trades)>=num_trades & length(marker)==0){
  print("positional placement check run with 1 position. fixed marker2.")
  if(last(ext,1) == 1){ 
    p_pip_dif = profit_sum
    if(p_pip_dif <= target){
      source("scripts/marker_save/marker_fixed2.r")
    }
  }
  if(last(ext,1) == 4){ 
    p_pip_dif = profit_sum
    if(p_pip_dif <= target){
      source("scripts/marker_save/marker_fixed2.r")
    }
  }
}
