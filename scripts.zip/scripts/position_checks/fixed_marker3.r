#######################################################################################
#######################################################################################
#######################################################################################
dir = getwd()
setwd(dir)
#######################################################################################
#######################################################################################
#######################################################################################
target = -0.0050
reverse = -0.00625
num_trades = marker_values_t1_t3$num_trades[1]
if(length(trades)>=num_trades & length(marker)==0){
  print("positional placement check run with 1 position. fixed marker3.")
  if(last(ext,1) == 1){ 
    p_pip_dif = profit_sum
    if(p_pip_dif <= target){
      source("scripts/marker_save/marker_fixed3.r")
    }
  }
  if(last(ext,1) == 4){ 
    p_pip_dif = profit_sum
    if(p_pip_dif <= target){
      source("scripts/marker_save/marker_fixed3.r")
    }
  }
}
#######################################################################################
#######################################################################################
#######################################################################################
if(length(trades)>=num_trades & 
   length(fixed_marker)==1 & 
   length(fixed_marker2)==1 & 
   length(fixed_marker3)==1){
  print("positional placement check run with 1 position. fixed marker closure 3.")
  if(last(ext,1) == 1){ 
    p_pip_dif = profit_sum
    if(p_pip_dif <= reverse){
      trade_m15 = 98
      print("close buy, the price is falling after hitting fixed marker3.")
    }
  }
  if(last(ext,1) == 4){ 
    p_pip_dif = profit_sum
    if(p_pip_dif <= reverse){
      trade_m15 = 99
      print("close buy, the price is falling after hitting fixed marker3.")
    }
  }
}
#######################################################################################
#######################################################################################
#######################################################################################