#######################################################################################
#######################################################################################
#######################################################################################
dir = getwd()
setwd(dir)
trades <- list.files(path = "trades/.", recursive = TRUE, 
                     pattern = "\\.csv$", 
                     full.names = TRUE)
trade_types <- list.files(path = "outputs/trade_type/.", recursive = TRUE, 
                     pattern = "\\.csv$", 
                     full.names = TRUE)
trade_status <- list.files(path = "outputs/trade_status/.", recursive = TRUE, 
                           pattern = "\\.csv$", 
                           full.names = TRUE)
pvmv <- list.files(path = "outputs/pv_med_value/.", recursive = TRUE, 
                           pattern = "\\.csv$", 
                           full.names = TRUE)
fixed_marker <- list.files(path = "outputs/fixed_marker/fm_1/.", recursive = TRUE, 
                   pattern = "\\.csv$", 
                   full.names = TRUE)
fixed_marker2 <- list.files(path = "outputs/fixed_marker/fm_2/.", recursive = TRUE, 
                           pattern = "\\.csv$", 
                           full.names = TRUE)
profit_sums_list <- list.files(path = "outputs/profit_sums/.", recursive = TRUE, 
                   pattern = "\\.csv$", 
                   full.names = TRUE)
marker <- list.files(path = "outputs/single_marker/m1/.", recursive = TRUE, 
                     pattern = "\\.csv$", 
                     full.names = TRUE)
marker2 <- list.files(path = "outputs/single_marker/m2/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker3 <- list.files(path = "outputs/single_marker/m3/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker4 <- list.files(path = "outputs/single_marker/m4/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker5 <- list.files(path = "outputs/single_marker/m5/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker6 <- list.files(path = "outputs/single_marker/m6/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker7 <- list.files(path = "outputs/single_marker/m7/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker8 <- list.files(path = "outputs/single_marker/m8/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker9 <- list.files(path = "outputs/single_marker/m9/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker10 <- list.files(path = "outputs/single_marker/m10/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker11 <- list.files(path = "outputs/single_marker/m11/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker12 <- list.files(path = "outputs/single_marker/m12/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker13 <- list.files(path = "outputs/single_marker/m13/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker14 <- list.files(path = "outputs/single_marker/m14/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker15 <- list.files(path = "outputs/single_marker/m15/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker16 <- list.files(path = "outputs/single_marker/m16/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker17 <- list.files(path = "outputs/single_marker/m17/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker18 <- list.files(path = "outputs/single_marker/m18/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker19 <- list.files(path = "outputs/single_marker/m19/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker20 <- list.files(path = "outputs/single_marker/m20/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker21 <- list.files(path = "outputs/single_marker/m21/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker22 <- list.files(path = "outputs/single_marker/m22/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker23 <- list.files(path = "outputs/single_marker/m23/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker24 <- list.files(path = "outputs/single_marker/m24/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker25 <- list.files(path = "outputs/single_marker/m25/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker26 <- list.files(path = "outputs/single_marker/m26/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker27 <- list.files(path = "outputs/single_marker/m27/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker28 <- list.files(path = "outputs/single_marker/m28/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker29 <- list.files(path = "outputs/single_marker/m29/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker30 <- list.files(path = "outputs/single_marker/m30/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker31 <- list.files(path = "outputs/single_marker/m31/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker32 <- list.files(path = "outputs/single_marker/m32/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker33 <- list.files(path = "outputs/single_marker/m33/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker34 <- list.files(path = "outputs/single_marker/m34/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker35 <- list.files(path = "outputs/single_marker/m35/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker36 <- list.files(path = "outputs/single_marker/m36/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker37 <- list.files(path = "outputs/single_marker/m37/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker38 <- list.files(path = "outputs/single_marker/m38/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker39 <- list.files(path = "outputs/single_marker/m39/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker40 <- list.files(path = "outputs/single_marker/m40/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker41 <- list.files(path = "outputs/single_marker/m41/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker42 <- list.files(path = "outputs/single_marker/m42/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker43 <- list.files(path = "outputs/single_marker/m43/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker44 <- list.files(path = "outputs/single_marker/m44/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker45 <- list.files(path = "outputs/single_marker/m45/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker46 <- list.files(path = "outputs/single_marker/m46/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker47 <- list.files(path = "outputs/single_marker/m47/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker48 <- list.files(path = "outputs/single_marker/m48/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker49 <- list.files(path = "outputs/single_marker/m49/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker50 <- list.files(path = "outputs/single_marker/m50/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker51 <- list.files(path = "outputs/single_marker/m51/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker52 <- list.files(path = "outputs/single_marker/m52/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker53 <- list.files(path = "outputs/single_marker/m53/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker54 <- list.files(path = "outputs/single_marker/m54/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker55 <- list.files(path = "outputs/single_marker/m55/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker56 <- list.files(path = "outputs/single_marker/m56/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker57 <- list.files(path = "outputs/single_marker/m57/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker58 <- list.files(path = "outputs/single_marker/m58/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker59 <- list.files(path = "outputs/single_marker/m59/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker60 <- list.files(path = "outputs/single_marker/m60/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker61 <- list.files(path = "outputs/single_marker/m61/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker62 <- list.files(path = "outputs/single_marker/m62/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker63 <- list.files(path = "outputs/single_marker/m63/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker64 <- list.files(path = "outputs/single_marker/m64/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker65 <- list.files(path = "outputs/single_marker/m65/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker66 <- list.files(path = "outputs/single_marker/m66/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker67 <- list.files(path = "outputs/single_marker/m67/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker68 <- list.files(path = "outputs/single_marker/m68/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker69 <- list.files(path = "outputs/single_marker/m69/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker70 <- list.files(path = "outputs/single_marker/m70/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker71 <- list.files(path = "outputs/single_marker/m71/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker72 <- list.files(path = "outputs/single_marker/m72/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker73 <- list.files(path = "outputs/single_marker/m73/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker74 <- list.files(path = "outputs/single_marker/m74/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker75 <- list.files(path = "outputs/single_marker/m75/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker76 <- list.files(path = "outputs/single_marker/m76/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker77 <- list.files(path = "outputs/single_marker/m77/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker78 <- list.files(path = "outputs/single_marker/m78/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker79 <- list.files(path = "outputs/single_marker/m79/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
marker80 <- list.files(path = "outputs/single_marker/m80/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)
