#######################################################################################
#######################################################################################
#######################################################################################
dir = getwd()
setwd(dir)
#######################################################################################
#######################################################################################
#######################################################################################
target = marker_values_t6_t8$target[7]*0.0001
reverse = marker_values_t6_t8$reverse[7]*0.0001
num_trades = marker_values_t6_t8$num_trades[1]
if(length(trades)>=num_trades & length(marker7)==0){
  print("positional placement check run with 1 position. marker 7.")
  if(last(ext,1) == 1){ 
    p_pip_dif = profit_sum
    if(p_pip_dif >= target){
      source("scripts/marker_save/marker7.r")
    }
  }
  if(last(ext,1) == 4){ 
    p_pip_dif = profit_sum
    if(p_pip_dif >= target){
      source("scripts/marker_save/marker7.r")
    }
  }
}
#######################################################################################
#######################################################################################
#######################################################################################
if(length(trades)>=num_trades & 
   length(marker)==1 & 
   length(marker2)==1 &
   length(marker3)==1 &
   length(marker4)==1 &
   length(marker5)==1 &
   length(marker6)==1 &
   length(marker7)==1 &
   length(marker8)==0 &
   length(marker9)==0 &
   length(marker10)==0 &
   length(marker11)==0 &
   length(marker12)==0 &
   length(marker13)==0 &
   length(marker14)==0 &
   length(marker15)==0 &
   length(marker16)==0 &
   length(marker17)==0 &
   length(marker18)==0 &
   length(marker19)==0 &
   length(marker20)==0 &
   length(marker21)==0 &
   length(marker22)==0 &
   length(marker23)==0 &
   length(marker24)==0 &
   length(marker25)==0 &
   length(marker26)==0 &
   length(marker27)==0 &
   length(marker28)==0 &
   length(marker29)==0 &
   length(marker30)==0 &
   length(marker31)==0 &
   length(marker32)==0 &
   length(marker33)==0 &
   length(marker34)==0 &
   length(marker35)==0 &
   length(marker36)==0 &
   length(marker37)==0 &
   length(marker38)==0 &
   length(marker39)==0 &
   length(marker40)==0 &
   length(marker41)==0 &
   length(marker42)==0 &
   length(marker43)==0 &
   length(marker44)==0 &
   length(marker45)==0 &
   length(marker46)==0 &
   length(marker47)==0 &
   length(marker48)==0 &
   length(marker49)==0 &
   length(marker50)==0 &
   length(marker51)==0 &
   length(marker52)==0 &
   length(marker53)==0 &
   length(marker54)==0 &
   length(marker55)==0 &
   length(marker56)==0 &
   length(marker57)==0 &
   length(marker58)==0 &
   length(marker59)==0 &
   length(marker60)==0 &
   length(marker61)==0 &
   length(marker62)==0 &
   length(marker63)==0 &
   length(marker64)==0 &
   length(marker65)==0 &
   length(marker66)==0 &
   length(marker67)==0 &
   length(marker68)==0 &
   length(marker69)==0 &
   length(marker70)==0 &
   length(marker71)==0 &
   length(marker72)==0 &
   length(marker73)==0 &
   length(marker74)==0 &
   length(marker75)==0 &
   length(marker76)==0 &
   length(marker77)==0 &
   length(marker78)==0 &
   length(marker79)==0 &
   length(marker80)==0){
  print("positional placement check run with 1 position. marker7 closure.")
  if(last(ext,1) == 1){ 
    p_pip_dif = profit_sum
    if(p_pip_dif <= reverse){
      trade_m15 = 98
      print("close buy, the price is falling after hitting marker 7.")
    }
  }
  if(last(ext,1) == 4){ 
    p_pip_dif = profit_sum
    if(p_pip_dif <= reverse){
      trade_m15 = 99
      print("close buy, the price is falling after hitting marker 7.")
    }
  }
}