#######################################################################################
#######################################################################################
#######################################################################################
dir = getwd()
setwd(dir)
#######################################################################################
#######################################################################################
#######################################################################################
target = ((sl/factor_num)*0.0001)*-1
target = target*2
rev_value = 0.75
reverse = ((sl * 0.0001)*rev_value)*-1
reverse = reverse
num_trades = marker_values_t1_t3$num_trades[1]
if(length(trades)>=num_trades & length(marker)==0){
  print("positional placement check run with 1 position. fixed marker5.")
  if(last(ext,1) == 1){ 
    p_pip_dif = profit_sum
    if(p_pip_dif <= target){
      source("scripts/marker_save/marker_fixed5.r")
    }
  }
  if(last(ext,1) == 4){ 
    p_pip_dif = profit_sum
    if(p_pip_dif <= target){
      source("scripts/marker_save/marker_fixed5.r")
    }
  }
}
#######################################################################################
#######################################################################################
#######################################################################################
if(length(trades)>=num_trades & 
   length(fixed_marker4)==1 & 
   length(fixed_marker5)==1 & 
   length(fixed_marker6)==0 & 
   length(fixed_marker7)==0 & 
   length(fixed_marker8)==0 & 
   length(fixed_marker9)==0 & 
   length(fixed_marker10)==0 & 
   length(fixed_marker11)==0 & 
   length(fixed_marker12)==0){
  print("positional placement check run with 1 position. fixed marker closure 5.")
  if(last(ext,1) == 1){ 
    p_pip_dif = profit_sum
    if(p_pip_dif <= reverse){
      trade_m15 = 98
      print("close buy, the price is falling after hitting fixed marker5.")
    }
  }
  if(last(ext,1) == 4){ 
    p_pip_dif = profit_sum
    if(p_pip_dif <= reverse){
      trade_m15 = 99
      print("close buy, the price is falling after hitting fixed marker5.")
    }
  }
}
#######################################################################################
#######################################################################################
#######################################################################################