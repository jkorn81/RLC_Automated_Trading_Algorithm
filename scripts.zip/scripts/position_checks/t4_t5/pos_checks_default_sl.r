#######################################################################################
#######################################################################################
#######################################################################################
dir = getwd()
setwd(dir)
#######################################################################################
#######################################################################################
#######################################################################################
default_value = marker_values_t4_t5$default[1]*0.0001
num_trades = marker_values_t4_t5$num_trades[1]
if(length(trades)>=num_trades){
  print("positional placement check run with 1 position. default stoploss.")
  if(last(ext,1) == 1){ 
    p_pip_dif = profit_sum
    if(p_pip_dif <= default_value){# Equalize to Positive State Population ----
      trade_m15 = 98
      print("price meet sl with 1 position open, close buy.")
    }
  }
  if(last(ext,1) == 4){ 
    p_pip_dif = profit_sum
    if(p_pip_dif <= default_value){#Equalize to Negative State Population ----
      trade_m15 = 99
      print("price meet sl with 1 position open, close sell.")
    }
  }
  
}
#######################################################################################
#######################################################################################
#######################################################################################