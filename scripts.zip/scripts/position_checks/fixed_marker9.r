#######################################################################################
#######################################################################################
#######################################################################################
dir = getwd()
setwd(dir)
#######################################################################################
#######################################################################################
#######################################################################################
target = -0.0075
reverse = -0.0050
num_trades = marker_values_t1_t3$num_trades[1]
if(length(trades)>=num_trades & length(marker)==0){
  print("positional placement check run with 1 position. fixed marker9.")
  if(last(ext,1) == 1){ 
    p_pip_dif = profit_sum
    if(p_pip_dif >= target){
      source("scripts/marker_save/marker_fixed9.r")
    }
  }
  if(last(ext,1) == 4){ 
    p_pip_dif = profit_sum
    if(p_pip_dif >= target){
      source("scripts/marker_save/marker_fixed9.r")
    }
  }
}
#######################################################################################
#######################################################################################
#######################################################################################
if(length(trades)>=num_trades &
   length(fixed_marker4)==1 & 
   length(fixed_marker5)==1 & 
   length(fixed_marker6)==1 & 
   length(fixed_marker7)==1 & 
   length(fixed_marker8)==1 & 
   length(fixed_marker9)==1 & 
   length(fixed_marker10)==0 & 
   length(fixed_marker11)==0 & 
   length(fixed_marker12)==0){
  print("positional placement check run with 1 position. fixed marker closure 9.")
  if(last(ext,1) == 1){ 
    p_pip_dif = profit_sum
    if(p_pip_dif <= reverse){
      trade_m15 = 98
      print("close buy, the price is falling after hitting fixed marker9.")
    }
  }
  if(last(ext,1) == 4){ 
    p_pip_dif = profit_sum
    if(p_pip_dif <= reverse){
      trade_m15 = 99
      print("close buy, the price is falling after hitting fixed marker9.")
    }
  }
}
#######################################################################################
#######################################################################################
#######################################################################################