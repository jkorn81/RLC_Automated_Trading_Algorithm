sl = sl
print(paste0("the sl setting is ", sl))
#######################################################################################
#######################################################################################
#######################################################################################
#######################################################################################
path = "scripts/position_checks/marker_values.xlsx"
trade_sl = as.numeric(sl) * -1
.wb <- openxlsx::loadWorkbook(path)
openxlsx::writeData(
  wb = .wb,
  sheet = 1,
  x = trade_sl,
  xy = c(5,2)
)
openxlsx::saveWorkbook(
  .wb,
  path,
  overwrite = TRUE
)
.wb <- openxlsx::loadWorkbook(path)
openxlsx::writeData(
  wb = .wb,
  sheet = 2,
  x = trade_sl,
  xy = c(5,2)
)
openxlsx::saveWorkbook(
  .wb,
  path,
  overwrite = TRUE
)
.wb <- openxlsx::loadWorkbook(path)
openxlsx::writeData(
  wb = .wb,
  sheet = 3,
  x = trade_sl,
  xy = c(5,2)
)
openxlsx::saveWorkbook(
  .wb,
  path,
  overwrite = TRUE
)
#######################################################################################
#######################################################################################
#######################################################################################
#######################################################################################
path = "scripts/position_checks/marker_values2.xlsx"
trade_sl = as.numeric(sl) * -1
.wb <- openxlsx::loadWorkbook(path)
openxlsx::writeData(
  wb = .wb,
  sheet = 1,
  x = trade_sl,
  xy = c(5,2)
)
openxlsx::saveWorkbook(
  .wb,
  path,
  overwrite = TRUE
)
.wb <- openxlsx::loadWorkbook(path)
openxlsx::writeData(
  wb = .wb,
  sheet = 2,
  x = trade_sl,
  xy = c(5,2)
)
openxlsx::saveWorkbook(
  .wb,
  path,
  overwrite = TRUE
)
.wb <- openxlsx::loadWorkbook(path)
openxlsx::writeData(
  wb = .wb,
  sheet = 3,
  x = trade_sl,
  xy = c(5,2)
)
openxlsx::saveWorkbook(
  .wb,
  path,
  overwrite = TRUE
)
#######################################################################################
#######################################################################################
#######################################################################################
#######################################################################################
path = "scripts/position_checks/marker_values3.xlsx"
trade_sl = as.numeric(sl) * -1
.wb <- openxlsx::loadWorkbook(path)
openxlsx::writeData(
  wb = .wb,
  sheet = 1,
  x = trade_sl,
  xy = c(5,2)
)
openxlsx::saveWorkbook(
  .wb,
  path,
  overwrite = TRUE
)
.wb <- openxlsx::loadWorkbook(path)
openxlsx::writeData(
  wb = .wb,
  sheet = 2,
  x = trade_sl,
  xy = c(5,2)
)
openxlsx::saveWorkbook(
  .wb,
  path,
  overwrite = TRUE
)
.wb <- openxlsx::loadWorkbook(path)
openxlsx::writeData(
  wb = .wb,
  sheet = 3,
  x = trade_sl,
  xy = c(5,2)
)
openxlsx::saveWorkbook(
  .wb,
  path,
  overwrite = TRUE
)


print(paste0("the sl factor value is ", factor_num))
marker_one = sl/factor_num
print(paste0("the first marker value is ", marker_one))
reverse_marker_one = marker_one/2
print(paste0("the first reverse marker value is ", reverse_marker_one))
path = "scripts/position_checks/marker_values.xlsx"
factor_num = factor_num 
.wb <- openxlsx::loadWorkbook(path)
openxlsx::writeData(
  wb = .wb,
  sheet = 1,
  x = factor_num,
  xy = c(6,2)
)
openxlsx::saveWorkbook(
  .wb,
  path,
  overwrite = TRUE
)
.wb <- openxlsx::loadWorkbook(path)
openxlsx::writeData(
  wb = .wb,
  sheet = 2,
  x = factor_num,
  xy = c(6,2)
)
openxlsx::saveWorkbook(
  .wb,
  path,
  overwrite = TRUE
)
.wb <- openxlsx::loadWorkbook(path)
openxlsx::writeData(
  wb = .wb,
  sheet = 3,
  x = factor_num,
  xy = c(6,2)
)
openxlsx::saveWorkbook(
  .wb,
  path,
  overwrite = TRUE
)
path = "scripts/position_checks/marker_values2.xlsx"
factor_num = factor_num
.wb <- openxlsx::loadWorkbook(path)
openxlsx::writeData(
  wb = .wb,
  sheet = 1,
  x = factor_num,
  xy = c(6,2)
)
openxlsx::saveWorkbook(
  .wb,
  path,
  overwrite = TRUE
)
.wb <- openxlsx::loadWorkbook(path)
openxlsx::writeData(
  wb = .wb,
  sheet = 2,
  x = factor_num,
  xy = c(6,2)
)
openxlsx::saveWorkbook(
  .wb,
  path,
  overwrite = TRUE
)
.wb <- openxlsx::loadWorkbook(path)
openxlsx::writeData(
  wb = .wb,
  sheet = 3,
  x = factor_num,
  xy = c(6,2)
)
openxlsx::saveWorkbook(
  .wb,
  path,
  overwrite = TRUE
)
path = "scripts/position_checks/marker_values3.xlsx"
factor_num = factor_num
.wb <- openxlsx::loadWorkbook(path)
openxlsx::writeData(
  wb = .wb,
  sheet = 1,
  x = factor_num,
  xy = c(6,2)
)
openxlsx::saveWorkbook(
  .wb,
  path,
  overwrite = TRUE
)
.wb <- openxlsx::loadWorkbook(path)
openxlsx::writeData(
  wb = .wb,
  sheet = 2,
  x = factor_num,
  xy = c(6,2)
)
openxlsx::saveWorkbook(
  .wb,
  path,
  overwrite = TRUE
)
.wb <- openxlsx::loadWorkbook(path)
openxlsx::writeData(
  wb = .wb,
  sheet = 3,
  x = factor_num,
  xy = c(6,2)
)
openxlsx::saveWorkbook(
  .wb,
  path,
  overwrite = TRUE
)
