#######################################################################################
#######################################################################################
#######################################################################################
dir = getwd()
setwd(dir)
#######################################################################################
#######################################################################################
#######################################################################################
if(length(trades) >= 1){
  if(pv_med_value$x == "high_potential"){
    marker_values_t1_t3 <- read_excel("scripts/position_checks/marker_values.xlsx", 
                                      sheet = "t1_t3")
    marker_values_t4_t5 <- read_excel("scripts/position_checks/marker_values.xlsx", 
                                      sheet = "t4_t5")
    marker_values_t6_t8 <- read_excel("scripts/position_checks/marker_values.xlsx", 
                                      sheet = "t6_t8")
  }
  if(pv_med_value$x == "medium_potential"){
    marker_values_t1_t3 <- read_excel("scripts/position_checks/marker_values2.xlsx", 
                                      sheet = "t1_t3")
    marker_values_t4_t5 <- read_excel("scripts/position_checks/marker_values2.xlsx", 
                                      sheet = "t4_t5")
    marker_values_t6_t8 <- read_excel("scripts/position_checks/marker_values2.xlsx", 
                                      sheet = "t6_t8")
  }
  if(pv_med_value$x == "low_potential"){
    marker_values_t1_t3 <- read_excel("scripts/position_checks/marker_values3.xlsx", 
                                      sheet = "t1_t3")
    marker_values_t4_t5 <- read_excel("scripts/position_checks/marker_values3.xlsx", 
                                      sheet = "t4_t5")
    marker_values_t6_t8 <- read_excel("scripts/position_checks/marker_values3.xlsx", 
                                      sheet = "t6_t8")
  }
}
