#######################################################################################
#######################################################################################
#######################################################################################
dir = getwd()
setwd(dir)
#######################################################################################
#######################################################################################
#######################################################################################
#######################################################################################
data = read_delim("rl_agent_crowder/data/df_rates_p2.csv", escape_double = FALSE, 
                     trim_ws = TRUE, delim=",")
data = data.frame(data)
colnames(data) = c('Account', 'Balance', 'Position_Count','Date', 'Open', 'High', 'Low', 'Close')
channel = data[,-c(1:5)]
bb = lag(BBands( channel[,c("High","Low","Close")] ))
bb_low = last(bb[,1],1)
bb_high = last(bb[,3],1)
bb_mid = last(bb[,2],1)

sidewaysA = bb_high - bb_low
sidewaysB = round((sidewaysA/bb_high)*100,2)
# if this comes back less than or equal to 0.0020 the market is sideways

bb_2 = lag(BBands( channel[,c("High","Low","Close")], sd = 1 ))
bb_2_low = last(bb_2[,1],1)
bb_2_high = last(bb_2[,3],1)
bb_2_mid = last(bb_2[,2],1)

atr = ATR(channel, n = 20)
atr = round(last(atr[,2],1),4)
atr = atr
#print(paste0("the atr is ", atr))