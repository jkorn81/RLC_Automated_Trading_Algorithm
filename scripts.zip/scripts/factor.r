if(pv_med_value$x == 'low_potential'){
  if(sl >= 500.01){
    factor_num = 5
  } else if(between(sl, 487.51, 500)){
    factor_num = 4
  } else if(between(sl, 475.01,487.5)){
    factor_num = 4
  } else if(between(sl, 462.51,475)){
    factor_num = 4
  } else if(between(sl, 450.01,462.5)){
    factor_num = 4
  } else if(between(sl, 437.51,450)){
    factor_num = 4
  } else if(between(sl, 425.01,437.5)){
    factor_num = 4
  } else if(between(sl, 412.51,425)){
    factor_num = 4
  } else if(between(sl, 400.01,412.5)){
    factor_num = 4
  } else if(between(sl, 387.51, 400)){
    factor_num = 3
  } else if(between(sl, 375.01,387.5)){
    factor_num = 3
  } else if(between(sl, 362.51,375)){
    factor_num = 3
  } else if(between(sl, 350.01,362.5)){
    factor_num = 3
  } else if(between(sl, 337.51,350)){
    factor_num = 3
  } else if(between(sl, 325.01,337.5)){
    factor_num = 3
  } else if(between(sl, 312.51,325)){
    factor_num = 3
  } else if(between(sl, 300.01,312.5)){
    factor_num = 3
  } else if(between(sl, 287.51, 300)){
    factor_num = 2
  } else if(between(sl, 275.01,287.5)){
    factor_num = 2
  } else if(between(sl, 262.51,275)){
    factor_num = 2
  } else if(between(sl, 250.01,262.5)){
    factor_num = 2
  } else if(between(sl, 237.51,250)){
    factor_num = 2
  } else if(between(sl, 225.01,237.5)){
    factor_num = 2
  } else if(between(sl, 212.51,225)){
    factor_num = 2
  } else if(between(sl, 200.01,212.5)){
    factor_num = 2
  } else if(between(sl, 187.51, 200)){
    factor_num = 1
  } else if(between(sl, 175.01,187.5)){
    factor_num = 1
  } else if(between(sl, 162.51,175)){
    factor_num = 1
  } else if(between(sl, 150.01,162.5)){
    factor_num = 1
  } else if(between(sl, 137.51,150)){
    factor_num = 1
  } else if(between(sl, 125.01,137.5)){
    factor_num = 1
  } else if(between(sl, 112.51,125)){
    factor_num = 1
  } else if(between(sl, 100.01,112.5)){
    factor_num = 1
  } else if(between(sl, 87.51,100)){
    factor_num = 1
  } else if(between(sl, 75.01,87.5)){
    factor_num = 1
  } else if(between(sl, 62.51,75)){
    factor_num = 1
  } else if(between(sl, 50.01,62.5)){
    factor_num = 1
  } else if(between(sl, 37.51,50)){
    factor_num = 1
  } else if(between(sl, 25.01,37.5)){
    factor_num = 1
  } else if(between(sl, 12.51,25)){
    factor_num = 1
  } else if(sl <= 12.5){
    factor_num = 1
  }
}
if(pv_med_value$x == 'medium_potential'){
  if(sl >= 500.01){
    factor_num = 5
  } else if(between(sl, 487.51, 500)){
    factor_num = 4
  } else if(between(sl, 475.01,487.5)){
    factor_num = 4
  } else if(between(sl, 462.51,475)){
    factor_num = 4
  } else if(between(sl, 450.01,462.5)){
    factor_num = 4
  } else if(between(sl, 437.51,450)){
    factor_num = 4
  } else if(between(sl, 425.01,437.5)){
    factor_num = 4
  } else if(between(sl, 412.51,425)){
    factor_num = 4
  } else if(between(sl, 400.01,412.5)){
    factor_num = 4
  } else if(between(sl, 387.51, 400)){
    factor_num = 3
  } else if(between(sl, 375.01,387.5)){
    factor_num = 3
  } else if(between(sl, 362.51,375)){
    factor_num = 3
  } else if(between(sl, 350.01,362.5)){
    factor_num = 3
  } else if(between(sl, 337.51,350)){
    factor_num = 3
  } else if(between(sl, 325.01,337.5)){
    factor_num = 3
  } else if(between(sl, 312.51,325)){
    factor_num = 3
  } else if(between(sl, 300.01,312.5)){
    factor_num = 3
  } else if(between(sl, 287.51, 300)){
    factor_num = 2
  } else if(between(sl, 275.01,287.5)){
    factor_num = 2
  } else if(between(sl, 262.51,275)){
    factor_num = 2
  } else if(between(sl, 250.01,262.5)){
    factor_num = 2
  } else if(between(sl, 237.51,250)){
    factor_num = 2
  } else if(between(sl, 225.01,237.5)){
    factor_num = 2
  } else if(between(sl, 212.51,225)){
    factor_num = 2
  } else if(between(sl, 200.01,212.5)){
    factor_num = 2
  } else if(between(sl, 187.51, 200)){
    factor_num = 1
  } else if(between(sl, 175.01,187.5)){
    factor_num = 1
  } else if(between(sl, 162.51,175)){
    factor_num = 1
  } else if(between(sl, 150.01,162.5)){
    factor_num = 1
  } else if(between(sl, 137.51,150)){
    factor_num = 1
  } else if(between(sl, 125.01,137.5)){
    factor_num = 1
  } else if(between(sl, 112.51,125)){
    factor_num = 1
  } else if(between(sl, 100.01,112.5)){
    factor_num = 1
  } else if(between(sl, 87.51,100)){
    factor_num = 1
  } else if(between(sl, 75.01,87.5)){
    factor_num = 1
  } else if(between(sl, 62.51,75)){
    factor_num = 1
  } else if(between(sl, 50.01,62.5)){
    factor_num = 1
  } else if(between(sl, 37.51,50)){
    factor_num = 1
  } else if(between(sl, 25.01,37.5)){
    factor_num = 1
  } else if(between(sl, 12.51,25)){
    factor_num = 1
  } else if(sl <= 12.5){
    factor_num = 1
  }
}
if(pv_med_value$x == 'high_potential'){
  if(sl >= 500.01){
    factor_num = 5
  } else if(between(sl, 487.51, 500)){
    factor_num = 4
  } else if(between(sl, 475.01,487.5)){
    factor_num = 4
  } else if(between(sl, 462.51,475)){
    factor_num = 4
  } else if(between(sl, 450.01,462.5)){
    factor_num = 4
  } else if(between(sl, 437.51,450)){
    factor_num = 4
  } else if(between(sl, 425.01,437.5)){
    factor_num = 4
  } else if(between(sl, 412.51,425)){
    factor_num = 4
  } else if(between(sl, 400.01,412.5)){
    factor_num = 4
  } else if(between(sl, 387.51, 400)){
    factor_num = 3
  } else if(between(sl, 375.01,387.5)){
    factor_num = 3
  } else if(between(sl, 362.51,375)){
    factor_num = 3
  } else if(between(sl, 350.01,362.5)){
    factor_num = 3
  } else if(between(sl, 337.51,350)){
    factor_num = 3
  } else if(between(sl, 325.01,337.5)){
    factor_num = 3
  } else if(between(sl, 312.51,325)){
    factor_num = 3
  } else if(between(sl, 300.01,312.5)){
    factor_num = 3
  } else if(between(sl, 287.51, 300)){
    factor_num = 2
  } else if(between(sl, 275.01,287.5)){
    factor_num = 2
  } else if(between(sl, 262.51,275)){
    factor_num = 2
  } else if(between(sl, 250.01,262.5)){
    factor_num = 2
  } else if(between(sl, 237.51,250)){
    factor_num = 2
  } else if(between(sl, 225.01,237.5)){
    factor_num = 2
  } else if(between(sl, 212.51,225)){
    factor_num = 2
  } else if(between(sl, 200.01,212.5)){
    factor_num = 2
  } else if(between(sl, 187.51, 200)){
    factor_num = 1
  } else if(between(sl, 175.01,187.5)){
    factor_num = 1
  } else if(between(sl, 162.51,175)){
    factor_num = 1
  } else if(between(sl, 150.01,162.5)){
    factor_num = 1
  } else if(between(sl, 137.51,150)){
    factor_num = 1
  } else if(between(sl, 125.01,137.5)){
    factor_num = 1
  } else if(between(sl, 112.51,125)){
    factor_num = 1
  } else if(between(sl, 100.01,112.5)){
    factor_num = 1
  } else if(between(sl, 87.51,100)){
    factor_num = 1
  } else if(between(sl, 75.01,87.5)){
    factor_num = 1
  } else if(between(sl, 62.51,75)){
    factor_num = 1
  } else if(between(sl, 50.01,62.5)){
    factor_num = 1
  } else if(between(sl, 37.51,50)){
    factor_num = 1
  } else if(between(sl, 25.01,37.5)){
    factor_num = 1
  } else if(between(sl, 12.51,25)){
    factor_num = 1
  } else if(sl <= 12.5){
    factor_num = 1
  }
}
