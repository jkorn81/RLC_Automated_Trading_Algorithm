#######################################################################################
#######################################################################################
#######################################################################################
dir = getwd()
setwd(dir)
#######################################################################################
#######################################################################################
#######################################################################################
#######################################################################################
path = "scripts/safe_nets/safenet_values.xlsx"
if(pv_med_value$x == "low_potential"){
  tp_values_t1_t3 <- read_excel("scripts/position_checks/marker_values3.xlsx", 
                                sheet = "t1_t3")
  tp_values_t4_t5 <- read_excel("scripts/position_checks/marker_values3.xlsx", 
                                sheet = "t4_t5")
  tp_values_t6_t8 <- read_excel("scripts/position_checks/marker_values3.xlsx", 
                                sheet = "t6_t8")
}
if(pv_med_value$x == "medium_potential"){
  tp_values_t1_t3 <- read_excel("scripts/position_checks/marker_values2.xlsx", 
                                sheet = "t1_t3")
  tp_values_t4_t5 <- read_excel("scripts/position_checks/marker_values2.xlsx", 
                                sheet = "t4_t5")
  tp_values_t6_t8 <- read_excel("scripts/position_checks/marker_values2.xlsx", 
                                sheet = "t6_t8")
}
if(pv_med_value$x == "high_potential"){
  tp_values_t1_t3 <- read_excel("scripts/position_checks/marker_values.xlsx", 
                                sheet = "t1_t3")
  tp_values_t4_t5 <- read_excel("scripts/position_checks/marker_values.xlsx", 
                                sheet = "t4_t5")
  tp_values_t6_t8 <- read_excel("scripts/position_checks/marker_values.xlsx", 
                                sheet = "t6_t8")
}
tp_1 = tp_values_t1_t3$target[80]
tp_2 = tp_values_t4_t5$target[80]
tp_3 = tp_values_t6_t8$target[80]
.wb <- openxlsx::loadWorkbook(path)
openxlsx::writeData(
  wb = .wb,
  sheet = 1,
  x = tp_1,
  xy = c(1,2)
)
openxlsx::saveWorkbook(
  .wb,
  path,
  overwrite = TRUE
)
.wb <- openxlsx::loadWorkbook(path)
openxlsx::writeData(
  wb = .wb,
  sheet = 1,
  x = tp_2,
  xy = c(1,3)
)
openxlsx::saveWorkbook(
  .wb,
  path,
  overwrite = TRUE
)
.wb <- openxlsx::loadWorkbook(path)
openxlsx::writeData(
  wb = .wb,
  sheet = 1,
  x = tp_3,
  xy = c(1,4)
)
openxlsx::saveWorkbook(
  .wb,
  path,
  overwrite = TRUE
)
#######################################################################################
#######################################################################################
#######################################################################################
#######################################################################################
if(length(trades) >= 1){
  safenet_values <- read_excel("scripts/safe_nets/safenet_values.xlsx")
}