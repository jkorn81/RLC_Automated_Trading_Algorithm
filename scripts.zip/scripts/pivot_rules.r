library(readxl)
pivots <- read_excel("rl_agent_crowder/outputs/pivots/pivots.xlsx")

pivot_date = pivots$date.Date.

n_last = 5
pivot_month = substr(pivot_date, nchar(pivot_date) - n_last + 1, nchar(pivot_date))
pivot_month = as.numeric(substr(pivot_month, 1, 2))

pivot_date = pivot_date[pivot_month == last(pivot_month,1)]

n_last = 2
pivot_dates = as.numeric(substr( pivot_date, nchar( pivot_date) - n_last + 1, nchar( pivot_date)))
if(length(pivot_dates) == 1){
  past_time = pivot_dates
} else{
  past_time = sort(pivot_dates, decreasing = TRUE)[2]
}
date_index = which(pivot_dates == past_time)
print(paste0("pivot date is ", pivot_date[date_index]))
pivots = pivots[date_index,7:15]


library(dplyr)
pivots = pivots %>% data.frame 
print(pivots)
if(current_cp > pivots$Pivot){
  market = "bullish"
} else if(current_cp < pivots$Pivot){
  market = "bearish"
} else {
  market = "unknown"
}