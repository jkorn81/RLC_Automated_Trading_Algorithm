#######################################################################################
#######################################################################################
#######################################################################################
dir = getwd()
setwd(dir)
#######################################################################################
#######################################################################################
#######################################################################################
#######################################################################################
write.csv(bb_2_low,paste0("outputs/prev_bb_2_low/bb_2_low", lastdate,".csv"), row.names = FALSE)


c_bb_2_list <- list.files(path = "outputs/prev_bb_2_low/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)

if(length(c_bb_2_list)>=2){
  prev_c_bb_2 = first(c_bb_2_list,1)
  prev_c_bb_2 = read_csv(prev_c_bb_2)
  assign("prev_bb_2_low",prev_c_bb_2$x, envir = globalenv())
} else if(length(c_bb_2_list)<= 1){
  prev_c_bb_2 = first(c_bb_2_list,1)
  prev_c_bb_2 = read_csv(prev_c_bb_2)
  assign("prev_bb_2_low",prev_c_bb_2$x, envir = globalenv())
}

if(length(c_bb_2_list)>=2){
  unlink(first(c_bb_2_list,1))
}