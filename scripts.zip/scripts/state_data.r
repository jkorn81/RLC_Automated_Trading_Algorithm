state_data <- list.files(path = "outputs/state_data/.", recursive = TRUE, 
                         pattern = "\\.csv$", 
                         full.names = TRUE)
if(length(state_data) == 0){
  data = data.frame(lastdate, pos_positive_count, pos_negative_count)
  colnames(data) = c('date', 'pos_count', 'neg_count')
  write.csv(data,"outputs/state_data/state_data.csv", row.names = FALSE)
}
if(length(state_data) == 1){
  data = data.frame(read_csv("outputs/state_data/state_data.csv"))
  new_data = data.frame(lastdate, pos_positive_count, pos_negative_count)
  colnames(new_data) = c('date', 'pos_count', 'neg_count')
  data = rbind(data,new_data)
  write.csv(data,"outputs/state_data/state_data.csv", row.names = FALSE)
}