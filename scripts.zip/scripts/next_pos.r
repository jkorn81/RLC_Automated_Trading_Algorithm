if(pv_med_value$x == "low_potential"){
  decide = (sl/factor_num)/2
  decide = (decide / 2)*0.0001
}
if(pv_med_value$x == "medium_potential"){
  decide = (sl/factor_num)/2
  decide = (decide / 2)*0.0001
}
if(pv_med_value$x == "high_potential"){
  decide = (sl/factor_num)/2
  decide = (decide / 2)*0.0001
}
if(length(trades)>=2){
  pvmv <- list.files(path = "outputs/pv_med_value/.", recursive = TRUE, 
                     pattern = "\\.csv$", 
                     full.names = TRUE)
  if(length(pvmv) == 1){
    pv_med_value <- read_csv("outputs/pv_med_value/pvmv.csv")
  }
  if(pv_med_value$x == "low_potential"){
    if(length(trades) >= 2){
      tp_list = last(trades,2)
      potp = read_delim(tp_list[1], escape_double = FALSE, 
                        trim_ws = TRUE, delim=",")
      potp = potp$close
    }
    if(trade_m15 != 0 & length(ext) >= 2| trade_m15 != 98 & length(ext) >= 2| trade_m15 != 99 & length(ext) >= 2){
      if(trade_m15 == 1 & last(ext,1) == 1){
        pip_dif = round(current_cp - potp,6)
        if(pip_dif < decide){
          trade_m15 = 0
          unlink(last(trades,1))
          print(paste0("the pip difference is ", pip_dif))
          print(paste0("hold, current price less than ", decide," pips from potp."))
        } else if(pip_dif >= decide){
          trade_m15 = 1
          print(paste0("the pip difference is ", pip_dif))
          print(paste0("open buy, current price greater than or equal to ", decide, " pips from potp."))
        }
      } 
      if(trade_m15 == 4 & last(ext,1) == 4){
        pip_dif = round(potp - current_cp,6)
        if(pip_dif < decide){
          trade_m15 = 0
          unlink(last(trades,1))
          print(paste0("the pip difference is ", pip_dif))
          print(paste0("hold, current price less than ", decide," pips from potp."))
        } else if(pip_dif >= decide){
          trade_m15 = 4
          print(paste0("the pip difference is ", pip_dif))
          print(paste0("open sell, current price greater than or equal to ", decide, " pips from potp."))
        }
      }
      rm(potp)
    }
  }
  if(pv_med_value$x == "medium_potential"){
    if(length(trades) >= 2){
      tp_list = last(trades,2)
      potp = read_delim(tp_list[1], escape_double = FALSE, 
                        trim_ws = TRUE, delim=",")
      potp = potp$close
    }
    if(trade_m15 != 0 & length(ext) >= 2| trade_m15 != 98 & length(ext) >= 2| trade_m15 != 99 & length(ext) >= 2){
      if(trade_m15 == 1 & last(ext,1) == 1){
        pip_dif = round(current_cp - potp,6)
        if(pip_dif < decide){
          trade_m15 = 0
          unlink(last(trades,1))
          print(paste0("the pip difference is ", pip_dif))
          print(paste0("hold, current price less than ", decide," pips from potp."))
        } else if(pip_dif >= decide){
          trade_m15 = 1
          print(paste0("the pip difference is ", pip_dif))
          print(paste0("open buy, current price greater than or equal to ", decide, " pips from potp."))
        }
      } 
      if(trade_m15 == 4 & last(ext,1) == 4){
        pip_dif = round(potp - current_cp,6)
        if(pip_dif < decide){
          trade_m15 = 0
          unlink(last(trades,1))
          print(paste0("the pip difference is ", pip_dif))
          print(paste0("hold, current price less than ", decide," pips from potp."))
        } else if(pip_dif >= decide){
          trade_m15 = 4
          print(paste0("the pip difference is ", pip_dif))
          print(paste0("open sell, current price greater than or equal to ", decide, " pips from potp."))
        }
      }
      rm(potp)
    }
  }
  if(pv_med_value$x == "high_potential"){
    if(length(trades) >= 2){
      tp_list = last(trades,2)
      potp = read_delim(tp_list[1], escape_double = FALSE, 
                        trim_ws = TRUE, delim=",")
      potp = potp$close
    }
    if(trade_m15 != 0 & length(ext) >= 2| trade_m15 != 98 & length(ext) >= 2| trade_m15 != 99 & length(ext) >= 2){
      if(trade_m15 == 1 & last(ext,1) == 1){
        pip_dif = round(current_cp - potp,6)
        if(pip_dif < decide){
          trade_m15 = 0
          unlink(last(trades,1))
          print(paste0("the pip difference is ", pip_dif))
          print(paste0("hold, current price less than ", decide," pips from potp."))
        } else if(pip_dif >= decide){
          trade_m15 = 1
          print(paste0("the pip difference is ", pip_dif))
          print(paste0("open buy, current price greater than or equal to ", decide, " pips from potp."))
        }
      } 
      if(trade_m15 == 4 & last(ext,1) == 4){
        pip_dif = round(potp - current_cp,6)
        if(pip_dif < decide){
          trade_m15 = 0
          unlink(last(trades,1))
          print(paste0("the pip difference is ", pip_dif))
          print(paste0("hold, current price less than ", decide," pips from potp."))
        } else if(pip_dif >= decide){
          trade_m15 = 4
          print(paste0("the pip difference is ", pip_dif))
          print(paste0("open sell, current price greater than or equal to ", decide, " pips from potp."))
        }
      }
      rm(potp)
    }
  }
}
