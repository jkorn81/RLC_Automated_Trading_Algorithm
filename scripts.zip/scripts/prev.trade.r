if(trade_m15 == "98"){
  print(paste0("save trade results..."))
  type = last(ext,1)
  status = c(ifelse(profit_sum <= 0, "negative", "positive"))
  close_price = c(current_cp)
  prev_trade = data.frame("type" = type,"status" = status, "close price" = close_price)
  write.csv(prev_trade,"outputs/prev_trade_status/pts.csv", row.names = FALSE)
  prev_trade_status <- list.files(path = "outputs/prev_trade_status/.", recursive = TRUE, 
                                  pattern = "\\.csv$", 
                                  full.names = TRUE)
  if(length(prev_trade_status)>=2){
    sapply(prev_trade_status[1], unlink)
  }
} 
if(trade_m15 == "99"){
  print(paste0("save trade results..."))
  type = last(ext,1)
  status = c(ifelse(profit_sum <= 0, "negative", "positive"))
  close_price = c(current_cp)
  prev_trade = data.frame("type" = type,"status" = status, "close price" = close_price)
  write.csv(prev_trade,"outputs/prev_trade_status/pts.csv", row.names = FALSE)
  prev_trade_status <- list.files(path = "outputs/prev_trade_status/.", recursive = TRUE, 
                                  pattern = "\\.csv$", 
                                  full.names = TRUE)
  if(length(prev_trade_status)>=2){
    sapply(prev_trade_status[1], unlink)
  }
} 