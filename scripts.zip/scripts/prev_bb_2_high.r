#######################################################################################
#######################################################################################
#######################################################################################
dir = getwd()
setwd(dir)
#######################################################################################
#######################################################################################
#######################################################################################
#######################################################################################
write.csv(bb_2_high,paste0("outputs/prev_bb_2_high/bb_2_high", lastdate,".csv"), row.names = FALSE)


c_bb_2_list <- list.files(path = "outputs/prev_bb_2_high/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)

if(length(c_bb_2_list)>=2){
  prev_c_bb_2 = first(c_bb_2_list,1)
  prev_c_bb_2 = read_csv(prev_c_bb_2)
  assign("prev_bb_2_high",prev_c_bb_2$x, envir = globalenv())
} else if(length(c_bb_2_list)<= 1){
  prev_c_bb_2 = first(c_bb_2_list,1)
  prev_c_bb_2 = read_csv(prev_c_bb_2)
  assign("prev_bb_2_high",prev_c_bb_2$x, envir = globalenv())
}

if(length(c_bb_2_list)>=2){
  unlink(first(c_bb_2_list,1))
}