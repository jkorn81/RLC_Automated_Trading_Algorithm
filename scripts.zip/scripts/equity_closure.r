original = read_delim("rl_agent_crowder/data/df_rates_p2.csv", escape_double = FALSE, 
                      trim_ws = TRUE, delim=",")
original = data.frame(original)
colnames(original) = c("Account","Balance","Position",'Date', 'Open', 'High', 'Low', 'Close')
balance = last(original$Account,1)
equity = last(original$Balance,1)
percent_change = round((equity-balance)/balance,6)

print(paste0("the percent_change is ", percent_change))

sl = sl
if(pv_med_value$x == 'low_potential'){
  if(sl >= 500.01){
    low_eq = 5*(sl*0.0001)
  } else if(between(sl, 487.51, 500)){
    low_eq = 4*(sl*0.0001)
  } else if(between(sl, 475.01,487.5)){
    low_eq = 4*(sl*0.0001)
  } else if(between(sl, 462.51,475)){
    low_eq = 4*(sl*0.0001)
  } else if(between(sl, 450.01,462.5)){
    low_eq = 4*(sl*0.0001)
  } else if(between(sl, 437.51,450)){
    low_eq = 4*(sl*0.0001)
  } else if(between(sl, 425.01,437.5)){
    low_eq = 4*(sl*0.0001)
  } else if(between(sl, 412.51,425)){
    low_eq = 4*(sl*0.0001)
  } else if(between(sl, 400.01,412.5)){
    low_eq = 4*(sl*0.0001)
  } else if(between(sl, 387.51, 400)){
    low_eq = 3*(sl*0.0001)
  } else if(between(sl, 375.01,387.5)){
    low_eq = 3*(sl*0.0001)
  } else if(between(sl, 362.51,375)){
    low_eq = 3*(sl*0.0001)
  } else if(between(sl, 350.01,362.5)){
    low_eq = 3*(sl*0.0001)
  } else if(between(sl, 337.51,350)){
    low_eq = 3*(sl*0.0001)
  } else if(between(sl, 325.01,337.5)){
    low_eq = 3*(sl*0.0001)
  } else if(between(sl, 312.51,325)){
    low_eq = 3*(sl*0.0001)
  } else if(between(sl, 300.01,312.5)){
    low_eq = 3*(sl*0.0001)
  } else if(between(sl, 287.51, 300)){
    low_eq = 2*(sl*0.0001)
  } else if(between(sl, 275.01,287.5)){
    low_eq = 2*(sl*0.0001)
  } else if(between(sl, 262.51,275)){
    low_eq = 2*(sl*0.0001)
  } else if(between(sl, 250.01,262.5)){
    low_eq = 2*(sl*0.0001)
  } else if(between(sl, 237.51,250)){
    low_eq = 2*(sl*0.0001)
  } else if(between(sl, 225.01,237.5)){
    low_eq = 2*(sl*0.0001)
  } else if(between(sl, 212.51,225)){
    low_eq = 2*(sl*0.0001)
  } else if(between(sl, 200.01,212.5)){
    low_eq = 2*(sl*0.0001)
  } else if(between(sl, 187.51, 200)){
    low_eq = 1*(sl*0.0001)
  } else if(between(sl, 175.01,187.5)){
    low_eq = 1*(sl*0.0001)
  } else if(between(sl, 162.51,175)){
    low_eq = 1*(sl*0.0001)
  } else if(between(sl, 150.01,162.5)){
    low_eq = 1*(sl*0.0001)
  } else if(between(sl, 137.51,150)){
    low_eq = 1*(sl*0.0001)
  } else if(between(sl, 125.01,137.5)){
    low_eq = 1*(sl*0.0001)
  } else if(between(sl, 112.51,125)){
    low_eq = 1*(sl*0.0001)
  } else if(between(sl, 100.01,112.5)){
    low_eq = 1*(sl*0.0001)
  } else if(between(sl, 87.51,100)){
    low_eq = 1*(sl*0.0001)
  } else if(between(sl, 75.01,87.5)){
    low_eq = 1*(sl*0.0001)
  } else if(between(sl, 62.51,75)){
    low_eq = 1*(sl*0.0001)
  } else if(between(sl, 50.01,62.5)){
    low_eq = 1*(sl*0.0001)
  } else if(between(sl, 37.51,50)){
    low_eq = 1*(sl*0.0001)
  } else if(between(sl, 25.01,37.5)){
    low_eq = 1*(sl*0.0001)
  } else if(between(sl, 12.51,25)){
    low_eq = 1*(sl*0.0001)
  } else if(sl <= 12.5){
    low_eq = 1*(sl*0.0001)
  }
  print(paste0("the low equity target is ", low_eq))
}

if(pv_med_value$x == 'medium_potential'){
  if(sl >= 500.01){
    med_eq = 5*(sl*0.0001)
  } else if(between(sl, 487.51, 500)){
    med_eq = 4*(sl*0.0001)
  } else if(between(sl, 475.01,487.5)){
    med_eq = 4*(sl*0.0001)
  } else if(between(sl, 462.51,475)){
    med_eq = 4*(sl*0.0001)
  } else if(between(sl, 450.01,462.5)){
    med_eq = 4*(sl*0.0001)
  } else if(between(sl, 437.51,450)){
    med_eq = 4*(sl*0.0001)
  } else if(between(sl, 425.01,437.5)){
    med_eq = 4*(sl*0.0001)
  } else if(between(sl, 412.51,425)){
    med_eq = 4*(sl*0.0001)
  } else if(between(sl, 400.01,412.5)){
    med_eq = 4*(sl*0.0001)
  } else if(between(sl, 387.51, 400)){
    med_eq = 3*(sl*0.0001)
  } else if(between(sl, 375.01,387.5)){
    med_eq = 3*(sl*0.0001)
  } else if(between(sl, 362.51,375)){
    med_eq = 3*(sl*0.0001)
  } else if(between(sl, 350.01,362.5)){
    med_eq = 3*(sl*0.0001)
  } else if(between(sl, 337.51,350)){
    med_eq = 3*(sl*0.0001)
  } else if(between(sl, 325.01,337.5)){
    med_eq = 3*(sl*0.0001)
  } else if(between(sl, 312.51,325)){
    med_eq = 3*(sl*0.0001)
  } else if(between(sl, 300.01,312.5)){
    med_eq = 3*(sl*0.0001)
  } else if(between(sl, 287.51, 300)){
    med_eq = 2*(sl*0.0001)
  } else if(between(sl, 275.01,287.5)){
    med_eq = 2*(sl*0.0001)
  } else if(between(sl, 262.51,275)){
    med_eq = 2*(sl*0.0001)
  } else if(between(sl, 250.01,262.5)){
    med_eq = 2*(sl*0.0001)
  } else if(between(sl, 237.51,250)){
    med_eq = 2*(sl*0.0001)
  } else if(between(sl, 225.01,237.5)){
    med_eq = 2*(sl*0.0001)
  } else if(between(sl, 212.51,225)){
    med_eq = 2*(sl*0.0001)
  } else if(between(sl, 200.01,212.5)){
    med_eq = 2*(sl*0.0001)
  } else if(between(sl, 187.51, 200)){
    med_eq = 1*(sl*0.0001)
  } else if(between(sl, 175.01,187.5)){
    med_eq = 1*(sl*0.0001)
  } else if(between(sl, 162.51,175)){
    med_eq = 1*(sl*0.0001)
  } else if(between(sl, 150.01,162.5)){
    med_eq = 1*(sl*0.0001)
  } else if(between(sl, 137.51,150)){
    med_eq = 1*(sl*0.0001)
  } else if(between(sl, 125.01,137.5)){
    med_eq = 1*(sl*0.0001)
  } else if(between(sl, 112.51,125)){
    med_eq = 1*(sl*0.0001)
  } else if(between(sl, 100.01,112.5)){
    med_eq = 1*(sl*0.0001)
  } else if(between(sl, 87.51,100)){
    med_eq = 1*(sl*0.0001)
  } else if(between(sl, 75.01,87.5)){
    med_eq = 1*(sl*0.0001)
  } else if(between(sl, 62.51,75)){
    med_eq = 1*(sl*0.0001)
  } else if(between(sl, 50.01,62.5)){
    med_eq = 1*(sl*0.0001)
  } else if(between(sl, 37.51,50)){
    med_eq = 1*(sl*0.0001)
  } else if(between(sl, 25.01,37.5)){
    med_eq = 1*(sl*0.0001)
  } else if(between(sl, 12.51,25)){
    med_eq = 1*(sl*0.0001)
  } else if(sl <= 12.5){
    med_eq = 1*(sl*0.0001)
  }
  print(paste0("the medium equity target is ", med_eq))
}
if(pv_med_value$x == 'high_potential'){
  if(sl >= 500.01){
    high_eq = 5*(sl*0.0001)
  } else if(between(sl, 487.51, 500)){
    high_eq = 4*(sl*0.0001)
  } else if(between(sl, 475.01,487.5)){
    high_eq = 4*(sl*0.0001)
  } else if(between(sl, 462.51,475)){
    high_eq = 4*(sl*0.0001)
  } else if(between(sl, 450.01,462.5)){
    high_eq = 4*(sl*0.0001)
  } else if(between(sl, 437.51,450)){
    high_eq = 4*(sl*0.0001)
  } else if(between(sl, 425.01,437.5)){
    high_eq = 4*(sl*0.0001)
  } else if(between(sl, 412.51,425)){
    high_eq = 4*(sl*0.0001)
  } else if(between(sl, 400.01,412.5)){
    high_eq = 4*(sl*0.0001)
  } else if(between(sl, 387.51, 400)){
    high_eq = 3*(sl*0.0001)
  } else if(between(sl, 375.01,387.5)){
    high_eq = 3*(sl*0.0001)
  } else if(between(sl, 362.51,375)){
    high_eq = 3*(sl*0.0001)
  } else if(between(sl, 350.01,362.5)){
    high_eq = 3*(sl*0.0001)
  } else if(between(sl, 337.51,350)){
    high_eq = 3*(sl*0.0001)
  } else if(between(sl, 325.01,337.5)){
    high_eq = 3*(sl*0.0001)
  } else if(between(sl, 312.51,325)){
    high_eq = 3*(sl*0.0001)
  } else if(between(sl, 300.01,312.5)){
    high_eq = 3*(sl*0.0001)
  } else if(between(sl, 287.51, 300)){
    high_eq = 2*(sl*0.0001)
  } else if(between(sl, 275.01,287.5)){
    high_eq = 2*(sl*0.0001)
  } else if(between(sl, 262.51,275)){
    high_eq = 2*(sl*0.0001)
  } else if(between(sl, 250.01,262.5)){
    high_eq = 2*(sl*0.0001)
  } else if(between(sl, 237.51,250)){
    high_eq = 2*(sl*0.0001)
  } else if(between(sl, 225.01,237.5)){
    high_eq = 2*(sl*0.0001)
  } else if(between(sl, 212.51,225)){
    high_eq = 2*(sl*0.0001)
  } else if(between(sl, 200.01,212.5)){
    high_eq = 2*(sl*0.0001)
  } else if(between(sl, 187.51, 200)){
    high_eq = 1*(sl*0.0001)
  } else if(between(sl, 175.01,187.5)){
    high_eq = 1*(sl*0.0001)
  } else if(between(sl, 162.51,175)){
    high_eq = 1*(sl*0.0001)
  } else if(between(sl, 150.01,162.5)){
    high_eq = 1*(sl*0.0001)
  } else if(between(sl, 137.51,150)){
    high_eq = 1*(sl*0.0001)
  } else if(between(sl, 125.01,137.5)){
    high_eq = 1*(sl*0.0001)
  } else if(between(sl, 112.51,125)){
    high_eq = 1*(sl*0.0001)
  } else if(between(sl, 100.01,112.5)){
    high_eq = 1*(sl*0.0001)
  } else if(between(sl, 87.51,100)){
    high_eq = 1*(sl*0.0001)
  } else if(between(sl, 75.01,87.5)){
    high_eq = 1*(sl*0.0001)
  } else if(between(sl, 62.51,75)){
    high_eq = 1*(sl*0.0001)
  } else if(between(sl, 50.01,62.5)){
    high_eq = 1*(sl*0.0001)
  } else if(between(sl, 37.51,50)){
    high_eq = 1*(sl*0.0001)
  } else if(between(sl, 25.01,37.5)){
    high_eq = 1*(sl*0.0001)
  } else if(between(sl, 12.51,25)){
    high_eq = 1*(sl*0.0001)
  } else if(sl <= 12.5){
    high_eq = 1*(sl*0.0001)
  }
  print(paste0("the high equity target is ", high_eq))
}


if(pv_med_value$x == "low_potential"){
  if(profit_sum >= low_eq & last(ext,1) == 1){
    trade_m15 = 98
    print("force close buy position, profit_sum is @ x pips.")
  }
  
  if(profit_sum >= low_eq & last(ext,1) == 4){
    trade_m15 = 99
    print("force close sell position, profit_sum is @ x pips.")
  }
}
if(pv_med_value$x == "medium_potential"){
  if(profit_sum >= med_eq & last(ext,1) == 1){
    trade_m15 = 98
    print("force close buy position, profit_sum is @ x pips.")
  }
  
  if(profit_sum >= med_eq & last(ext,1) == 4){
    trade_m15 = 99
    print("force close sell position, profit_sum is @ x pips.")
  }
}
if(pv_med_value$x == "high_potential"){
  if(profit_sum >= high_eq & last(ext,1) == 1){
    trade_m15 = 98
    print("force close buy position, profit_sum is @ x pips.")
  }
  
  if(profit_sum >= high_eq & last(ext,1) == 4){
    trade_m15 = 99
    print("force close sell position, profit_sum is @ x pips.")
  }
}
