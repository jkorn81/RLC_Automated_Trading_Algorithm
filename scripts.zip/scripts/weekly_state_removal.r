current_date = lastdate
current_date = gsub("\\.", "-", current_date)
current_date = gsub("^(.{10})(.*)$","\\1 \\2",current_date)
current_date = gsub("^(.{13})(.*)$","\\1:\\2",current_date)
current_date = paste0(current_date, ":00")


pos_theta_list <- list.files(path = "rl_agent_crowder/deploy_outputs/pos_theta/.", recursive = TRUE, 
                       pattern = "\\.csv$", 
                       full.names = TRUE)
if(length(pos_theta_list)>=1){
  ptl_data = data.frame("names" = c(pos_theta_list))
  ptl_data$names = as.character(ptl_data$names)
  ptl_data$dates_only = str_sub(ptl_data$names, start = -22, end = -5)
  ptl_data$dates_only = gsub("^(.{10})(.*)$","\\1 \\2",ptl_data$dates_only)
  ptl_data$dates = str_sub(ptl_data$dates_only, start = 1, end = 10)
  ptl_data$time = str_sub(ptl_data$dates_only, start = -8, end = -1)
  ptl_data$time = str_replace_all(ptl_data$time, "-", ":")
  ptl_data$fulldate = paste0(ptl_data$dates, " ", ptl_data$time)
  ptl_data$fulldate = as.POSIXct(ptl_data$fulldate)
  ptl_data$pt_month = day(ptl_data$fulldate)
  ptl_data$current_month = rep(day(current_date), length(ptl_data$names))
  ptl_data$month_diff = c(ptl_data$current_month - ptl_data$pt_month)
  ptl_remove1 = ptl_data[ptl_data$month_diff < 0,]
  ptl_remove2 = ptl_data[ptl_data$month_diff>=8,]
  ptl_remove = data.frame(rbind(ptl_remove1,ptl_remove2))
  if(length(ptl_remove$names)>=1){
    sapply(ptl_remove$names, unlink)
  }
}
pos_pos_list <- list.files(path = "rl_agent_crowder/deploy_outputs/pos_positions/.", recursive = TRUE, 
                             pattern = "\\.csv$", 
                             full.names = TRUE)
if(length(pos_pos_list)>=1){
  ppl_data = data.frame("names" = c(pos_pos_list))
  ppl_data$names = as.character(ppl_data$names)
  ppl_data$dates_only = str_sub(ppl_data$names, start = -22, end = -5)
  ppl_data$dates_only = gsub("^(.{10})(.*)$","\\1 \\2",ppl_data$dates_only)
  ppl_data$dates = str_sub(ppl_data$dates_only, start = 1, end = 10)
  ppl_data$time = str_sub(ppl_data$dates_only, start = -8, end = -1)
  ppl_data$time = str_replace_all(ppl_data$time, "-", ":")
  ppl_data$fulldate = paste0(ppl_data$dates, " ", ptl_data$time)
  ppl_data$fulldate = as.POSIXct(ppl_data$fulldate)
  ppl_data$pp_month = day(ppl_data$fulldate)
  ppl_data$current_month = rep(day(current_date), length(ppl_data$names))
  ppl_data$month_diff = c(ppl_data$current_month - ppl_data$pp_month)
  ppl_remove1 = ppl_data[ppl_data$month_diff < 0,]
  ppl_remove2 = ppl_data[ppl_data$month_diff >=8,]
  ppl_remove = data.frame(rbind(ppl_remove1,ppl_remove2))
  if(length(ppl_remove$names)>=1){
    sapply(ppl_remove$names, unlink)
  }
}

neg_theta_list <- list.files(path = "rl_agent_crowder/deploy_outputs/neg_theta/.", recursive = TRUE, 
                             pattern = "\\.csv$", 
                             full.names = TRUE)
if(length(neg_theta_list)>=1){
  ntl_data = data.frame("names" = c(neg_theta_list))
  ntl_data$names = as.character(ntl_data$names)
  ntl_data$dates_only = str_sub(ntl_data$names, start = -22, end = -5)
  ntl_data$dates_only = gsub("^(.{10})(.*)$","\\1 \\2",ntl_data$dates_only)
  ntl_data$dates = str_sub(ntl_data$dates_only, start = 1, end = 10)
  ntl_data$time = str_sub(ntl_data$dates_only, start = -8, end = -1)
  ntl_data$time = str_replace_all(ntl_data$time, "-", ":")
  ntl_data$fulldate = paste0(ntl_data$dates, " ", ntl_data$time)
  ntl_data$fulldate = as.POSIXct(ntl_data$fulldate)
  ntl_data$nt_month = day(ntl_data$fulldate)
  ntl_data$current_month = rep(day(current_date), length(ntl_data$names))
  ntl_data$month_diff = c(ntl_data$current_month - ntl_data$nt_month)
  ntl_remove1 = ntl_data[ntl_data$month_diff < 0,]
  ntl_remove2 = ntl_data[ntl_data$month_diff >= 8,]
  ntl_remove = data.frame(rbind(ntl_remove1,ntl_remove2))
  if(length(ntl_remove$names)>=1){
    sapply(ntl_remove$names, unlink)
  }
}
neg_pos_list <- list.files(path = "rl_agent_crowder/deploy_outputs/neg_positions/.", recursive = TRUE, 
                           pattern = "\\.csv$", 
                           full.names = TRUE)
if(length(neg_pos_list)>=1){
  npl_data = data.frame("names" = c(neg_pos_list))
  npl_data$names = as.character(npl_data$names)
  npl_data$dates_only = str_sub(npl_data$names, start = -22, end = -5)
  npl_data$dates_only = gsub("^(.{10})(.*)$","\\1 \\2",npl_data$dates_only)
  npl_data$dates = str_sub(npl_data$dates_only, start = 1, end = 10)
  npl_data$time = str_sub(npl_data$dates_only, start = -8, end = -1)
  npl_data$time = str_replace_all(npl_data$time, "-", ":")
  npl_data$fulldate = paste0(npl_data$dates, " ", npl_data$time)
  npl_data$fulldate = as.POSIXct(npl_data$fulldate)
  npl_data$np_month = day(npl_data$fulldate)
  npl_data$current_month = rep(day(current_date), length(npl_data$names))
  npl_data$month_diff = c(npl_data$current_month - npl_data$np_month)
  npl_remove1 = npl_data[npl_data$month_diff < 0,]
  npl_remove2 = npl_data[npl_data$month_diff >= 8,]
  npl_remove = data.frame(rbind(npl_remove1,npl_remove2))
  if(length(npl_remove$names)>=1){
    sapply(npl_remove$names, unlink)
  }
}