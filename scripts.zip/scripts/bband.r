# BBand Entry 

data_entry <- read_csv("rl_agent_crowder/data/data.csv")
data_entry = last(data_entry$entry_signal,1)
source("scripts/entry_indicator.r")
print(paste0("band entry signal is ", data_entry))

if(trade_m15 != 0 || trade_m15 != 98 || trade_m15 != 99){
  if(length(trades) == 0){
    if(trade_m15 == 1){
      if(data_entry == 1){
        trade_m15 = trade_m15
        print("open buy, previous price is less than prev_bb_low & current price is btw the bb_low and bb_mid.")
      } else if(data_entry == 2){
        trade_m15 = trade_m15
        print("open buy, predicted price is up and sma is moving up and current price is in a buy zone.")
      } else {
        trade_m15 = 0
        print("do not open buy, the previous price and current price do not meet the requirements.")
      }
    }
    if(trade_m15 == 4){
      if(data_entry == -1){
        trade_m15 = trade_m15
        print("open sell, previous price is greater than the prev_bb_high & current price is btw the bb_mid and bb_high.")
      } else if(data_entry == -2){
        trade_m15 = trade_m15
        print("open sell, predicted price is down and sma is moving down and current price is in a sell zone.")
      } else {
        trade_m15 = 0
        print("do not open sell, the previous price and current price do not meet the requirements.")
      }
    }
  } else {
    print("do not run bollinger band entry check, there is no signal to confirm.")
  } 
} else {
  print("do not run bollinger band entry check, there is no signal to confirm.")
}