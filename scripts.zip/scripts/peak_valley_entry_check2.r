#######################################################################################
#######################################################################################
dir = getwd()
setwd(dir)
#######################################################################################
#######################################################################################
#######################################################################################
#######################################################################################
data = read_delim("rl_agent_crowder/data/df_rates_p2.csv", escape_double = FALSE, 
                  trim_ws = TRUE, delim=",")
data = data.frame(data)
colnames(data) = c('Account', 'Balance', 'Position_Count','Date', 'Open', 'High', 'Low', 'Close')
#######################################################################################
#######################################################################################
#######################################################################################
#######################################################################################

if(trade_m15 != 0 || trade_m15 != 98 || trade_m15 != 99){
  
  if(rsqr >= .75){
    pod_data = last(data[,"Close"],96*1)
  } else if(between(rsqr, .60,.749)){
    pod_data = last(data[,"Close"],96*1)
  } else if(between(rsqr, .50,.599)){
    pod_data = last(data[,"Close"],96*1)
  } else if(between(rsqr, .40,.499)){
    pod_data = last(data[,"Close"],96*1)
  } else if(rsqr < .399){
    pod_data = last(data[,"Close"],96*1)
  }
  if(trade_m15 == 1 & trade_type == "reversal"){
    peaks = findPeaks(pod_data)
    peak_index = peaks-1
    peak_value = pod_data[peak_index]
    peak_value = max(peak_value)
    peak_status = match(peak_value, pod_data[peak_index])
    peak_status = peak_index[peak_status]-1
    
    
    valleys = findValleys(pod_data)
    valley_index = valleys-1
    valley_value = pod_data[valley_index]
    valley_value = min(valley_value)
    valley_status = match(valley_value, pod_data[valley_index])
    valley_status = valley_index[valley_status]-1
    
    
    mid_value = median(c(valley_value, peak_value))
    p_mid_value = median(c(mid_value, peak_value))
    v_mid_value = median(c(valley_value, mid_value))
    direction_pv = ifelse(peak_status < valley_status, "p2v", "v2p")
    if(length(peak_value) == 0 & length(valley_value) == 0){
      trade_m15 = 0
      print("no peak and valleys, do not open buy")
    }
    if(length(peak_value) != 0 & length(valley_value) == 0){
      trade_m15 = 0
      print("peaks but no valleys, do not open buy")
    }
    if(length(peak_value) == 0 & length(valley_value) != 0){
      trade_m15 = 0
      print("no peaks but valleys, do not open buy")
    }
    if(length(peak_value) != 0 & length(valley_value) != 0){
      if(direction_pv == "v2p"){
        print("direction is v2p")
        print(paste0("the max peak is ", peak_value))
        print(paste0("the mid_point is ", mid_value))
        print(paste0("the min valley is ", valley_value))
        if(current_cp >= peak_value){
          trade_m15 = trade_m15
          buy_type = "low_potential"
          print(paste0("open buy, ", buy_type))
          write.csv(buy_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(between(current_cp, p_mid_value, peak_value)){
          trade_m15 = trade_m15
          buy_type = "low_potential"
          print(paste0("open buy, ", buy_type))
          write.csv(buy_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(current_cp == p_mid_value){
          trade_m15 = trade_m15
          buy_type = "low_potential"
          print(paste0("open buy, ", buy_type))
          write.csv(buy_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(between(current_cp, mid_value, p_mid_value)){
          trade_m15 = trade_m15
          buy_type = "medium_potential"
          print(paste0("open buy, ", buy_type))
          write.csv(buy_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(current_cp == mid_value){
          trade_m15 = trade_m15
          buy_type = "medium_potential"
          print(paste0("open buy, ", buy_type))
          write.csv(buy_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(between(current_cp, v_mid_value, mid_value)){
          trade_m15 = trade_m15
          buy_type = "medium_potential"
          print(paste0("open buy, ", buy_type))
          write.csv(buy_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(current_cp == v_mid_value){
          trade_m15 = trade_m15
          buy_type = "high_potential"
          print(paste0("open buy, ", buy_type))
          write.csv(buy_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(between(current_cp, valley_value, v_mid_value)){
          trade_m15 = trade_m15
          buy_type = "high_potential"
          print(paste0("open buy, ", buy_type))
          write.csv(buy_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(current_cp <= valley_value){
          trade_m15 = trade_m15
          buy_type = "high_potential"
          print(paste0("open buy, ", buy_type))
          write.csv(buy_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
      }
      if(direction_pv == "p2v"){
        print("direction is p2v.")
        print(paste0("the max peak is ", peak_value))
        print(paste0("the mid_point is ", mid_value))
        print(paste0("the min valley is ", valley_value))
        if(current_cp >= peak_value){
          trade_m15 = 0
          buy_type = "no_potential"
          print(paste0("do not open buy, ", buy_type))
        }
        if(between(current_cp, p_mid_value, peak_value)){
          trade_m15 = 0
          buy_type = "no_potential"
          print(paste0("do not open buy, ", buy_type))
        }
        if(current_cp == p_mid_value){
          trade_m15 = 0
          buy_type = "no_potential"
          print(paste0("do not open buy, ", buy_type))
        }
        if(between(current_cp, mid_value, p_mid_value)){
          trade_m15 = 0
          buy_type = "no_potential"
          print(paste0("do not open buy, ", buy_type))
        }
        if(current_cp == mid_value){
          trade_m15 = 0
          buy_type = "no_potential"
          print(paste0("do not open buy, ", buy_type))
        }
        if(between(current_cp, v_mid_value, mid_value)){
          trade_m15 = 0
          buy_type = "no_potential"
          print(paste0("do not open buy, ", buy_type))
        }
        if(current_cp == v_mid_value){
          trade_m15 = 0
          buy_type = "no_potential"
          print(paste0("do not open buy, ", buy_type))
        }
        if(between(current_cp, valley_value, v_mid_value)){
          trade_m15 = 0
          buy_type = "no_potential"
          print(paste0("do not open buy, ", buy_type))
        }
        if(current_cp <= valley_value){
          trade_m15 = trade_m15
          buy_type = "low_potential"
          print(paste0("open buy, ", buy_type))
          write.csv(buy_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
      }
    }
  }
  if(trade_m15 == 1 & trade_type == "double"){
    peaks = findPeaks(pod_data)
    peak_index = peaks-1
    peak_value = pod_data[peak_index]
    peak_value = max(peak_value)
    peak_status = match(peak_value, pod_data[peak_index])
    peak_status = peak_index[peak_status]-1
    
    
    valleys = findValleys(pod_data)
    valley_index = valleys-1
    valley_value = pod_data[valley_index]
    valley_value = min(valley_value)
    valley_status = match(valley_value, pod_data[valley_index])
    valley_status = valley_index[valley_status]-1
    
    
    mid_value = median(c(valley_value, peak_value))
    p_mid_value = median(c(mid_value, peak_value))
    v_mid_value = median(c(valley_value, mid_value))
    direction_pv = ifelse(peak_status < valley_status, "p2v", "v2p")
    if(length(peak_value) == 0 & length(valley_value) == 0){
      trade_m15 = 0
      print("no peak and valleys, do not open buy")
    }
    if(length(peak_value) != 0 & length(valley_value) == 0){
      trade_m15 = 0
      print("peaks but no valleys, do not open buy")
    }
    if(length(peak_value) == 0 & length(valley_value) != 0){
      trade_m15 = 0
      print("no peaks but valleys, do not open buy")
    }
    if(length(peak_value) != 0 & length(valley_value) != 0){
      if(direction_pv == "v2p"){
        print("direction is v2p.")
        print(paste0("the max peak is ", peak_value))
        print(paste0("the mid_point is ", mid_value))
        print(paste0("the min valley is ", valley_value))
        if(current_cp >= peak_value){
          trade_m15 = trade_m15
          buy_type = "low_potential"
          print(paste0("open buy, ", buy_type))
          write.csv(buy_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(between(current_cp, p_mid_value, peak_value)){
          trade_m15 = trade_m15
          buy_type = "low_potential"
          print(paste0("open buy, ", buy_type))
          write.csv(buy_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(current_cp == p_mid_value){
          trade_m15 = trade_m15
          buy_type = "low_potential"
          print(paste0("open buy, ", buy_type))
          write.csv(buy_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(between(current_cp, mid_value, p_mid_value)){
          trade_m15 = trade_m15
          buy_type = "medium_potential"
          print(paste0("open buy, ", buy_type))
          write.csv(buy_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(current_cp == mid_value){
          trade_m15 = trade_m15
          buy_type = "medium_potential"
          print(paste0("open buy, ", buy_type))
          write.csv(buy_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(between(current_cp, v_mid_value, mid_value)){
          trade_m15 = trade_m15
          buy_type = "medium_potential"
          print(paste0("open buy, ", buy_type))
          write.csv(buy_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(current_cp == v_mid_value){
          trade_m15 = trade_m15
          buy_type = "high_potential"
          print(paste0("open buy, ", buy_type))
          write.csv(buy_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(between(current_cp, valley_value, v_mid_value)){
          trade_m15 = trade_m15
          buy_type = "high_potential"
          print(paste0("open buy, ", buy_type))
          write.csv(buy_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(current_cp <= valley_value){
          trade_m15 = trade_m15
          buy_type = "high_potential"
          print(paste0("open buy, ", buy_type))
          write.csv(buy_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
      }
      if(direction_pv == "p2v"){
        print("direction is p2v.")
        print(paste0("the max peak is ", peak_value))
        print(paste0("the mid_point is ", mid_value))
        print(paste0("the min valley is ", valley_value))
        if(current_cp >= peak_value){
          trade_m15 = 0
          buy_type = "no_potential"
          print(paste0("do not open buy, ", buy_type))
        }
        if(between(current_cp, p_mid_value, peak_value)){
          trade_m15 = 0
          buy_type = "no_potential"
          print(paste0("do not open buy, ", buy_type))
        }
        if(current_cp == p_mid_value){
          trade_m15 = 0
          buy_type = "no_potential"
          print(paste0("do not open buy, ", buy_type))
        }
        if(between(current_cp, mid_value, p_mid_value)){
          trade_m15 = 0
          buy_type = "no_potential"
          print(paste0("do not open buy, ", buy_type))
        }
        if(current_cp == mid_value){
          trade_m15 = 0
          buy_type = "no_potential"
          print(paste0("do not open buy, ", buy_type))
        }
        if(between(current_cp, v_mid_value, mid_value)){
          trade_m15 = 0
          buy_type = "no_potential"
          print(paste0("do not open buy, ", buy_type))
        }
        if(current_cp == v_mid_value){
          trade_m15 = 0
          buy_type = "no_potential"
          print(paste0("do not open buy, ", buy_type))
        }
        if(between(current_cp, valley_value, v_mid_value)){
          trade_m15 = 0
          buy_type = "no_potential"
          print(paste0("do not open buy, ", buy_type))
        }
        if(current_cp <= valley_value){
          trade_m15 = trade_m15
          buy_type = "low_potential"
          print(paste0("open buy, ", buy_type))
          write.csv(buy_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
      }
    }
  }
  if(trade_m15 == 1 & trade_type == "trend"){
    peaks = findPeaks(pod_data)
    peak_index = peaks-1
    peak_value = pod_data[peak_index]
    peak_value = max(peak_value)
    peak_status = match(peak_value, pod_data[peak_index])
    peak_status = peak_index[peak_status]-1
    
    
    valleys = findValleys(pod_data)
    valley_index = valleys-1
    valley_value = pod_data[valley_index]
    valley_value = min(valley_value)
    valley_status = match(valley_value, pod_data[valley_index])
    valley_status = valley_index[valley_status]-1
    
    
    mid_value = median(c(valley_value, peak_value))
    p_mid_value = median(c(mid_value, peak_value))
    v_mid_value = median(c(valley_value, mid_value))
    direction_pv = ifelse(peak_status < valley_status, "p2v", "v2p")
    if(length(peak_value) == 0 & length(valley_value) == 0){
      trade_m15 = 0
      print("no peak and valleys, do not open buy")
    }
    if(length(peak_value) != 0 & length(valley_value) == 0){
      trade_m15 = 0
      print("peaks but no valleys, do not open buy")
    }
    if(length(peak_value) == 0 & length(valley_value) != 0){
      trade_m15 = 0
      print("no peaks but valleys, do not open buy")
    }
    if(length(peak_value) != 0 & length(valley_value) != 0){
      if(direction_pv == "v2p"){
        print("direction is v2p.")
        print(paste0("the max peak is ", peak_value))
        print(paste0("the mid_point is ", mid_value))
        print(paste0("the min valley is ", valley_value))
        if(current_cp >= peak_value){
          trade_m15 = trade_m15
          buy_type = "low_potential"
          print(paste0("open buy, ", buy_type))
          write.csv(buy_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(between(current_cp, p_mid_value, peak_value)){
          trade_m15 = trade_m15
          buy_type = "low_potential"
          print(paste0("open buy, ", buy_type))
          write.csv(buy_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(current_cp == p_mid_value){
          trade_m15 = trade_m15
          buy_type = "low_potential"
          print(paste0("open buy, ", buy_type))
          write.csv(buy_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(between(current_cp, mid_value, p_mid_value)){
          trade_m15 = trade_m15
          buy_type = "medium_potential"
          print(paste0("open buy, ", buy_type))
          write.csv(buy_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(current_cp == mid_value){
          trade_m15 = trade_m15
          buy_type = "medium_potential"
          print(paste0("open buy, ", buy_type))
          write.csv(buy_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(between(current_cp, v_mid_value, mid_value)){
          trade_m15 = trade_m15
          buy_type = "medium_potential"
          print(paste0("open buy, ", buy_type))
          write.csv(buy_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(current_cp == v_mid_value){
          trade_m15 = trade_m15
          buy_type = "high_potential"
          print(paste0("open buy, ", buy_type))
          write.csv(buy_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(between(current_cp, valley_value, v_mid_value)){
          trade_m15 = trade_m15
          buy_type = "high_potential"
          print(paste0("open buy, ", buy_type))
          write.csv(buy_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(current_cp <= valley_value){
          trade_m15 = trade_m15
          buy_type = "high_potential"
          print(paste0("open buy, ", buy_type))
          write.csv(buy_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
      }
      if(direction_pv == "p2v"){
        print("direction is p2v.")
        print(paste0("the max peak is ", peak_value))
        print(paste0("the mid_point is ", mid_value))
        print(paste0("the min valley is ", valley_value))
        if(current_cp >= peak_value){
          trade_m15 = 0
          buy_type = "no_potential"
          print(paste0("do not open buy, ", buy_type))
        }
        if(between(current_cp, p_mid_value, peak_value)){
          trade_m15 = 0
          buy_type = "no_potential"
          print(paste0("do not open buy, ", buy_type))
        }
        if(current_cp == p_mid_value){
          trade_m15 = 0
          buy_type = "no_potential"
          print(paste0("do not open buy, ", buy_type))
        }
        if(between(current_cp, mid_value, p_mid_value)){
          trade_m15 = 0
          buy_type = "no_potential"
          print(paste0("do not open buy, ", buy_type))
        }
        if(current_cp == mid_value){
          trade_m15 = 0
          buy_type = "no_potential"
          print(paste0("do not open buy, ", buy_type))
        }
        if(between(current_cp, v_mid_value, mid_value)){
          trade_m15 = 0
          buy_type = "no_potential"
          print(paste0("do not open buy, ", buy_type))
        }
        if(current_cp == v_mid_value){
          trade_m15 = 0
          buy_type = "no_potential"
          print(paste0("do not open buy, ", buy_type))
        }
        if(between(current_cp, valley_value, v_mid_value)){
          trade_m15 = 0
          buy_type = "no_potential"
          print(paste0("do not open buy, ", buy_type))
        }
        if(current_cp <= valley_value){
          trade_m15 = trade_m15
          buy_type = "low_potential"
          print(paste0("open buy, ", buy_type))
          write.csv(buy_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
      }
    }
  }
  if(trade_m15 == 4 & trade_type == "reversal"){
    peaks = findPeaks(pod_data)
    peak_index = peaks-1
    peak_value = pod_data[peak_index]
    peak_value = max(peak_value)
    peak_status = match(peak_value, pod_data[peak_index])
    peak_status = peak_index[peak_status]-1
    
    
    valleys = findValleys(pod_data)
    valley_index = valleys-1
    valley_value = pod_data[valley_index]
    valley_value = min(valley_value)
    valley_status = match(valley_value, pod_data[valley_index])
    valley_status = valley_index[valley_status]-1
    
    
    mid_value = median(c(valley_value, peak_value))
    p_mid_value = median(c(mid_value, peak_value))
    v_mid_value = median(c(valley_value, mid_value))
    direction_pv = ifelse(peak_status < valley_status, "p2v", "v2p")
    if(length(peak_value) == 0 & length(valley_value) == 0){
      trade_m15 = 0
      print("no peak and valleys, do not open sell")
    }
    if(length(peak_value) != 0 & length(valley_value) == 0){
      trade_m15 = 0
      print("peaks but no valleys, do not open sell")
    }
    if(length(peak_value) == 0 & length(valley_value) != 0){
      trade_m15 = 0
      print("no peaks but valleys, do not open sell")
    }
    if(length(peak_value) != 0 & length(valley_value) != 0){
      if(direction_pv == "v2p"){
        print("direction is v2p.")
        print(paste0("the max peak is ", peak_value))
        print(paste0("the mid_point is ", mid_value))
        print(paste0("the min valley is ", valley_value))
        if(current_cp <= valley_value){
          trade_m15 = 0
          sell_type = "no_potential"
          print(paste0("do not open sell, ", sell_type))
        }
        if(between(current_cp, valley_value, v_mid_value)){
          trade_m15 = 0
          sell_type = "no_potential"
          print(paste0("do not open sell, ", sell_type))
        }
        if(current_cp == v_mid_value){
          trade_m15 = 0
          sell_type = "no_potential"
          print(paste0("do not open sell, ", sell_type))
        }
        if(between(current_cp, v_mid_value, mid_value)){
          trade_m15 = 0
          sell_type = "no_potential"
          print(paste0("do not open sell, ", sell_type))
        }
        if(current_cp == mid_value){
          trade_m15 = 0
          sell_type = "no_potential"
          print(paste0("do not open sell, ", sell_type))
        }
        if(between(current_cp, mid_value, p_mid_value)){
          trade_m15 = 0
          sell_type = "no_potential"
          print(paste0("do not open sell, ", sell_type))
        }
        if(current_cp == p_mid_value){
          trade_m15 = 0
          sell_type = "no_potential"
          print(paste0("do not open sell, ", sell_type))
        }
        if(between(current_cp, p_mid_value, peak_value)){
          trade_m15 = 0
          sell_type = "no_potential"
          print(paste0("do not open sell, ", sell_type))
        }
        if(current_cp >= peak_value){
          trade_m15 = trade_m15
          sell_type = "low_potential"
          print(paste0("open sell, ", sell_type))
          write.csv(sell_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
      }
      if(direction_pv == "p2v"){
        print("direction is p2v.")
        print(paste0("the max peak is ", peak_value))
        print(paste0("the mid_point is ", mid_value))
        print(paste0("the min valley is ", valley_value))
        if(current_cp <= valley_value){
          trade_m15 = trade_m15
          sell_type = "low_potential"
          print(paste0("open sell, ", sell_type))
          write.csv(sell_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(between(current_cp, valley_value, v_mid_value)){
          trade_m15 = trade_m15
          sell_type = "low_potential"
          print(paste0("open sell, ", sell_type))
          write.csv(sell_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(current_cp == v_mid_value){
          trade_m15 = trade_m15
          sell_type = "low_potential"
          print(paste0("open sell, ", sell_type))
          write.csv(sell_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(between(current_cp, v_mid_value, mid_value)){
          trade_m15 = trade_m15
          sell_type = "medium_potential"
          print(paste0("open sell, ", sell_type))
          write.csv(sell_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(current_cp == mid_value){
          trade_m15 = trade_m15
          sell_type = "medium_potential"
          print(paste0("open sell, ", sell_type))
          write.csv(sell_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(between(current_cp, mid_value, p_mid_value)){
          trade_m15 = trade_m15
          sell_type = "medium_potential"
          print(paste0("open sell, ", sell_type))
          write.csv(sell_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(current_cp == p_mid_value){
          trade_m15 = trade_m15
          sell_type = "high_potential"
          print(paste0("open sell, ", sell_type))
          write.csv(sell_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(between(current_cp, p_mid_value, peak_value)){
          trade_m15 = trade_m15
          sell_type = "high_potential"
          print(paste0("open sell, ", sell_type))
          write.csv(sell_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(current_cp >= peak_value){
          trade_m15 = trade_m15
          sell_type = "high_potential"
          print(paste0("open sell, ", sell_type))
          write.csv(sell_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
      }
    }
  }
  if(trade_m15 == 4 & trade_type == "double"){
    peaks = findPeaks(pod_data)
    peak_index = peaks-1
    peak_value = pod_data[peak_index]
    peak_value = max(peak_value)
    peak_status = match(peak_value, pod_data[peak_index])
    peak_status = peak_index[peak_status]-1
    
    
    valleys = findValleys(pod_data)
    valley_index = valleys-1
    valley_value = pod_data[valley_index]
    valley_value = min(valley_value)
    valley_status = match(valley_value, pod_data[valley_index])
    valley_status = valley_index[valley_status]-1
    
    
    mid_value = median(c(valley_value, peak_value))
    p_mid_value = median(c(mid_value, peak_value))
    v_mid_value = median(c(valley_value, mid_value))
    direction_pv = ifelse(peak_status < valley_status, "p2v", "v2p")
    if(length(peak_value) == 0 & length(valley_value) == 0){
      trade_m15 = 0
      print("no peak and valleys, do not open sell")
    }
    if(length(peak_value) != 0 & length(valley_value) == 0){
      trade_m15 = 0
      print("peaks but no valleys, do not open sell")
    }
    if(length(peak_value) == 0 & length(valley_value) != 0){
      trade_m15 = 0
      print("no peaks but valleys, do not open sell")
    }
    if(length(peak_value) != 0 & length(valley_value) != 0){
      if(direction_pv == "v2p"){
        print("direction is v2p.")
        print(paste0("the max peak is ", peak_value))
        print(paste0("the mid_point is ", mid_value))
        print(paste0("the min valley is ", valley_value))
        if(current_cp <= valley_value){
          trade_m15 = 0
          sell_type = "no_potential"
          print(paste0("do not open sell, ", sell_type))
        }
        if(between(current_cp, valley_value, v_mid_value)){
          trade_m15 = 0
          sell_type = "no_potential"
          print(paste0("do not open sell, ", sell_type))
        }
        if(current_cp == v_mid_value){
          trade_m15 = 0
          sell_type = "no_potential"
          print(paste0("do not open sell, ", sell_type))
        }
        if(between(current_cp, v_mid_value, mid_value)){
          trade_m15 = 0
          sell_type = "no_potential"
          print(paste0("do not open sell, ", sell_type))
        }
        if(current_cp == mid_value){
          trade_m15 = 0
          sell_type = "no_potential"
          print(paste0("do not open sell, ", sell_type))
        }
        if(between(current_cp, mid_value, p_mid_value)){
          trade_m15 = 0
          sell_type = "no_potential"
          print(paste0("do not open sell, ", sell_type))
        }
        if(current_cp == p_mid_value){
          trade_m15 = 0
          sell_type = "no_potential"
          print(paste0("do not open sell, ", sell_type))
        }
        if(between(current_cp, p_mid_value, peak_value)){
          trade_m15 = 0
          sell_type = "no_potential"
          print(paste0("do not open sell, ", sell_type))
        }
        if(current_cp >= peak_value){
          trade_m15 = trade_m15
          sell_type = "low_potential"
          print(paste0("open sell, ", sell_type))
          write.csv(sell_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
      }
      if(direction_pv == "p2v"){
        print("direction is p2v, open sell.")
        print(paste0("the max peak is ", peak_value))
        print(paste0("the mid_point is ", mid_value))
        print(paste0("the min valley is ", valley_value))
        if(current_cp <= valley_value){
          trade_m15 = trade_m15
          sell_type = "low_potential"
          print(paste0("open sell, ", sell_type))
          write.csv(sell_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(between(current_cp, valley_value, v_mid_value)){
          trade_m15 = trade_m15
          sell_type = "low_potential"
          print(paste0("open sell, ", sell_type))
          write.csv(sell_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(current_cp == v_mid_value){
          trade_m15 = trade_m15
          sell_type = "low_potential"
          print(paste0("open sell, ", sell_type))
          write.csv(sell_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(between(current_cp, v_mid_value, mid_value)){
          trade_m15 = trade_m15
          sell_type = "medium_potential"
          print(paste0("open sell, ", sell_type))
          write.csv(sell_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(current_cp == mid_value){
          trade_m15 = trade_m15
          sell_type = "medium_potential"
          print(paste0("open sell, ", sell_type))
          write.csv(sell_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(between(current_cp, mid_value, p_mid_value)){
          trade_m15 = trade_m15
          sell_type = "medium_potential"
          print(paste0("open sell, ", sell_type))
          write.csv(sell_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(current_cp == p_mid_value){
          trade_m15 = trade_m15
          sell_type = "high_potential"
          print(paste0("open sell, ", sell_type))
          write.csv(sell_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(between(current_cp, p_mid_value, peak_value)){
          trade_m15 = trade_m15
          sell_type = "high_potential"
          print(paste0("open sell, ", sell_type))
          write.csv(sell_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(current_cp >= peak_value){
          trade_m15 = trade_m15
          sell_type = "high_potential"
          print(paste0("open sell, ", sell_type))
          write.csv(sell_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
      }
    }
  }
  if(trade_m15 == 4 & trade_type == "trend"){
    peaks = findPeaks(pod_data)
    peak_index = peaks-1
    peak_value = pod_data[peak_index]
    peak_value = max(peak_value)
    peak_status = match(peak_value, pod_data[peak_index])
    peak_status = peak_index[peak_status]-1
    
    
    valleys = findValleys(pod_data)
    valley_index = valleys-1
    valley_value = pod_data[valley_index]
    valley_value = min(valley_value)
    valley_status = match(valley_value, pod_data[valley_index])
    valley_status = valley_index[valley_status]-1
    
    
    mid_value = median(c(valley_value, peak_value))
    p_mid_value = median(c(mid_value, peak_value))
    v_mid_value = median(c(valley_value, mid_value))
    direction_pv = ifelse(peak_status < valley_status, "p2v", "v2p")
    if(length(peak_value) == 0 & length(valley_value) == 0){
      trade_m15 = 0
      print("no peak and valleys, do not open sell")
    }
    if(length(peak_value) != 0 & length(valley_value) == 0){
      trade_m15 = 0
      print("peaks but no valleys, do not open sell")
    }
    if(length(peak_value) == 0 & length(valley_value) != 0){
      trade_m15 = 0
      print("no peaks but valleys, do not open sell")
    }
    if(length(peak_value) != 0 & length(valley_value) != 0){
      if(direction_pv == "v2p"){
        print("direction is v2p.")
        print(paste0("the max peak is ", peak_value))
        print(paste0("the mid_point is ", mid_value))
        print(paste0("the min valley is ", valley_value))
        if(current_cp <= valley_value){
          trade_m15 = 0
          sell_type = "no_potential"
          print(paste0("do not open sell, ", sell_type))
        }
        if(between(current_cp, valley_value, v_mid_value)){
          trade_m15 = 0
          sell_type = "no_potential"
          print(paste0("do not open sell, ", sell_type))
        }
        if(current_cp == v_mid_value){
          trade_m15 = 0
          sell_type = "no_potential"
          print(paste0("do not open sell, ", sell_type))
        }
        if(between(current_cp, v_mid_value, mid_value)){
          trade_m15 = 0
          sell_type = "no_potential"
          print(paste0("do not open sell, ", sell_type))
        }
        if(current_cp == mid_value){
          trade_m15 = 0
          sell_type = "no_potential"
          print(paste0("do not open sell, ", sell_type))
        }
        if(between(current_cp, mid_value, p_mid_value)){
          trade_m15 = 0
          sell_type = "no_potential"
          print(paste0("do not open sell, ", sell_type))
        }
        if(current_cp == p_mid_value){
          trade_m15 = 0
          sell_type = "no_potential"
          print(paste0("do not open sell, ", sell_type))
        }
        if(between(current_cp, p_mid_value, peak_value)){
          trade_m15 = 0
          sell_type = "no_potential"
          print(paste0("do not open sell, ", sell_type))
        }
        if(current_cp >= peak_value){
          trade_m15 = trade_m15
          sell_type = "low_potential"
          print(paste0("open sell, ", sell_type))
          write.csv(sell_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
      }
      if(direction_pv == "p2v"){
        print("direction is p2v, open sell.")
        print(paste0("the max peak is ", peak_value))
        print(paste0("the mid_point is ", mid_value))
        print(paste0("the min valley is ", valley_value))
        if(current_cp <= valley_value){
          trade_m15 = trade_m15
          sell_type = "low_potential"
          print(paste0("open sell, ", sell_type))
          write.csv(sell_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(between(current_cp, valley_value, v_mid_value)){
          trade_m15 = trade_m15
          sell_type = "low_potential"
          print(paste0("open sell, ", sell_type))
          write.csv(sell_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(current_cp == v_mid_value){
          trade_m15 = trade_m15
          sell_type = "low_potential"
          print(paste0("open sell, ", sell_type))
          write.csv(sell_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(between(current_cp, v_mid_value, mid_value)){
          trade_m15 = trade_m15
          sell_type = "medium_potential"
          print(paste0("open sell, ", sell_type))
          write.csv(sell_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(current_cp == mid_value){
          trade_m15 = trade_m15
          sell_type = "medium_potential"
          print(paste0("open sell, ", sell_type))
          write.csv(sell_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(between(current_cp, mid_value, p_mid_value)){
          trade_m15 = trade_m15
          sell_type = "medium_potential"
          print(paste0("open sell, ", sell_type))
          write.csv(sell_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(current_cp == p_mid_value){
          trade_m15 = trade_m15
          sell_type = "high_potential"
          print(paste0("open sell, ", sell_type))
          write.csv(sell_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(between(current_cp, p_mid_value, peak_value)){
          trade_m15 = trade_m15
          sell_type = "high_potential"
          print(paste0("open sell, ", sell_type))
          write.csv(sell_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
        if(current_cp >= peak_value){
          trade_m15 = trade_m15
          sell_type = "high_potential"
          print(paste0("open sell, ", sell_type))
          write.csv(sell_type,"outputs/pv_med_value/pvmv.csv", row.names = FALSE)
        }
      }
    }
  }
}
#######################################################################################
#######################################################################################
#######################################################################################
#######################################################################################
