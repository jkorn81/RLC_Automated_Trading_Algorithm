#######################################################################################
#######################################################################################
#######################################################################################
dir = getwd()
setwd(dir)
#######################################################################################
#######################################################################################
#######################################################################################
#######################################################################################
source("scripts/libs.r")
data = read_delim("rl_agent_crowder/data/df_rates_p2.csv", escape_double = FALSE, 
                  trim_ws = TRUE, delim=",")
data = data.frame(data)
colnames(data) = c('Account', 'Balance', 'Position_Count','Date', 'Open', 'High', 'Low', 'Close')
sub = data[,-c(1:7)]
library(readr)
rsqr <- c(read_csv("outputs/rsqr/rsqr.csv"))
bstsclose <- function(x, y) {
  data = log(x[,'Close'])
  ss <- AddSemilocalLinearTrend(list(), y = c(data))
  ss <- AddAutoAr(ss, y = c(data))
  #ss = AddTrig(ss, period = 60, frequencies = 1:3, y = c(data))
  model = bsts(c(x[,'Close']), state.specification = ss, niter = 200)
  print(summary(model)) #model summary report...
  pred = predict(model, horizon = y, quantiles = c(.05, .95), burn = 50)
  assign("Close.Mean",last(pred$mean,10), envir = globalenv())
  ####################################################################################### # high LongTerm (Days) 3 sets of days (2,5,10) if == 1 = 3 if == 0 = 0
  #######################################################################################
  #######################################################################################
  #######################################################################################
}
# - Trend Block ----
if(rsqr >= .75){
  require(bsts)
  n = 60
  horizon = as.numeric(n)*2
  bsdata= data.frame("Close" = last(sub, n))
  bsdata = apply(bsdata,2,as.numeric)
  bstsclose(bsdata, horizon)
  bstsclose <- last(Close.Mean,1)
  bstsdata = data.frame(bstsclose = bstsclose)
  colnames(bstsdata) = c('bstsclose')
} else if(between(rsqr, .60,.749)){
  require(bsts)
  n = 54
  horizon = as.numeric(n)*2
  bsdata= data.frame("Close" = last(sub, n))
  bsdata = apply(bsdata,2,as.numeric)
  bstsclose(bsdata, horizon)
  bstsclose <- last(Close.Mean,1)
  bstsdata = data.frame(bstsclose = bstsclose)
  colnames(bstsdata) = c('bstsclose')
} else if(between(rsqr, .50,.599)){
  require(bsts)
  n = 48
  horizon = as.numeric(n)*2
  bsdata= data.frame("Close" = last(sub, n))
  bsdata = apply(bsdata,2,as.numeric)
  bstsclose(bsdata, horizon)
  bstsclose <- last(Close.Mean,1)
  bstsdata = data.frame(bstsclose = bstsclose)
  colnames(bstsdata) = c('bstsclose')
} else if(between(rsqr, .40,.499)){
  require(bsts)
  n = 42
  horizon = as.numeric(n)*2
  bsdata= data.frame("Close" = last(sub, n))
  bsdata = apply(bsdata,2,as.numeric)
  bstsclose(bsdata, horizon)
  bstsclose <- last(Close.Mean,1)
  bstsdata = data.frame(bstsclose = bstsclose)
  colnames(bstsdata) = c('bstsclose')
} else if(rsqr < .399){
  require(bsts)
  n = 36
  horizon = as.numeric(n)*2
  bsdata= data.frame("Close" = last(sub, n))
  bsdata = apply(bsdata,2,as.numeric)
  bstsclose(bsdata, horizon)
  bstsclose <- last(Close.Mean,1)
  bstsdata = data.frame(bstsclose = bstsclose)
  colnames(bstsdata) = c('bstsclose')
}
bsts_data3 = bstsdata$bstsclose
close_mean_3 = Close.Mean
write.csv(bsts_data3,"outputs/bsts_data/bsts_data3.csv", row.names = FALSE)