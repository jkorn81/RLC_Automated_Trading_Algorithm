source("scripts/marker_sum.r")

if(marker_sum <=0){
  original = read_delim("rl_agent_crowder/data/df_rates_p2.csv", escape_double = FALSE, 
                        trim_ws = TRUE, delim=",")
  original = data.frame(original)
  colnames(original) = c("Account","Balance","Position",'Date', 'Open', 'High', 'Low', 'Close')
  balance = last(original$Account,1)
  equity = last(original$Balance,1)
  percent_change = round((equity-balance)/balance,6)
  if(pv_med_value$x == "low_potential"){
    if(sl >= 500){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 20)*-1
    } else if(between(sl, 487.51, 500)){
      eq = (sl*0.0001)*10
      neg_equity = (eq /19.5)*-1
    } else if(between(sl, 475.01, 487.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq /19)*-1
    } else if(between(sl, 462.51, 475)){
      eq = (sl*0.0001)*10
      neg_equity = (eq /18.5)*-1
    } else if(between(sl, 450.01, 462.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq /18)*-1
    } else if(between(sl, 437.51, 450)){
      eq = (sl*0.0001)*10
      neg_equity = (eq /17.5)*-1
    } else if(between(sl, 425.01, 437.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq /17)*-1
    } else if(between(sl, 412.51, 425)){
      eq = (sl*0.0001)*10
      neg_equity = (eq /16.5)*-1
    } else if(between(sl, 400.01, 412.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq /16)*-1
    } else if(between(sl, 387.51, 400)){
      eq = (sl*0.0001)*10
      neg_equity = (eq /15.5)*-1
    } else if(between(sl, 375.01, 387.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq /15)*-1
    } else if(between(sl, 362.51, 375)){
      eq = (sl*0.0001)*10
      neg_equity = (eq /14.5)*-1
    } else if(between(sl, 350.01, 362.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq /14)*-1
    } else if(between(sl, 337.51, 350)){
      eq = (sl*0.0001)*10
      neg_equity = (eq /13.5)*-1
    } else if(between(sl, 325.01, 337.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq /13)*-1
    } else if(between(sl, 312.51, 325)){
      eq = (sl*0.0001)*10
      neg_equity = (eq /12.5)*-1
    } else if(between(sl, 300.01, 312.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq /12)*-1
    } else if(between(sl, 287.51, 300)){
      eq = (sl*0.0001)*10
      neg_equity = (eq /11.5)*-1
    } else if(between(sl, 275.01, 287.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq /11)*-1
    } else if(between(sl, 262.51, 275)){
      eq = (sl*0.0001)*10
      neg_equity = (eq /10.5)*-1
    } else if(between(sl, 250.01, 262.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq /10)*-1
    } else if(between(sl, 237.51, 250)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 9.5)*-1
    } else if(between(sl, 225.01, 237.5)){
      eq = (sl*0.0001)*10
      neg_equityq = (eq /9)*-1
    } else if(between(sl, 212.51, 225)){
      eq = (sl*0.0001)*10
      neg_equity = (eq /8.5)*-1
    } else if(between(sl, 200.01, 212.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq /8)*-1
    } else if(between(sl, 187.51, 200)){
      eq = (sl*0.0001)*10
      neg_equity = (eq /7.5)*-1
    } else if(between(sl, 175.01,187.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq /7)*-1
    } else if(between(sl, 162.51,175)){
      eq = (sl*0.0001)*10
      neg_equity = (eq /6.5)*-1
    } else if(between(sl, 150.01,162.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq /6)*-1
    } else if(between(sl, 137.51,150)){
      eq = (sl*0.0001)*10
      neg_equity = (eq /5.5)*-1
    } else if(between(sl, 125.01,137.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 5)*-1
    } else if(between(sl, 112.51,125)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 4.5)*-1
    } else if(between(sl, 100.01,112.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 4)*-1
    } else if(between(sl, 87.51,100)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 3.5)*-1
    } else if(between(sl, 75.01,87.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 3)*-1
    } else if(between(sl, 62.51,75)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 2.5)*-1
    } else if(between(sl, 50.01,62.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 2)*-1
    } else if(between(sl, 37.51,50)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 1.5)*-1
    } else if(between(sl, 25.01,37.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 1)*-1
    } else if(between(sl, 12.51,25)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 1)*-1
    } else if(sl <= 12.5){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 1)*-1
    }
  } else if(pv_med_value$x == "medium_potential"){
    if(sl >= 500.01){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 10)*-1
    } else if(between(sl, 487.51, 500)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 9.75)*-1
    } else if(between(sl, 475.01,487.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 9.5)*-1
    } else if(between(sl, 462.51,475)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 9.25)*-1
    } else if(between(sl, 450.01,462.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 9)*-1
    } else if(between(sl, 437.51,450)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 8.75)*-1
    } else if(between(sl, 425.01,437.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 8.5)*-1
    } else if(between(sl, 412.51,425)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 8.25)*-1
    } else if(between(sl, 400.01,412.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 8)*-1
    } else if(between(sl, 387.51, 400)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 7.75)*-1
    } else if(between(sl, 375.01,387.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 7.5)*-1
    } else if(between(sl, 362.51,375)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 7.25)*-1
    } else if(between(sl, 350.01,362.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 7)*-1
    } else if(between(sl, 337.51,350)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 6.75)*-1
    } else if(between(sl, 325.01,337.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 6.5)*-1
    } else if(between(sl, 312.51,325)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 6.25)*-1
    } else if(between(sl, 300.01,312.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 6)*-1
    } else if(between(sl, 287.51, 300)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 5.75)*-1
    } else if(between(sl, 275.01,287.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 5.5)*-1
    } else if(between(sl, 262.51,275)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 5.25)*-1
    } else if(between(sl, 250.01,262.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 5)*-1
    } else if(between(sl, 237.51,250)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 4.75)*-1
    } else if(between(sl, 225.01,237.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 4.5)*-1
    } else if(between(sl, 212.51,225)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 4.25)*-1
    } else if(between(sl, 200.01,212.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 4)*-1
    } else if(between(sl, 187.51, 200)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 3.75)*-1
    } else if(between(sl, 175.01,187.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 3.5)*-1
    } else if(between(sl, 162.51,175)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 3.25)*-1
    } else if(between(sl, 150.01,162.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 3)*-1
    } else if(between(sl, 137.51,150)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 2.75)*-1
    } else if(between(sl, 125.01,137.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 2.5)*-1
    } else if(between(sl, 112.51,125)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 2.25)*-1
    } else if(between(sl, 100.01,112.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 2)*-1
    } else if(between(sl, 87.51,100)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 1.75)*-1
    } else if(between(sl, 75.01,87.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 1.5)*-1
    } else if(between(sl, 62.51,75)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 1.25)*-1
    } else if(between(sl, 50.01,62.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 1)*-1
    } else if(between(sl, 37.51,50)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 1)*-1
    } else if(between(sl, 25.01,37.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 1)*-1
    } else if(between(sl, 12.51,25)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 1)*-1
    } else if(sl <= 12.5){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 1)*-1
    }
  } else if(pv_med_value$x == "high_potential"){
    if(sl >= 500.01){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 5)*-1
    } else if(between(sl, 487.51, 500)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 4.875)*-1
    } else if(between(sl, 475.01,487.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 4.75)*-1
    } else if(between(sl, 462.51,475)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 4.625)*-1
    } else if(between(sl, 450.01,462.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 4.5)*-1
    } else if(between(sl, 437.51,450)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 4.375)*-1
    } else if(between(sl, 425.01,437.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 4.25)*-1
    } else if(between(sl, 412.51,425)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 4.125)*-1
    } else if(between(sl, 400.01,412.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 4)*-1
    } else if(between(sl, 387.51, 400)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 3.875)*-1
    } else if(between(sl, 375.01,387.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 3.75)*-1
    } else if(between(sl, 362.51,375)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 3.625)*-1
    } else if(between(sl, 350.01,362.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 3.5)*-1
    } else if(between(sl, 337.51,350)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 3.375)*-1
    } else if(between(sl, 325.01,337.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 3.25)*-1
    } else if(between(sl, 312.51,325)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 3.125)*-1
    } else if(between(sl, 300.01,312.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 3)*-1
    } else if(between(sl, 287.51, 300)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 2.875)*-1
    } else if(between(sl, 275.01,287.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 2.75)*-1
    } else if(between(sl, 262.51,275)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 2.625)*-1
    } else if(between(sl, 250.01,262.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 2.5)*-1
    } else if(between(sl, 237.51,250)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 2.375)*-1
    } else if(between(sl, 225.01,237.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 2.25)*-1
    } else if(between(sl, 212.51,225)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 2.125)*-1
    } else if(between(sl, 200.01,212.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 2)*-1
    } else if(between(sl, 187.51, 200)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 1.875)*-1
    } else if(between(sl, 175.01,187.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 1.75)*-1
    } else if(between(sl, 162.51,175)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 1.625)*-1
    } else if(between(sl, 150.01,162.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 1.5)*-1
    } else if(between(sl, 137.51,150)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 1.375)*-1
    } else if(between(sl, 125.01,137.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 1.25)*-1
    } else if(between(sl, 112.51,125)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 1.125)*-1
    } else if(between(sl, 100.01,112.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 1)*-1
    } else if(between(sl, 87.51,100)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 1)*-1
    } else if(between(sl, 75.01,87.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 1)*-1
    } else if(between(sl, 62.51,75)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 1)*-1
    } else if(between(sl, 50.01,62.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 1)*-1
    } else if(between(sl, 37.51,50)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 1)*-1
    } else if(between(sl, 25.01,37.5)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 1)*-1
    } else if(between(sl, 12.51,25)){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 1)*-1
    } else if(sl <= 12.5){
      eq = (sl*0.0001)*10
      neg_equity = (eq / 1)*-1
    }
  }
  print(paste0("neg equity closure threshold is .", neg_equity))
  if(percent_change > neg_equity){
    trade_m15 = trade_m15
    print("continue trading, the trade/s equity is in good standing.")
  } else {
    if(last(ext,1) == 1){
      if(o_trade_m15 == 1 & correction == 1 & bar_signal == 1 & direction_pv == "v2p"){
        trade_m15 = trade_m15
        print("continue trading bc another position will open right away, even though the equity is not in good standing.")
      } else {
        trade_m15 = 98
        print("close trade/s no re-positioning occuring right after the closure and equity is not in good standing.") 
      }
    } else if(last(ext,1) == 4){
      if(o_trade_m15 == 4 & correction == -1 & bar_signal == -1 & direction_pv == "p2v"){
        trade_m15 = trade_m15
        print("continue trading bc another position will open right away, even though the equity is not in good standing.")
      } else {
        trade_m15 = 99
        print("close trade/s no re-positioning occuring right after the closure and equity is not in good standing.") 
      }
    }
  }
} else {
  print("marker is reached so continue trading.")
}