trades <- list.files(path = "trades/.", recursive = TRUE, 
                     pattern = "\\.csv$", 
                     full.names = TRUE)
n_last <- 5                               
ext = substr(trades, nchar(trades) - n_last + 1, nchar(trades)) 
require(stringr)
require(data.table)
ext = str_remove(ext,".csv")

if(trade_m15 == 98){
  if(last(ext,1) == 1 & o_trade_m15 == 4){
    trade_m15 = trade_m15
    close_vote1 = "yes"
    print("existing buys with reverse rl sell signal, so close buys.")
  } else if(last(ext,1) == 1 & pos_positive_count == 0 & pos_negative_count == 0){
    trade_m15 = trade_m15
    close_vote1 = "yes"
    print("existing buys with no buy/sell signal, so close buys.")
  } else if(last(ext,1) == 1 & pos_positive_count == pos_negative_count){
    trade_m15 = trade_m15
    close_vote1 = "yes"
    print("existing buys with even buy/sell signal, so close buys.")
  } else{
    print("closure was not due to rl states.")
    trade_m15 = trade_m15
    close_vote1 = "no"
  }
} 

source("scripts/position_count.r")
if(trade_m15 == 98){
  if(positions == 0 & length(trades)>=1){
    print("ea closed position/s so remove trade file/s.")
    if(last(ext,1) == 1){
      trade_m15 == trade_m15
      close_vote2 = "yes"
    }
  } else{
    print("closure was not due to ea.")
    trade_m15 = trade_m15
    close_vote2 = "no"
  } 
} 

if(trade_m15 == 98){
 if(length(marker) == 0){
   if(length(trades)>=1 & length(fixed_marker)==1){
     target = (marker_values_t1_t3$reverse[1]*0.0001)*-1
     reverse = (marker_values_t1_t3$target[1]*0.0001)*-1
     p_pip_dif = profit_sum
     if(p_pip_dif <= reverse){
       trade_m15 = trade_m15
       close_vote3 = "yes"
       print("close buy, the price is falling after hitting fixed marker.")
     } else {
       print("closure not due to the fixed marker being reached.")
       trade_m15 = trade_m15
       close_vote3 = "no"
     }
   } else {
     print("closure not due to the fixed marker being reached.")
     trade_m15 = trade_m15
     close_vote3 = "no"
   }
 } else {
   print("closure not due to the fixed marker being reached.")
   trade_m15 = trade_m15
   close_vote3 = "no"
 }
}

if(close_vote1 == "yes" & close_vote2 == "no" & close_vote3 == "no"){
  trade_m15 = 98
} else if(close_vote1 == "no" & close_vote2 == "yes" & close_vote3 == "no"){
  trade_m15 = 98
} else if(close_vote1 == "no" & close_vote2 == "yes" & close_vote3 == "yes"){
  trade_m15 = 98
} else if(close_vote1 == "yes" & close_vote2 == "yes" & close_vote3 == "yes"){
  trade_m15 = 98
} else if(close_vote1 == "yes" & close_vote2 == "yes" & close_vote3 == "no"){
  trade_m15 = 98
}  else if(close_vote1 == "yes" & close_vote2 == "no" & close_vote3 == "yes"){
  trade_m15 = 98
} else if(close_vote1 == "no" & close_vote2 == "no" & close_vote3 == "yes"){
  trade_m15 = 98
} else {
  if(trade_m15 == 98){
    if(o_trade_m15 == 1 & correction == 1 & bar_signal == 1 & profit_sum > (marker_values_t1_t3$target[1]*0.0001)*-1){
      trade_m15 = 0
      print("ignore closure bc another position will open right away.")
    } else {
      print("accept closure no re-positioning occuring right after the closure.")
      trade_m15 = trade_m15
    } 
  }
}
