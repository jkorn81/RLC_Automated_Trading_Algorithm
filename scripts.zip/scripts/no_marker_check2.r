source("scripts/marker_sum.r")

if(marker_sum <=0){
  original = read_delim("rl_agent_crowder/data/df_rates_p2.csv", escape_double = FALSE, 
                        trim_ws = TRUE, delim=",")
  original = data.frame(original)
  colnames(original) = c("Account","Balance","Position",'Date', 'Open', 'High', 'Low', 'Close')
  balance = last(original$Account,1)
  equity = last(original$Balance,1)
  percent_change = round((equity-balance)/balance,6)
  eq = (sl*0.0001)*10
  neg_equity = (eq)*-1
  print(paste0("neg equity closure threshold is .", neg_equity))
  if(percent_change > neg_equity){
    trade_m15 = trade_m15
    print("continue trading, the trade/s equity is in good standing.")
  } else {
    if(last(ext,1) == 1){
      if(o_trade_m15 == 1 & correction == 1 & bar_signal == 1 & direction_pv == "v2p" & market == "bullish"){
        trade_m15 = trade_m15
        print("continue trading bc another position will open right away, even though the equity is not in good standing.")
      } else {
        trade_m15 = 98
        print("close trade/s no re-positioning occuring right after the closure and equity is not in good standing.") 
      }
    } else if(last(ext,1) == 4){
      if(o_trade_m15 == 4 & correction == -1 & bar_signal == -1 & direction_pv == "p2v" & market == "bearish"){
        trade_m15 = trade_m15
        print("continue trading bc another position will open right away, even though the equity is not in good standing.")
      } else {
        trade_m15 = 99
        print("close trade/s no re-positioning occuring right after the closure and equity is not in good standing.") 
      }
    }
  }
} else {
  print("marker is reached so continue trading.")
}