prev_trade_status <- list.files(path = "outputs/prev_trade_status/.", recursive = TRUE, 
                           pattern = "\\.csv$", 
                           full.names = TRUE)

if(length(prev_trade_status)>=1){
  if(trade_m15 == 1){
    prev_trade_results <- read_csv("outputs/prev_trade_status/pts.csv")
    prev_close_price = prev_trade_results$close_price
    prev_type = prev_trade_results$type
    prev_status = prev_trade_results$status
    pivots <- read_excel("rl_agent_crowder/outputs/pivots.xlsx")
    pivots = pivots[7,7:15]
    if(between(current_cp, pivots$Pivot, pivots$R1)){
      curr_distance_r1 = pivots$R1 - current_cp
      curr_distance_pivot = current_cp - pivots$Pivot
      if(curr_distance_r1 < curr_distance_pivot){
        prev_distance_r1 = pivots$R1 - prev_close_price
        prev_distance_pivot = prev_close_price - pivots$Pivot
        if(prev_distance_r1 < prev_distance_pivot){
          trade_m15 = 0
          print("ignore, do not open the buy bc price action indicates not a good entry point.")
        }
      }
    }
    if(between(current_cp, pivots$R1, pivots$R2)){
      curr_distance_r2 = pivots$R2 - current_cp
      curr_distance_pivot = current_cp - pivots$R1
      if(curr_distance_r2 < curr_distance_pivot){
        prev_distance_r2 = pivots$R2 - prev_close_price
        prev_distance_pivot = prev_close_price - pivots$Pivot
        if(prev_distance_r2 < prev_distance_pivot){
          trade_m15 = 0
          print("ignore, do not open the buy bc price action indicates not a good entry point.")
        }
      }
    }
    if(between(current_cp, pivots$R2, pivots$R3)){
      curr_distance_r3 = pivots$R3 - current_cp
      curr_distance_pivot = current_cp - pivots$R2
      if(curr_distance_r3 < curr_distance_pivot){
        prev_distance_r3 = pivots$R3 - prev_close_price
        prev_distance_pivot = prev_close_price - pivots$Pivot
        if(prev_distance_r3 < prev_distance_pivot){
          trade_m15 = 0
          print("ignore, do not open the buy bc price action indicates not a good entry point.")
        }
      }
    }
    if(between(current_cp, pivots$R3, pivots$R4)){
      curr_distance_r4 = pivots$R4 - current_cp
      curr_distance_pivot = current_cp - pivots$R3
      if(curr_distance_r4 < curr_distance_pivot){
        prev_distance_r4 = pivots$R4 - prev_close_price
        prev_distance_pivot = prev_close_price - pivots$Pivot
        if(prev_distance_r4 < prev_distance_pivot){
          trade_m15 = 0
          print("ignore, do not open the buy bc price action indicates not a good entry point.")
        }
      }
    }
    if(current_cp > pivots$R4){
      trade_m15 = 0
      print("ignore, do not open the buy bc price action indicates not a good entry point.")
    }
    if(current_cp <= pivots$Pivot){
      trade_m15 = 0
      print("ignore, do not open the buy bc price action indicates not a good entry point.")
    }
  }
  if(trade_m15 == 4){
    prev_trade_results <- read_csv("outputs/prev_trade_status/pts.csv")
    prev_close_price = prev_trade_results$close_price
    prev_type = prev_trade_results$type
    prev_status = prev_trade_results$status
    pivots <- read_excel("rl_agent_crowder/outputs/pivots.xlsx")
    pivots = pivots[7,7:15]
    if(prev_status == "positive"){
      if(prev_close_price <= pivots$S1 & current_cp <= pivots$S1){
        trade_m15 = 0
        print("ignore, do not open a sell the price does not show much room for profit.")
      }
    }
  }
}