prev_trade_status <- list.files(path = "trades/.", recursive = TRUE, 
                                pattern = "\\.csv$", 
                                full.names = TRUE)
prev_trade_results <- read_csv(last(prev_trade_status,1))
prev_trade_results <- prev_trade_results %>% data.frame 

r1 = last(pivots$R1,1)
r2 = last(pivots$R2,1)
r3 = last(pivots$R3,1)
r4 = last(pivots$R4,1)

pivot_point = last(pivots$Pivot,1)

s1 = last(pivots$S1,1)
s2 = last(pivots$S2,1)
s3 = last(pivots$S3,1)
s4 = last(pivots$S4,1)

pt_price = prev_trade_results$close

if(pt_price < pivot_point){
  if(between(pt_price, s1, pivot_point)){
    s1_range = seq(from = s1, to = pivot_point, by = 0.0001)
    s1_quartile = quantile(s1_range, c(0.0,0.125, 0.25, 0.375, 0.50, 0.625, 0.75, 0.875, 1.0))
    if(between(pt_price, s1_quartile[8], s1_quartile[9])){
      pt_level = "s1-8"
      print("pt price btw support price 1 and pivot point.")
      print("pt price sits btw quartile 87.5% and 100%.")
    }
    if(between(pt_price, s1_quartile[7], s1_quartile[8])){
      pt_level = "s1-7"
      print("pt price btw support price 1 and pivot point.")
      print("pt price sits btw quartile 75% and 87.5%.")
    }
    if(between(pt_price, s1_quartile[6], s1_quartile[7])){
      pt_level = "s1-6"
      print("pt price btw support price 1 and pivot point.")
      print("pt price sits btw quartile 62.5% and 75%.")
    }
    if(between(pt_price, s1_quartile[5], s1_quartile[6])){
      pt_level = "s1-5"
      print("pt price btw support price 1 and pivot point.")
      print("pt price sits btw quartile 50% and 62.5%.")
    }
    if(between(pt_price, s1_quartile[4], s1_quartile[5])){
      pt_level = "s1-4"
      print("pt price btw support price 1 and pivot point.")
      print("pt price sits btw quartile 37.5% and 50%.")
    }
    if(between(pt_price, s1_quartile[3], s1_quartile[4])){
      pt_level = "s1-3"
      print("pt price btw support price 1 and pivot point.")
      print("pt price sits btw quartile 25% and 37.5%.")
    }
    if(between(pt_price, s1_quartile[2], s1_quartile[3])){
      pt_level = "s1-2"
      print("pt price btw support price 1 and pivot point.")
      print("pt price sits btw quartile 12.5% and 25%.")
    }
    if(between(pt_price, s1_quartile[1], s1_quartile[2])){
      pt_level = "s1-1"
      print("pt price btw support price 1 and pivot point.")
      print("pt price sits btw quartile 0% and 12.5%.")
    }
  }
  if(between(pt_price, s2, s1)){
    s1_range = seq(from = s2, to = s1, by = 0.0001)
    s1_quartile = quantile(s1_range, c(0.0,0.125, 0.25, 0.375, 0.50, 0.625, 0.75, 0.875, 1.0))
    if(between(pt_price, s1_quartile[8], s1_quartile[9])){
      pt_level = "s2-8"
      print("pt price btw support price 2 and support price 1.")
      print("pt price sits btw quartile 87.5% and 100%.")
    }
    if(between(pt_price, s1_quartile[7], s1_quartile[8])){
      pt_level = "s2-87"
      print("pt price btw support price 2 and support price 1.")
      print("pt price sits btw quartile 75% and 87.5%.")
    }
    if(between(pt_price, s1_quartile[6], s1_quartile[7])){
      pt_level = "s2-6"
      print("pt price btw support price 2 and support price 1.")
      print("pt price sits btw quartile 62.5% and 75%.")
    }
    if(between(pt_price, s1_quartile[5], s1_quartile[6])){
      pt_level = "s2-5"
      print("pt price btw support price 2 and support price 1.")
      print("pt price sits btw quartile 50% and 62.5%.")
    }
    if(between(pt_price, s1_quartile[4], s1_quartile[5])){
      pt_level = "s2-4"
      print("pt price btw support price 2 and support price 1.")
      print("pt price sits btw quartile 37.5% and 50%.")
    }
    if(between(pt_price, s1_quartile[3], s1_quartile[4])){
      pt_level = "s2-3"
      print("pt price btw support price 2 and support price 1.")
      print("pt price sits btw quartile 25% and 37.5%.")
    }
    if(between(pt_price, s1_quartile[2], s1_quartile[3])){
      pt_level = "s2-2"
      print("pt price btw support price 2 and support price 1.")
      print("pt price sits btw quartile 12.5% and 25%.")
    }
    if(between(pt_price, s1_quartile[1], s1_quartile[2])){
      pt_level = "s2-1"
      print("pt price btw support price 2 and support price 1.")
      print("pt price sits btw quartile 0% and 12.5%.")
    }
  }
  if(between(pt_price, s3, s2)){
    s1_range = seq(from = s3, to = s2, by = 0.0001)
    s1_quartile = quantile(s1_range, c(0.0,0.125, 0.25, 0.375, 0.50, 0.625, 0.75, 0.875, 1.0))
    if(between(pt_price, s1_quartile[8], s1_quartile[9])){
      pt_level = "s3-8"
      print("pt price btw support price 3 and support price 2.")
      print("pt price sits btw quartile 87.5% and 100%.")
    }
    if(between(pt_price, s1_quartile[7], s1_quartile[8])){
      pt_level = "s3-7"
      print("pt price btw support price 3 and support price 2.")
      print("pt price sits btw quartile 75% and 87.5%.")
    }
    if(between(pt_price, s1_quartile[6], s1_quartile[7])){
      pt_level = "s3-6"
      print("pt price btw support price 3 and support price 2.")
      print("pt price sits btw quartile 62.5% and 75%.")
    }
    if(between(pt_price, s1_quartile[5], s1_quartile[6])){
      pt_level = "s3-5"
      print("pt price btw support price 3 and support price 2.")
      print("pt price sits btw quartile 50% and 62.5%.")
    }
    if(between(pt_price, s1_quartile[4], s1_quartile[5])){
      pt_level = "s3-4"
      print("pt price btw support price 3 and support price 2.")
      print("pt price sits btw quartile 37.5% and 50%.")
    }
    if(between(pt_price, s1_quartile[3], s1_quartile[4])){
      pt_level = "s3-3"
      print("pt price btw support price 3 and support price 2.")
      print("pt price sits btw quartile 25% and 37.5%.")
    }
    if(between(pt_price, s1_quartile[2], s1_quartile[3])){
      pt_level = "s3-2"
      print("pt price btw support price 3 and support price 2.")
      print("pt price sits btw quartile 12.5% and 25%.")
    }
    if(between(pt_price, s1_quartile[1], s1_quartile[2])){
      pt_level = "s3-1"
      print("pt price btw support price 3 and support price 2.")
      print("pt price sits btw quartile 0% and 12.5%.")
    }
  }
  if(between(pt_price, s4, s3)){
    s1_range = seq(from = s4, to = s3, by = 0.0001)
    s1_quartile = quantile(s1_range, c(0.0,0.125, 0.25, 0.375, 0.50, 0.625, 0.75, 0.875, 1.0))
    if(between(pt_price, s1_quartile[8], s1_quartile[9])){
      pt_level = "s4-8"
      print("pt price btw support price 4 and support price 3.")
      print("pt price sits btw quartile 87.5% and 100%.")
    }
    if(between(pt_price, s1_quartile[7], s1_quartile[8])){
      pt_level = "s4-7"
      print("pt price btw support price 4 and support price 3.")
      print("pt price sits btw quartile 75% and 87.5%.")
    }
    if(between(pt_price, s1_quartile[6], s1_quartile[7])){
      pt_level = "s4-6"
      print("pt price btw support price 4 and support price 3.")
      print("pt price sits btw quartile 62.5% and 75%.")
    }
    if(between(pt_price, s1_quartile[5], s1_quartile[6])){
      pt_level = "s4-5"
      print("pt price btw support price 4 and support price 3.")
      print("pt price sits btw quartile 50% and 62.5%.")
    }
    if(between(pt_price, s1_quartile[4], s1_quartile[5])){
      pt_level = "s4-4"
      print("pt price btw support price 4 and support price 3.")
      print("pt price sits btw quartile 37.5% and 50%.")
    }
    if(between(pt_price, s1_quartile[3], s1_quartile[4])){
      pt_level = "s4-3"
      print("pt price btw support price 4 and support price 3.")
      print("pt price sits btw quartile 25% and 37.5%.")
    }
    if(between(pt_price, s1_quartile[2], s1_quartile[3])){
      pt_level = "s4-2"
      print("pt price btw support price 4 and support price 3.")
      print("pt price sits btw quartile 12.5% and 25%.")
    }
    if(between(pt_price, s1_quartile[1], s1_quartile[2])){
      pt_level = "s4-1"
      print("pt price btw support price 4 and support price 3.")
      print("pt price sits btw quartile 0% and 12.5%.")
    }
  }
  if(pt_price<=s4){
    pt_level = "s5"
    print("pt price less than support price s4.")
  }
}
if(pt_price > pivot_point){
  if(between(pt_price, pivot_point, r1)){
    r1_range = seq(from = pivot_point, to = r1, by = 0.0001)
    r1_quartile = quantile(r1_range, c(0.0,0.125, 0.25, 0.375, 0.50, 0.625, 0.75, 0.875, 1.0))
    if(between(pt_price, r1_quartile[8], r1_quartile[9])){
      pt_level = "r1-8"
      print("pt price btw pivot point and the resistence price 1.")
      print("pt price sits btw quartile 87.5% and 100%.")
    }
    if(between(pt_price, r1_quartile[7], r1_quartile[8])){
      pt_level = "r1-7"
      print("pt price btw pivot point and the resistence price 1.")
      print("pt price sits btw quartile 75% and 87.5%.")
    }
    if(between(pt_price, r1_quartile[6], r1_quartile[7])){
      pt_level = "r1-6"
      print("pt price btw pivot point and the resistence price 1.")
      print("pt price sits btw quartile 62.5% and 75%.")
    }
    if(between(pt_price, r1_quartile[5], r1_quartile[6])){
      pt_level = "r1-5"
      print("pt price btw pivot point and the resistence price 1.")
      print("pt price sits btw quartile 50% and 62.5%.")
    }
    if(between(pt_price, r1_quartile[4], r1_quartile[5])){
      pt_level = "r1-4"
      print("pt price btw pivot point and the resistence price 1.")
      print("pt price sits btw quartile 37.5% and 50%.")
    }
    if(between(pt_price, r1_quartile[3], r1_quartile[4])){
      pt_level = "r1-3"
      print("pt price btw pivot point and the resistence price 1.")
      print("pt price sits btw quartile 25% and 37.5%.")
    }
    if(between(pt_price, r1_quartile[2], r1_quartile[3])){
      pt_level = "r1-2"
      print("pt price btw pivot point and the resistence price 1.")
      print("pt price sits btw quartile 12.5% and 25%.")
    }
    if(between(pt_price, r1_quartile[1], r1_quartile[2])){
      pt_level = "r1-1"
      print("pt price btw pivot point and the resistence price 1.")
      print("pt price sits btw quartile 0% and 12.5%.")
    }
  }
  if(between(pt_price, r1, r2)){
    r1_range = seq(from = r1, to = r2, by = 0.0001)
    r1_quartile = quantile(r1_range, c(0.0,0.125, 0.25, 0.375, 0.50, 0.625, 0.75, 0.875, 1.0))
    if(between(pt_price, r1_quartile[8], r1_quartile[9])){
      pt_level = "r2-8"
      print("pt price btw the resistence price 1 and the resistence price 2.")
      print("pt price sits btw quartile 87.5% and 100%.")
    }
    if(between(pt_price, r1_quartile[7], r1_quartile[8])){
      pt_level = "r2-7"
      print("pt price btw resistence price 1 and the resistence price 2.")
      print("pt price sits btw quartile 75% and 87.5%.")
    }
    if(between(pt_price, r1_quartile[6], r1_quartile[7])){
      pt_level = "r2-6"
      print("pt price btw resistence price 1 and the resistence price 2.")
      print("pt price sits btw quartile 62.5% and 75%.")
    }
    if(between(pt_price, r1_quartile[5], r1_quartile[6])){
      pt_level = "r2-5"
      print("pt price btw resistence price 1 and the resistence price 2.")
      print("pt price sits btw quartile 50% and 62.5%.")
    }
    if(between(pt_price, r1_quartile[4], r1_quartile[5])){
      pt_level = "r2-4"
      print("pt price btw resistence price 1 and the resistence price 2.")
      print("pt price sits btw quartile 37.5% and 50%.")
    }
    if(between(pt_price, r1_quartile[3], r1_quartile[4])){
      pt_level = "r2-3"
      print("pt price btw resistence price 1 and the resistence price 2.")
      print("pt price sits btw quartile 25% and 37.5%.")
    }
    if(between(pt_price, r1_quartile[2], r1_quartile[3])){
      pt_level = "r2-2"
      print("pt price btw resistence price 1 and the resistence price 2.")
      print("pt price sits btw quartile 12.5% and 25%.")
    }
    if(between(pt_price, r1_quartile[1], r1_quartile[2])){
      pt_level = "r2-1"
      print("pt price btw resistence price 1 and the resistence price 2.")
      print("pt price sits btw quartile 0% and 12.5%.")
    }
  }
  if(between(pt_price, r2, r3)){
    r1_range = seq(from = r2, to = r3, by = 0.0001)
    r1_quartile = quantile(r1_range, c(0.0,0.125, 0.25, 0.375, 0.50, 0.625, 0.75, 0.875, 1.0))
    if(between(pt_price, r1_quartile[8], r1_quartile[9])){
      pt_level = "r3-8"
      print("pt price btw the resistence price 2 and the resistence price 3.")
      print("pt price sits btw quartile 87.5% and 100%.")
    }
    if(between(pt_price, r1_quartile[7], r1_quartile[8])){
      pt_level = "r3-7"
      print("pt price btw the resistence price 2 and the resistence price 3.")
      print("pt price sits btw quartile 75% and 87.5%.")
    }
    if(between(pt_price, r1_quartile[6], r1_quartile[7])){
      pt_level = "r3-6"
      print("pt price btw the resistence price 2 and the resistence price 3.")
      print("pt price sits btw quartile 62.5% and 75%.")
    }
    if(between(pt_price, r1_quartile[5], r1_quartile[6])){
      pt_level = "r3-5"
      print("pt price btw the resistence price 2 and the resistence price 3.")
      print("pt price sits btw quartile 50% and 62.5%.")
    }
    if(between(pt_price, r1_quartile[4], r1_quartile[5])){
      pt_level = "r3-4"
      print("pt price btw the resistence price 2 and the resistence price 3.")
      print("pt price sits btw quartile 37.5% and 50%.")
    }
    if(between(pt_price, r1_quartile[3], r1_quartile[4])){
      pt_level = "r3-3"
      print("pt price btw the resistence price 2 and the resistence price 3.")
      print("pt price sits btw quartile 25% and 37.5%.")
    }
    if(between(pt_price, r1_quartile[2], r1_quartile[3])){
      pt_level = "r3-2"
      print("pt price btw the resistence price 2 and the resistence price 3.")
      print("pt price sits btw quartile 12.5% and 25%.")
    }
    if(between(pt_price, r1_quartile[1], r1_quartile[2])){
      pt_level = "r3-1"
      print("pt price btw the resistence price 2 and the resistence price 3.")
      print("pt price sits btw quartile 0% and 12.5%.")
    }
  }
  if(between(pt_price, r3, r4)){
    r1_range = seq(from = r3, to = r4, by = 0.0001)
    r1_quartile = quantile(r1_range, c(0.0,0.125, 0.25, 0.375, 0.50, 0.625, 0.75, 0.875, 1.0))
    if(between(pt_price, r1_quartile[8], r1_quartile[9])){
      pt_level = "r4-8"
      print("pt price btw the resistence price 3 and the resistence price 4.")
      print("pt price sits btw quartile 87.5% and 100%.")
    }
    if(between(pt_price, r1_quartile[7], r1_quartile[8])){
      pt_level = "r4-7"
      print("pt price btw the resistence price 3 and the resistence price 4.")
      print("pt price sits btw quartile 75% and 87.5%.")
    }
    if(between(pt_price, r1_quartile[6], r1_quartile[7])){
      pt_level = "r4-6"
      print("pt price btw the resistence price 3 and the resistence price 4.")
      print("pt price sits btw quartile 62.5% and 75%.")
    }
    if(between(pt_price, r1_quartile[5], r1_quartile[6])){
      pt_level = "r4-5"
      print("pt price btw the resistence price 3 and the resistence price 4.")
      print("pt price sits btw quartile 50% and 62.5%.")
    }
    if(between(pt_price, r1_quartile[4], r1_quartile[5])){
      pt_level = "r4-4"
      print("pt price btw the resistence price 3 and the resistence price 4.")
      print("pt price sits btw quartile 37.5% and 50%.")
    }
    if(between(pt_price, r1_quartile[3], r1_quartile[4])){
      pt_level = "r4-3"
      print("pt price btw the resistence price 3 and the resistence price 4.")
      print("pt price sits btw quartile 25% and 37.5%.")
    }
    if(between(pt_price, r1_quartile[2], r1_quartile[3])){
      pt_level = "r4-2"
      print("pt price btw the resistence price 3 and the resistence price 4.")
      print("pt price sits btw quartile 12.5% and 25%.")
    }
    if(between(pt_price, r1_quartile[1], r1_quartile[2])){
      pt_level = "r4-1"
      print("pt price btw the resistence price 3 and the resistence price 4.")
      print("pt price sits btw quartile 0% and 12.5%.")
    }
  }
  if(pt_price>=r4){
    pt_level = "r5"
    print("pt price greater than the resistence price r4.")
  }
}

print(paste0("the past trade price level is ", pt_level))