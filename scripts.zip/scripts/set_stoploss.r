pti_list <- list.files(path = "outputs/past_trade_status/.", recursive = TRUE, 
                       pattern = "\\.csv$", 
                       full.names = TRUE)
source("scripts/set_stoploss1.r")
if(length(pti_list)>=11){
  sapply(first(pti_list,1), unlink)
}