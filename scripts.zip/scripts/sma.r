#######################################################################################
#######################################################################################
#######################################################################################
dir = getwd()
setwd(dir)
#######################################################################################
#######################################################################################
#######################################################################################
#######################################################################################
write.csv(bb_mid,paste0("outputs/sma/sma", lastdate,".csv"), row.names = FALSE)


cp_sma_list <- list.files(path = "outputs/sma/.", recursive = TRUE, 
                          pattern = "\\.csv$", 
                          full.names = TRUE)

if(length(cp_sma_list)>=2){
  prev_cp_sma = first(cp_sma_list,1)
  prev_cp_sma = read_csv(prev_cp_sma)
  assign("prev_sma",prev_cp_sma$x, envir = globalenv())
  last_cp_sma = last(cp_sma_list,1)
  last_cp_sma = read_csv(last_cp_sma)
  assign("current_sma",last_cp_sma$x, envir = globalenv())
} else if(length(cp_sma_list)<= 1){
  prev_cp_sma = first(cp_sma_list,1)
  prev_cp_sma = read_csv(prev_cp_sma)
  assign("prev_sma",prev_cp_sma$x, envir = globalenv())
  last_cp_sma = last(cp_sma_list,1)
  last_cp_sma = read_csv(last_cp_sma)
  assign("current_sma",last_cp_sma$x, envir = globalenv())
}

if(length(cp_sma_list)>=2){
  unlink(first(cp_sma_list,1))
}