original = read_delim("rl_agent_crowder/data/df_rates_p2.csv", escape_double = FALSE, 
                      trim_ws = TRUE, delim=",")
original = data.frame(original)
colnames(original) = c("Account","Balance","Position",'Date', 'Open', 'High', 'Low', 'Close')
balance = last(original$Account,1)
equity = last(original$Balance,1)
percent_change = round((equity-balance)/balance,6)

print(paste0("the percent_change is ", percent_change))

sl = sl

if(pv_med_value$x == 'low_potential'){
  low_eq = ((sl*0.0001)*10)
  print(paste0("the low equity target is ", low_eq))
}
if(pv_med_value$x == 'medium_potential'){
  med_eq = ((sl*0.0001)*10)
  print(paste0("the medium equity target is ", med_eq))
}
if(pv_med_value$x == 'high_potential'){
  high_eq = ((sl*0.0001)*10)
  print(paste0("the high equity target is ", high_eq))
}


if(pv_med_value$x == "low_potential"){
  if(percent_change >= low_eq & last(ext,1) == 1){
    trade_m15 = 98
    print("force close buy position, equity is @ a x% return.")
  }
  
  if(percent_change >= low_eq & last(ext,1) == 4){
    trade_m15 = 99
    print("force close sell position, equity is @ a x% return.")
  }
}
if(pv_med_value$x == "medium_potential"){
  if(percent_change >= med_eq & last(ext,1) == 1){
    trade_m15 = 98
    print("force close buy position, equity is @ a x% return.")
  }
  
  if(percent_change >= med_eq & last(ext,1) == 4){
    trade_m15 = 99
    print("force close sell position, equity is @ a x% return.")
  }
}
if(pv_med_value$x == "high_potential"){
  if(percent_change >= high_eq & last(ext,1) == 1){
    trade_m15 = 98
    print("force close buy position, equity is @ a x% return.")
  }
  
  if(percent_change >= high_eq & last(ext,1) == 4){
    trade_m15 = 99
    print("force close sell position, equity is @ a x% return.")
  }
}
