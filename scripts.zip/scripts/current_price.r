#######################################################################################
#######################################################################################
#######################################################################################
dir = getwd()
setwd(dir)
#######################################################################################
#######################################################################################
#######################################################################################
#######################################################################################
original = read_delim("rl_agent_crowder/data/df_rates_p2.csv", escape_double = FALSE, 
                      trim_ws = TRUE, delim=",")
original = data.frame(original)
colnames(original) = c("Account","Balance","Position",'Date', 'Open', 'High', 'Low', 'Close')
current = last(original[,-c(1:7)],1)
write.csv(current,paste0("outputs/cp/cp", lastdate,".csv"), row.names = FALSE)


cp_list <- list.files(path = "outputs/cp/.", recursive = TRUE, 
                      pattern = "\\.csv$", 
                      full.names = TRUE)

if(length(cp_list)>=2){
  prev_cp = first(cp_list,1)
  prev_cp = read_csv(prev_cp)
  assign("prev_cp",prev_cp$x, envir = globalenv())
  last_cp = last(cp_list,1)
  last_cp = read_csv(last_cp)
  assign("current_cp",last_cp$x, envir = globalenv())
} else if(length(cp_list)<= 1){
  prev_cp = first(cp_list,1)
  prev_cp = read_csv(prev_cp)
  assign("prev_cp",prev_cp$x, envir = globalenv())
  last_cp = last(cp_list,1)
  last_cp = read_csv(last_cp)
  assign("current_cp",last_cp$x, envir = globalenv())
}

if(length(cp_list)>=2){
  unlink(first(cp_list,1))
}