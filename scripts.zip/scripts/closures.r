#######################################################################################
#######################################################################################
#######################################################################################
dir = getwd()
setwd(dir)
#######################################################################################
#######################################################################################
#######################################################################################
#######################################################################################
if(length(trades)>=1){
  if(between(sl, 20, 29.999)){
    if(trade_type == "reversal"){
      if(last(ext,1) == 1 & correction == -1){
        if(profit_sum < (default_value/2)){
          trade_m15 = 98
          print("close buy, the predicted trend opposes and mitigated sl met.")
        }
      }
      if(last(ext,1) == 4 & correction == 1){
        if(profit_sum < (default_value/2)){
          trade_m15 = 99
          print("close sell, the predicted trend opposes and mitigated sl met.")
        }
      }
    }
    if(trade_type == "double"){
      if(last(ext,1) == 1 & correction == -1){
        if(profit_sum < (default_value/2)){
          trade_m15 = 98
          print("close buy, the predicted trend opposes and mitigated sl met.")
        }
      }
      if(last(ext,1) == 4 & correction == 1){
        if(profit_sum < (default_value/2)){
          trade_m15 = 99
          print("close sell, the predicted trend opposes and mitigated sl met.")
        }
      }
    }
  }
  if(between(sl, 30, 39.999)){
    if(trade_type == "reversal"){
      if(last(ext,1) == 1 & correction == -1){
        if(profit_sum < (default_value/2)){
          trade_m15 = 98
          print("close buy, the predicted trend opposes and mitigated sl met.")
        }
      }
      if(last(ext,1) == 4 & correction == 1){
        if(profit_sum < (default_value/2)){
          trade_m15 = 99
          print("close sell, the predicted trend opposes and mitigated sl met.")
        }
      }
    }
    if(trade_type == "double"){
      if(last(ext,1) == 1 & correction == -1){
        if(profit_sum < (default_value/2)){
          trade_m15 = 98
          print("close buy, the predicted trend opposes and mitigated sl met.")
        }
      }
      if(last(ext,1) == 4 & correction == 1){
        if(profit_sum < (default_value/2)){
          trade_m15 = 99
          print("close sell, the predicted trend opposes and mitigated sl met.")
        }
      }
    }
  }
  if(between(sl, 40, 49.999)){
    if(trade_type == "reversal"){
      if(last(ext,1) == 1 & correction == -1){
        if(profit_sum < (default_value/2)){
          trade_m15 = 98
          print("close buy, the predicted trend opposes and mitigated sl met.")
        }
      }
      if(last(ext,1) == 4 & correction == 1){
        if(profit_sum < (default_value/2)){
          trade_m15 = 99
          print("close sell, the predicted trend opposes and mitigated sl met.")
        }
      }
    }
    if(trade_type == "double"){
      if(last(ext,1) == 1 & correction == -1){
        if(profit_sum < (default_value/2)){
          trade_m15 = 98
          print("close buy, the predicted trend opposes and mitigated sl met.")
        }
      }
      if(last(ext,1) == 4 & correction == 1){
        if(profit_sum < (default_value/2)){
          trade_m15 = 99
          print("close sell, the predicted trend opposes and mitigated sl met.")
        }
      }
    }
  }
  if(between(sl, 50, 59.999)){
    if(trade_type == "reversal"){
      if(last(ext,1) == 1 & correction == -1){
        if(profit_sum < (default_value/2)){
          trade_m15 = 98
          print("close buy, the predicted trend opposes and mitigated sl met.")
        }
      }
      if(last(ext,1) == 4 & correction == 1){
        if(profit_sum < (default_value/2)){
          trade_m15 = 99
          print("close sell, the predicted trend opposes and mitigated sl met.")
        }
      }
    }
    if(trade_type == "double"){
      if(last(ext,1) == 1 & correction == -1){
        if(profit_sum < (default_value/2)){
          trade_m15 = 98
          print("close buy, the predicted trend opposes and mitigated sl met.")
        }
      }
      if(last(ext,1) == 4 & correction == 1){
        if(profit_sum < (default_value/2)){
          trade_m15 = 99
          print("close sell, the predicted trend opposes and mitigated sl met.")
        }
      }
    }
  }
  if(between(sl, 60, 69.999)){
    if(trade_type == "reversal"){
      if(last(ext,1) == 1 & correction == -1){
        if(profit_sum < (default_value/2)){
          trade_m15 = 98
          print("close buy, the predicted trend opposes and mitigated sl met.")
        }
      }
      if(last(ext,1) == 4 & correction == 1){
        if(profit_sum < (default_value/2)){
          trade_m15 = 99
          print("close sell, the predicted trend opposes and mitigated sl met.")
        }
      }
    }
    if(trade_type == "double"){
      if(last(ext,1) == 1 & correction == -1){
        if(profit_sum < (default_value/2)){
          trade_m15 = 98
          print("close buy, the predicted trend opposes and mitigated sl met.")
        }
      }
      if(last(ext,1) == 4 & correction == 1){
        if(profit_sum < (default_value/2)){
          trade_m15 = 99
          print("close sell, the predicted trend opposes and mitigated sl met.")
        }
      }
    }
  }
  if(between(sl, 70, 79.999)){
    if(trade_type == "reversal"){
      if(last(ext,1) == 1 & correction == -1){
        if(profit_sum < (default_value/2)){
          trade_m15 = 98
          print("close buy, the predicted trend opposes and mitigated sl met.")
        }
      }
      if(last(ext,1) == 4 & correction == 1){
        if(profit_sum < (default_value/2)){
          trade_m15 = 99
          print("close sell, the predicted trend opposes and mitigated sl met.")
        }
      }
    }
    if(trade_type == "double"){
      if(last(ext,1) == 1 & correction == -1){
        if(profit_sum < (default_value/2)){
          trade_m15 = 98
          print("close buy, the predicted trend opposes and mitigated sl met.")
        }
      }
      if(last(ext,1) == 4 & correction == 1){
        if(profit_sum < (default_value/2)){
          trade_m15 = 99
          print("close sell, the predicted trend opposes and mitigated sl met.")
        }
      }
    }
  }
  if(between(sl, 80, 89.999)){
    if(trade_type == "reversal"){
      if(last(ext,1) == 1 & correction == -1){
        if(profit_sum < (default_value/2)){
          trade_m15 = 98
          print("close buy, the predicted trend opposes and mitigated sl met.")
        }
      }
      if(last(ext,1) == 4 & correction == 1){
        if(profit_sum < (default_value/2)){
          trade_m15 = 99
          print("close sell, the predicted trend opposes and mitigated sl met.")
        }
      }
    }
    if(trade_type == "double"){
      if(last(ext,1) == 1 & correction == -1){
        if(profit_sum < (default_value/2)){
          trade_m15 = 98
          print("close buy, the predicted trend opposes and mitigated sl met.")
        }
      }
      if(last(ext,1) == 4 & correction == 1){
        if(profit_sum < (default_value/2)){
          trade_m15 = 99
          print("close sell, the predicted trend opposes and mitigated sl met.")
        }
      }
    }
  }
  if(between(sl, 90, 99.999)){
    if(trade_type == "reversal"){
      if(last(ext,1) == 1 & correction == -1){
        if(profit_sum < (default_value/2)){
          trade_m15 = 98
          print("close buy, the predicted trend opposes and mitigated sl met.")
        }
      }
      if(last(ext,1) == 4 & correction == 1){
        if(profit_sum < (default_value/2)){
          trade_m15 = 99
          print("close sell, the predicted trend opposes and mitigated sl met.")
        }
      }
    }
    if(trade_type == "double"){
      if(last(ext,1) == 1 & correction == -1){
        if(profit_sum < (default_value/2)){
          trade_m15 = 98
          print("close buy, the predicted trend opposes and mitigated sl met.")
        }
      }
      if(last(ext,1) == 4 & correction == 1){
        if(profit_sum < (default_value/2)){
          trade_m15 = 99
          print("close sell, the predicted trend opposes and mitigated sl met.")
        }
      }
    }
  }
  if(sl == 100){
    if(trade_type == "reversal"){
      if(last(ext,1) == 1 & correction == -1){
        if(profit_sum < (default_value/2)){
          trade_m15 = 98
          print("close buy, the predicted trend opposes and mitigated sl met.")
        }
      }
      if(last(ext,1) == 4 & correction == 1){
        if(profit_sum < (default_value/2)){
          trade_m15 = 99
          print("close sell, the predicted trend opposes and mitigated sl met.")
        }
      }
    }
    if(trade_type == "double"){
      if(last(ext,1) == 1 & correction == -1){
        if(profit_sum < (default_value/2)){
          trade_m15 = 98
          print("close buy, the predicted trend opposes and mitigated sl met.")
        }
      }
      if(last(ext,1) == 4 & correction == 1){
        if(profit_sum < (default_value/2)){
          trade_m15 = 99
          print("close sell, the predicted trend opposes and mitigated sl met.")
        }
      }
    }
  }
}