r1 = last(pivots$R1,1)
r2 = last(pivots$R2,1)
r3 = last(pivots$R3,1)
r4 = last(pivots$R4,1)

pivot_point = last(pivots$Pivot,1)

s1 = last(pivots$S1,1)
s2 = last(pivots$S2,1)
s3 = last(pivots$S3,1)
s4 = last(pivots$S4,1)

# We may want to change it so that the btw pivot point and s1 is pivot point value minus s4 value


if(pv_med_value$x == 'low_potential'){
  if(current_cp < pivot_point){
    if(between(current_cp, s1, pivot_point)){
      s1_range = seq(from = s1, to = pivot_point, by = 0.0001)
      s1_quartile = quantile(s1_range, c(0.0,0.125, 0.25, 0.375, 0.50, 0.625, 0.75, 0.875, 1.0))
      if(between(current_cp, s1_quartile[8], s1_quartile[9])){
        sl = s1_quartile[9]-s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 1 and pivot point.")
        print("current price sits btw quartile 87.5% and 100%.")
      }
      if(between(current_cp, s1_quartile[7], s1_quartile[8])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 1 and pivot point.")
        print("current price sits btw quartile 75% and 87.5%.")
      }
      if(between(current_cp, s1_quartile[6], s1_quartile[7])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 1 and pivot point.")
        print("current price sits btw quartile 62.5% and 75%.")
      }
      if(between(current_cp, s1_quartile[5], s1_quartile[6])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 1 and pivot point.")
        print("current price sits btw quartile 50% and 62.5%.")
      }
      if(between(current_cp, s1_quartile[4], s1_quartile[5])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 1 and pivot point.")
        print("current price sits btw quartile 37.5% and 50%.")
      }
      if(between(current_cp, s1_quartile[3], s1_quartile[4])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 1 and pivot point.")
        print("current price sits btw quartile 25% and 37.5%.")
      }
      if(between(current_cp, s1_quartile[2], s1_quartile[3])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 1 and pivot point.")
        print("current price sits btw quartile 12.5% and 25%.")
      }
      if(between(current_cp, s1_quartile[1], s1_quartile[2])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 1 and pivot point.")
        print("current price sits btw quartile 0% and 12.5%.")
      }
    }
    if(between(current_cp, s2, s1)){
      s1_range = seq(from = s2, to = s1, by = 0.0001)
      s1_quartile = quantile(s1_range, c(0.0,0.125, 0.25, 0.375, 0.50, 0.625, 0.75, 0.875, 1.0))
      if(between(current_cp, s1_quartile[8], s1_quartile[9])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 2 and support price 1.")
        print("current price sits btw quartile 87.5% and 100%.")
      }
      if(between(current_cp, s1_quartile[7], s1_quartile[8])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 2 and support price 1.")
        print("current price sits btw quartile 75% and 87.5%.")
      }
      if(between(current_cp, s1_quartile[6], s1_quartile[7])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 2 and support price 1.")
        print("current price sits btw quartile 62.5% and 75%.")
      }
      if(between(current_cp, s1_quartile[5], s1_quartile[6])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 2 and support price 1.")
        print("current price sits btw quartile 50% and 62.5%.")
      }
      if(between(current_cp, s1_quartile[4], s1_quartile[5])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 2 and support price 1.")
        print("current price sits btw quartile 37.5% and 50%.")
      }
      if(between(current_cp, s1_quartile[3], s1_quartile[4])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 2 and support price 1.")
        print("current price sits btw quartile 25% and 37.5%.")
      }
      if(between(current_cp, s1_quartile[2], s1_quartile[3])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 2 and support price 1.")
        print("current price sits btw quartile 12.5% and 25%.")
      }
      if(between(current_cp, s1_quartile[1], s1_quartile[2])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 2 and support price 1.")
        print("current price sits btw quartile 0% and 12.5%.")
      }
    }
    if(between(current_cp, s3, s2)){
      s1_range = seq(from = s3, to = s2, by = 0.0001)
      s1_quartile = quantile(s1_range, c(0.0,0.125, 0.25, 0.375, 0.50, 0.625, 0.75, 0.875, 1.0))
      if(between(current_cp, s1_quartile[8], s1_quartile[9])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 3 and support price 2.")
        print("current price sits btw quartile 87.5% and 100%.")
      }
      if(between(current_cp, s1_quartile[7], s1_quartile[8])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 3 and support price 2.")
        print("current price sits btw quartile 75% and 87.5%.")
      }
      if(between(current_cp, s1_quartile[6], s1_quartile[7])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 3 and support price 2.")
        print("current price sits btw quartile 62.5% and 75%.")
      }
      if(between(current_cp, s1_quartile[5], s1_quartile[6])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 3 and support price 2.")
        print("current price sits btw quartile 50% and 62.5%.")
      }
      if(between(current_cp, s1_quartile[4], s1_quartile[5])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 3 and support price 2.")
        print("current price sits btw quartile 37.5% and 50%.")
      }
      if(between(current_cp, s1_quartile[3], s1_quartile[4])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 3 and support price 2.")
        print("current price sits btw quartile 25% and 37.5%.")
      }
      if(between(current_cp, s1_quartile[2], s1_quartile[3])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 3 and support price 2.")
        print("current price sits btw quartile 12.5% and 25%.")
      }
      if(between(current_cp, s1_quartile[1], s1_quartile[2])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 3 and support price 2.")
        print("current price sits btw quartile 0% and 12.5%.")
      }
    }
    if(between(current_cp, s4, s3)){
      s1_range = seq(from = s4, to = s3, by = 0.0001)
      s1_quartile = quantile(s1_range, c(0.0,0.125, 0.25, 0.375, 0.50, 0.625, 0.75, 0.875, 1.0))
      if(between(current_cp, s1_quartile[8], s1_quartile[9])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 4 and support price 3.")
        print("current price sits btw quartile 87.5% and 100%.")
      }
      if(between(current_cp, s1_quartile[7], s1_quartile[8])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 4 and support price 3.")
        print("current price sits btw quartile 75% and 87.5%.")
      }
      if(between(current_cp, s1_quartile[6], s1_quartile[7])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 4 and support price 3.")
        print("current price sits btw quartile 62.5% and 75%.")
      }
      if(between(current_cp, s1_quartile[5], s1_quartile[6])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 4 and support price 3.")
        print("current price sits btw quartile 50% and 62.5%.")
      }
      if(between(current_cp, s1_quartile[4], s1_quartile[5])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 4 and support price 3.")
        print("current price sits btw quartile 37.5% and 50%.")
      }
      if(between(current_cp, s1_quartile[3], s1_quartile[4])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 4 and support price 3.")
        print("current price sits btw quartile 25% and 37.5%.")
      }
      if(between(current_cp, s1_quartile[2], s1_quartile[3])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 4 and support price 3.")
        print("current price sits btw quartile 12.5% and 25%.")
      }
      if(between(current_cp, s1_quartile[1], s1_quartile[2])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 4 and support price 3.")
        print("current price sits btw quartile 0% and 12.5%.")
      }
    }
    if(current_cp<=s4){
      if(length(trades>=0)){
        if(trade_m15 == 1){
          trade_m15 = 0
        }
        if(trade_m15 == 4){
          trade_m15 = 0
        }
      } 
      print("current price less than support price s4.")
    }
  }
  if(current_cp > pivot_point){
    if(between(current_cp, pivot_point, r1)){
      r1_range = seq(from = pivot_point, to = r1, by = 0.0001)
      r1_quartile = quantile(r1_range, c(0.0,0.125, 0.25, 0.375, 0.50, 0.625, 0.75, 0.875, 1.0))
      if(between(current_cp, r1_quartile[8], r1_quartile[9])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw pivot point and the resistence price 1.")
        print("current price sits btw quartile 87.5% and 100%.")
      }
      if(between(current_cp, r1_quartile[7], r1_quartile[8])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw pivot point and the resistence price 1.")
        print("current price sits btw quartile 75% and 87.5%.")
      }
      if(between(current_cp, r1_quartile[6], r1_quartile[7])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw pivot point and the resistence price 1.")
        print("current price sits btw quartile 62.5% and 75%.")
      }
      if(between(current_cp, r1_quartile[5], r1_quartile[6])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw pivot point and the resistence price 1.")
        print("current price sits btw quartile 50% and 62.5%.")
      }
      if(between(current_cp, r1_quartile[4], r1_quartile[5])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw pivot point and the resistence price 1.")
        print("current price sits btw quartile 37.5% and 50%.")
      }
      if(between(current_cp, r1_quartile[3], r1_quartile[4])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw pivot point and the resistence price 1.")
        print("current price sits btw quartile 25% and 37.5%.")
      }
      if(between(current_cp, r1_quartile[2], r1_quartile[3])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw pivot point and the resistence price 1.")
        print("current price sits btw quartile 12.5% and 25%.")
      }
      if(between(current_cp, r1_quartile[1], r1_quartile[2])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw pivot point and the resistence price 1.")
        print("current price sits btw quartile 0% and 12.5%.")
      }
    }
    if(between(current_cp, r1, r2)){
      r1_range = seq(from = r1, to = r2, by = 0.0001)
      r1_quartile = quantile(r1_range, c(0.0,0.125, 0.25, 0.375, 0.50, 0.625, 0.75, 0.875, 1.0))
      if(between(current_cp, r1_quartile[8], r1_quartile[9])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 1 and the resistence price 2.")
        print("current price sits btw quartile 87.5% and 100%.")
      }
      if(between(current_cp, r1_quartile[7], r1_quartile[8])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw resistence price 1 and the resistence price 2.")
        print("current price sits btw quartile 75% and 87.5%.")
      }
      if(between(current_cp, r1_quartile[6], r1_quartile[7])){
        sl =  r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw resistence price 1 and the resistence price 2.")
        print("current price sits btw quartile 62.5% and 75%.")
      }
      if(between(current_cp, r1_quartile[5], r1_quartile[6])){
        sl =  r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw resistence price 1 and the resistence price 2.")
        print("current price sits btw quartile 50% and 62.5%.")
      }
      if(between(current_cp, r1_quartile[4], r1_quartile[5])){
        sl =  r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw resistence price 1 and the resistence price 2.")
        print("current price sits btw quartile 37.5% and 50%.")
      }
      if(between(current_cp, r1_quartile[3], r1_quartile[4])){
        sl =  r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw resistence price 1 and the resistence price 2.")
        print("current price sits btw quartile 25% and 37.5%.")
      }
      if(between(current_cp, r1_quartile[2], r1_quartile[3])){
        sl =  r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw resistence price 1 and the resistence price 2.")
        print("current price sits btw quartile 12.5% and 25%.")
      }
      if(between(current_cp, r1_quartile[1], r1_quartile[2])){
        sl =  r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw resistence price 1 and the resistence price 2.")
        print("current price sits btw quartile 0% and 12.5%.")
      }
    }
    if(between(current_cp, r2, r3)){
      r1_range = seq(from = r2, to = r3, by = 0.0001)
      r1_quartile = quantile(r1_range, c(0.0,0.125, 0.25, 0.375, 0.50, 0.625, 0.75, 0.875, 1.0))
      if(between(current_cp, r1_quartile[8], r1_quartile[9])){
        sl =  r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 2 and the resistence price 3.")
        print("current price sits btw quartile 87.5% and 100%.")
      }
      if(between(current_cp, r1_quartile[7], r1_quartile[8])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 2 and the resistence price 3.")
        print("current price sits btw quartile 75% and 87.5%.")
      }
      if(between(current_cp, r1_quartile[6], r1_quartile[7])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 2 and the resistence price 3.")
        print("current price sits btw quartile 62.5% and 75%.")
      }
      if(between(current_cp, r1_quartile[5], r1_quartile[6])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 2 and the resistence price 3.")
        print("current price sits btw quartile 50% and 62.5%.")
      }
      if(between(current_cp, r1_quartile[4], r1_quartile[5])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 2 and the resistence price 3.")
        print("current price sits btw quartile 37.5% and 50%.")
      }
      if(between(current_cp, r1_quartile[3], r1_quartile[4])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 2 and the resistence price 3.")
        print("current price sits btw quartile 25% and 37.5%.")
      }
      if(between(current_cp, r1_quartile[2], r1_quartile[3])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 2 and the resistence price 3.")
        print("current price sits btw quartile 12.5% and 25%.")
      }
      if(between(current_cp, r1_quartile[1], r1_quartile[2])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 2 and the resistence price 3.")
        print("current price sits btw quartile 0% and 12.5%.")
      }
    }
    if(between(current_cp, r3, r4)){
      r1_range = seq(from = r3, to = r4, by = 0.0001)
      r1_quartile = quantile(r1_range, c(0.0,0.125, 0.25, 0.375, 0.50, 0.625, 0.75, 0.875, 1.0))
      if(between(current_cp, r1_quartile[8], r1_quartile[9])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 3 and the resistence price 4.")
        print("current price sits btw quartile 87.5% and 100%.")
      }
      if(between(current_cp, r1_quartile[7], r1_quartile[8])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 3 and the resistence price 4.")
        print("current price sits btw quartile 75% and 87.5%.")
      }
      if(between(current_cp, r1_quartile[6], r1_quartile[7])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 3 and the resistence price 4.")
        print("current price sits btw quartile 62.5% and 75%.")
      }
      if(between(current_cp, r1_quartile[5], r1_quartile[6])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 3 and the resistence price 4.")
        print("current price sits btw quartile 50% and 62.5%.")
      }
      if(between(current_cp, r1_quartile[4], r1_quartile[5])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 3 and the resistence price 4.")
        print("current price sits btw quartile 37.5% and 50%.")
      }
      if(between(current_cp, r1_quartile[3], r1_quartile[4])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 3 and the resistence price 4.")
        print("current price sits btw quartile 25% and 37.5%.")
      }
      if(between(current_cp, r1_quartile[2], r1_quartile[3])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 3 and the resistence price 4.")
        print("current price sits btw quartile 12.5% and 25%.")
      }
      if(between(current_cp, r1_quartile[1], r1_quartile[2])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 3 and the resistence price 4.")
        print("current price sits btw quartile 0% and 12.5%.")
      }
    }
    if(current_cp>=r4){
      if(length(trades>=0)){
        if(trade_m15 == 1){
          trade_m15 = 0
        }
        if(trade_m15 == 4){
          trade_m15 = 0
        }
      } 
      print("current price greater than the resistence price r4.")
    }
  }
}

if(pv_med_value$x == 'medium_potential'){
  if(current_cp < pivot_point){
    if(between(current_cp, s1, pivot_point)){
      s1_range = seq(from = s1, to = pivot_point, by = 0.0001)
      s1_quartile = quantile(s1_range, c(0.0,0.125, 0.25, 0.375, 0.50, 0.625, 0.75, 0.875, 1.0))
      if(between(current_cp, s1_quartile[8], s1_quartile[9])){
        sl = s1_quartile[9]-s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 1 and pivot point.")
        print("current price sits btw quartile 87.5% and 100%.")
      }
      if(between(current_cp, s1_quartile[7], s1_quartile[8])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 1 and pivot point.")
        print("current price sits btw quartile 75% and 87.5%.")
      }
      if(between(current_cp, s1_quartile[6], s1_quartile[7])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 1 and pivot point.")
        print("current price sits btw quartile 62.5% and 75%.")
      }
      if(between(current_cp, s1_quartile[5], s1_quartile[6])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 1 and pivot point.")
        print("current price sits btw quartile 50% and 62.5%.")
      }
      if(between(current_cp, s1_quartile[4], s1_quartile[5])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 1 and pivot point.")
        print("current price sits btw quartile 37.5% and 50%.")
      }
      if(between(current_cp, s1_quartile[3], s1_quartile[4])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 1 and pivot point.")
        print("current price sits btw quartile 25% and 37.5%.")
      }
      if(between(current_cp, s1_quartile[2], s1_quartile[3])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 1 and pivot point.")
        print("current price sits btw quartile 12.5% and 25%.")
      }
      if(between(current_cp, s1_quartile[1], s1_quartile[2])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 1 and pivot point.")
        print("current price sits btw quartile 0% and 12.5%.")
      }
    }
    if(between(current_cp, s2, s1)){
      s1_range = seq(from = s2, to = s1, by = 0.0001)
      s1_quartile = quantile(s1_range, c(0.0,0.125, 0.25, 0.375, 0.50, 0.625, 0.75, 0.875, 1.0))
      if(between(current_cp, s1_quartile[8], s1_quartile[9])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 2 and support price 1.")
        print("current price sits btw quartile 87.5% and 100%.")
      }
      if(between(current_cp, s1_quartile[7], s1_quartile[8])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 2 and support price 1.")
        print("current price sits btw quartile 75% and 87.5%.")
      }
      if(between(current_cp, s1_quartile[6], s1_quartile[7])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 2 and support price 1.")
        print("current price sits btw quartile 62.5% and 75%.")
      }
      if(between(current_cp, s1_quartile[5], s1_quartile[6])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 2 and support price 1.")
        print("current price sits btw quartile 50% and 62.5%.")
      }
      if(between(current_cp, s1_quartile[4], s1_quartile[5])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 2 and support price 1.")
        print("current price sits btw quartile 37.5% and 50%.")
      }
      if(between(current_cp, s1_quartile[3], s1_quartile[4])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 2 and support price 1.")
        print("current price sits btw quartile 25% and 37.5%.")
      }
      if(between(current_cp, s1_quartile[2], s1_quartile[3])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 2 and support price 1.")
        print("current price sits btw quartile 12.5% and 25%.")
      }
      if(between(current_cp, s1_quartile[1], s1_quartile[2])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 2 and support price 1.")
        print("current price sits btw quartile 0% and 12.5%.")
      }
    }
    if(between(current_cp, s3, s2)){
      s1_range = seq(from = s3, to = s2, by = 0.0001)
      s1_quartile = quantile(s1_range, c(0.0,0.125, 0.25, 0.375, 0.50, 0.625, 0.75, 0.875, 1.0))
      if(between(current_cp, s1_quartile[8], s1_quartile[9])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 3 and support price 2.")
        print("current price sits btw quartile 87.5% and 100%.")
      }
      if(between(current_cp, s1_quartile[7], s1_quartile[8])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 3 and support price 2.")
        print("current price sits btw quartile 75% and 87.5%.")
      }
      if(between(current_cp, s1_quartile[6], s1_quartile[7])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 3 and support price 2.")
        print("current price sits btw quartile 62.5% and 75%.")
      }
      if(between(current_cp, s1_quartile[5], s1_quartile[6])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 3 and support price 2.")
        print("current price sits btw quartile 50% and 62.5%.")
      }
      if(between(current_cp, s1_quartile[4], s1_quartile[5])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 3 and support price 2.")
        print("current price sits btw quartile 37.5% and 50%.")
      }
      if(between(current_cp, s1_quartile[3], s1_quartile[4])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 3 and support price 2.")
        print("current price sits btw quartile 25% and 37.5%.")
      }
      if(between(current_cp, s1_quartile[2], s1_quartile[3])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 3 and support price 2.")
        print("current price sits btw quartile 12.5% and 25%.")
      }
      if(between(current_cp, s1_quartile[1], s1_quartile[2])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 3 and support price 2.")
        print("current price sits btw quartile 0% and 12.5%.")
      }
    }
    if(between(current_cp, s4, s3)){
      s1_range = seq(from = s4, to = s3, by = 0.0001)
      s1_quartile = quantile(s1_range, c(0.0,0.125, 0.25, 0.375, 0.50, 0.625, 0.75, 0.875, 1.0))
      if(between(current_cp, s1_quartile[8], s1_quartile[9])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 4 and support price 3.")
        print("current price sits btw quartile 87.5% and 100%.")
      }
      if(between(current_cp, s1_quartile[7], s1_quartile[8])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 4 and support price 3.")
        print("current price sits btw quartile 75% and 87.5%.")
      }
      if(between(current_cp, s1_quartile[6], s1_quartile[7])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 4 and support price 3.")
        print("current price sits btw quartile 62.5% and 75%.")
      }
      if(between(current_cp, s1_quartile[5], s1_quartile[6])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 4 and support price 3.")
        print("current price sits btw quartile 50% and 62.5%.")
      }
      if(between(current_cp, s1_quartile[4], s1_quartile[5])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 4 and support price 3.")
        print("current price sits btw quartile 37.5% and 50%.")
      }
      if(between(current_cp, s1_quartile[3], s1_quartile[4])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 4 and support price 3.")
        print("current price sits btw quartile 25% and 37.5%.")
      }
      if(between(current_cp, s1_quartile[2], s1_quartile[3])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 4 and support price 3.")
        print("current price sits btw quartile 12.5% and 25%.")
      }
      if(between(current_cp, s1_quartile[1], s1_quartile[2])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 4 and support price 3.")
        print("current price sits btw quartile 0% and 12.5%.")
      }
    }
    if(current_cp<=s4){
      if(length(trades>=0)){
        if(trade_m15 == 1){
          trade_m15 = 0
        }
        if(trade_m15 == 4){
          trade_m15 = 0
        }
      } 
      print("current price less than support price s4.")
    }
  }
  if(current_cp > pivot_point){
    if(between(current_cp, pivot_point, r1)){
      r1_range = seq(from = pivot_point, to = r1, by = 0.0001)
      r1_quartile = quantile(r1_range, c(0.0,0.125, 0.25, 0.375, 0.50, 0.625, 0.75, 0.875, 1.0))
      if(between(current_cp, r1_quartile[8], r1_quartile[9])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw pivot point and the resistence price 1.")
        print("current price sits btw quartile 87.5% and 100%.")
      }
      if(between(current_cp, r1_quartile[7], r1_quartile[8])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw pivot point and the resistence price 1.")
        print("current price sits btw quartile 75% and 87.5%.")
      }
      if(between(current_cp, r1_quartile[6], r1_quartile[7])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw pivot point and the resistence price 1.")
        print("current price sits btw quartile 62.5% and 75%.")
      }
      if(between(current_cp, r1_quartile[5], r1_quartile[6])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw pivot point and the resistence price 1.")
        print("current price sits btw quartile 50% and 62.5%.")
      }
      if(between(current_cp, r1_quartile[4], r1_quartile[5])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw pivot point and the resistence price 1.")
        print("current price sits btw quartile 37.5% and 50%.")
      }
      if(between(current_cp, r1_quartile[3], r1_quartile[4])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw pivot point and the resistence price 1.")
        print("current price sits btw quartile 25% and 37.5%.")
      }
      if(between(current_cp, r1_quartile[2], r1_quartile[3])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw pivot point and the resistence price 1.")
        print("current price sits btw quartile 12.5% and 25%.")
      }
      if(between(current_cp, r1_quartile[1], r1_quartile[2])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw pivot point and the resistence price 1.")
        print("current price sits btw quartile 0% and 12.5%.")
      }
    }
    if(between(current_cp, r1, r2)){
      r1_range = seq(from = r1, to = r2, by = 0.0001)
      r1_quartile = quantile(r1_range, c(0.0,0.125, 0.25, 0.375, 0.50, 0.625, 0.75, 0.875, 1.0))
      if(between(current_cp, r1_quartile[8], r1_quartile[9])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 1 and the resistence price 2.")
        print("current price sits btw quartile 87.5% and 100%.")
      }
      if(between(current_cp, r1_quartile[7], r1_quartile[8])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw resistence price 1 and the resistence price 2.")
        print("current price sits btw quartile 75% and 87.5%.")
      }
      if(between(current_cp, r1_quartile[6], r1_quartile[7])){
        sl =  r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw resistence price 1 and the resistence price 2.")
        print("current price sits btw quartile 62.5% and 75%.")
      }
      if(between(current_cp, r1_quartile[5], r1_quartile[6])){
        sl =  r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw resistence price 1 and the resistence price 2.")
        print("current price sits btw quartile 50% and 62.5%.")
      }
      if(between(current_cp, r1_quartile[4], r1_quartile[5])){
        sl =  r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw resistence price 1 and the resistence price 2.")
        print("current price sits btw quartile 37.5% and 50%.")
      }
      if(between(current_cp, r1_quartile[3], r1_quartile[4])){
        sl =  r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw resistence price 1 and the resistence price 2.")
        print("current price sits btw quartile 25% and 37.5%.")
      }
      if(between(current_cp, r1_quartile[2], r1_quartile[3])){
        sl =  r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw resistence price 1 and the resistence price 2.")
        print("current price sits btw quartile 12.5% and 25%.")
      }
      if(between(current_cp, r1_quartile[1], r1_quartile[2])){
        sl =  r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw resistence price 1 and the resistence price 2.")
        print("current price sits btw quartile 0% and 12.5%.")
      }
    }
    if(between(current_cp, r2, r3)){
      r1_range = seq(from = r2, to = r3, by = 0.0001)
      r1_quartile = quantile(r1_range, c(0.0,0.125, 0.25, 0.375, 0.50, 0.625, 0.75, 0.875, 1.0))
      if(between(current_cp, r1_quartile[8], r1_quartile[9])){
        sl =  r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 2 and the resistence price 3.")
        print("current price sits btw quartile 87.5% and 100%.")
      }
      if(between(current_cp, r1_quartile[7], r1_quartile[8])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 2 and the resistence price 3.")
        print("current price sits btw quartile 75% and 87.5%.")
      }
      if(between(current_cp, r1_quartile[6], r1_quartile[7])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 2 and the resistence price 3.")
        print("current price sits btw quartile 62.5% and 75%.")
      }
      if(between(current_cp, r1_quartile[5], r1_quartile[6])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 2 and the resistence price 3.")
        print("current price sits btw quartile 50% and 62.5%.")
      }
      if(between(current_cp, r1_quartile[4], r1_quartile[5])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 2 and the resistence price 3.")
        print("current price sits btw quartile 37.5% and 50%.")
      }
      if(between(current_cp, r1_quartile[3], r1_quartile[4])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 2 and the resistence price 3.")
        print("current price sits btw quartile 25% and 37.5%.")
      }
      if(between(current_cp, r1_quartile[2], r1_quartile[3])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 2 and the resistence price 3.")
        print("current price sits btw quartile 12.5% and 25%.")
      }
      if(between(current_cp, r1_quartile[1], r1_quartile[2])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 2 and the resistence price 3.")
        print("current price sits btw quartile 0% and 12.5%.")
      }
    }
    if(between(current_cp, r3, r4)){
      r1_range = seq(from = r3, to = r4, by = 0.0001)
      r1_quartile = quantile(r1_range, c(0.0,0.125, 0.25, 0.375, 0.50, 0.625, 0.75, 0.875, 1.0))
      if(between(current_cp, r1_quartile[8], r1_quartile[9])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 3 and the resistence price 4.")
        print("current price sits btw quartile 87.5% and 100%.")
      }
      if(between(current_cp, r1_quartile[7], r1_quartile[8])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 3 and the resistence price 4.")
        print("current price sits btw quartile 75% and 87.5%.")
      }
      if(between(current_cp, r1_quartile[6], r1_quartile[7])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 3 and the resistence price 4.")
        print("current price sits btw quartile 62.5% and 75%.")
      }
      if(between(current_cp, r1_quartile[5], r1_quartile[6])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 3 and the resistence price 4.")
        print("current price sits btw quartile 50% and 62.5%.")
      }
      if(between(current_cp, r1_quartile[4], r1_quartile[5])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 3 and the resistence price 4.")
        print("current price sits btw quartile 37.5% and 50%.")
      }
      if(between(current_cp, r1_quartile[3], r1_quartile[4])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 3 and the resistence price 4.")
        print("current price sits btw quartile 25% and 37.5%.")
      }
      if(between(current_cp, r1_quartile[2], r1_quartile[3])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 3 and the resistence price 4.")
        print("current price sits btw quartile 12.5% and 25%.")
      }
      if(between(current_cp, r1_quartile[1], r1_quartile[2])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 3 and the resistence price 4.")
        print("current price sits btw quartile 0% and 12.5%.")
      }
    }
    if(current_cp>=r4){
      if(length(trades>=0)){
        if(trade_m15 == 1){
          trade_m15 = 0
        }
        if(trade_m15 == 4){
          trade_m15 = 0
        }
      } 
      print("current price greater than the resistence price r4.")
    }
  }
}

if(pv_med_value$x == 'high_potential'){
  if(current_cp < pivot_point){
    if(between(current_cp, s1, pivot_point)){
      s1_range = seq(from = s1, to = pivot_point, by = 0.0001)
      s1_quartile = quantile(s1_range, c(0.0,0.125, 0.25, 0.375, 0.50, 0.625, 0.75, 0.875, 1.0))
      if(between(current_cp, s1_quartile[8], s1_quartile[9])){
        sl = s1_quartile[9]-s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 1 and pivot point.")
        print("current price sits btw quartile 87.5% and 100%.")
      }
      if(between(current_cp, s1_quartile[7], s1_quartile[8])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 1 and pivot point.")
        print("current price sits btw quartile 75% and 87.5%.")
      }
      if(between(current_cp, s1_quartile[6], s1_quartile[7])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 1 and pivot point.")
        print("current price sits btw quartile 62.5% and 75%.")
      }
      if(between(current_cp, s1_quartile[5], s1_quartile[6])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 1 and pivot point.")
        print("current price sits btw quartile 50% and 62.5%.")
      }
      if(between(current_cp, s1_quartile[4], s1_quartile[5])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 1 and pivot point.")
        print("current price sits btw quartile 37.5% and 50%.")
      }
      if(between(current_cp, s1_quartile[3], s1_quartile[4])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 1 and pivot point.")
        print("current price sits btw quartile 25% and 37.5%.")
      }
      if(between(current_cp, s1_quartile[2], s1_quartile[3])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 1 and pivot point.")
        print("current price sits btw quartile 12.5% and 25%.")
      }
      if(between(current_cp, s1_quartile[1], s1_quartile[2])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 1 and pivot point.")
        print("current price sits btw quartile 0% and 12.5%.")
      }
    }
    if(between(current_cp, s2, s1)){
      s1_range = seq(from = s2, to = s1, by = 0.0001)
      s1_quartile = quantile(s1_range, c(0.0,0.125, 0.25, 0.375, 0.50, 0.625, 0.75, 0.875, 1.0))
      if(between(current_cp, s1_quartile[8], s1_quartile[9])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 2 and support price 1.")
        print("current price sits btw quartile 87.5% and 100%.")
      }
      if(between(current_cp, s1_quartile[7], s1_quartile[8])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 2 and support price 1.")
        print("current price sits btw quartile 75% and 87.5%.")
      }
      if(between(current_cp, s1_quartile[6], s1_quartile[7])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 2 and support price 1.")
        print("current price sits btw quartile 62.5% and 75%.")
      }
      if(between(current_cp, s1_quartile[5], s1_quartile[6])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 2 and support price 1.")
        print("current price sits btw quartile 50% and 62.5%.")
      }
      if(between(current_cp, s1_quartile[4], s1_quartile[5])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 2 and support price 1.")
        print("current price sits btw quartile 37.5% and 50%.")
      }
      if(between(current_cp, s1_quartile[3], s1_quartile[4])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 2 and support price 1.")
        print("current price sits btw quartile 25% and 37.5%.")
      }
      if(between(current_cp, s1_quartile[2], s1_quartile[3])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 2 and support price 1.")
        print("current price sits btw quartile 12.5% and 25%.")
      }
      if(between(current_cp, s1_quartile[1], s1_quartile[2])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 2 and support price 1.")
        print("current price sits btw quartile 0% and 12.5%.")
      }
    }
    if(between(current_cp, s3, s2)){
      s1_range = seq(from = s3, to = s2, by = 0.0001)
      s1_quartile = quantile(s1_range, c(0.0,0.125, 0.25, 0.375, 0.50, 0.625, 0.75, 0.875, 1.0))
      if(between(current_cp, s1_quartile[8], s1_quartile[9])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 3 and support price 2.")
        print("current price sits btw quartile 87.5% and 100%.")
      }
      if(between(current_cp, s1_quartile[7], s1_quartile[8])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 3 and support price 2.")
        print("current price sits btw quartile 75% and 87.5%.")
      }
      if(between(current_cp, s1_quartile[6], s1_quartile[7])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 3 and support price 2.")
        print("current price sits btw quartile 62.5% and 75%.")
      }
      if(between(current_cp, s1_quartile[5], s1_quartile[6])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 3 and support price 2.")
        print("current price sits btw quartile 50% and 62.5%.")
      }
      if(between(current_cp, s1_quartile[4], s1_quartile[5])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 3 and support price 2.")
        print("current price sits btw quartile 37.5% and 50%.")
      }
      if(between(current_cp, s1_quartile[3], s1_quartile[4])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 3 and support price 2.")
        print("current price sits btw quartile 25% and 37.5%.")
      }
      if(between(current_cp, s1_quartile[2], s1_quartile[3])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 3 and support price 2.")
        print("current price sits btw quartile 12.5% and 25%.")
      }
      if(between(current_cp, s1_quartile[1], s1_quartile[2])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 3 and support price 2.")
        print("current price sits btw quartile 0% and 12.5%.")
      }
    }
    if(between(current_cp, s4, s3)){
      s1_range = seq(from = s4, to = s3, by = 0.0001)
      s1_quartile = quantile(s1_range, c(0.0,0.125, 0.25, 0.375, 0.50, 0.625, 0.75, 0.875, 1.0))
      if(between(current_cp, s1_quartile[8], s1_quartile[9])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 4 and support price 3.")
        print("current price sits btw quartile 87.5% and 100%.")
      }
      if(between(current_cp, s1_quartile[7], s1_quartile[8])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 4 and support price 3.")
        print("current price sits btw quartile 75% and 87.5%.")
      }
      if(between(current_cp, s1_quartile[6], s1_quartile[7])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 4 and support price 3.")
        print("current price sits btw quartile 62.5% and 75%.")
      }
      if(between(current_cp, s1_quartile[5], s1_quartile[6])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 4 and support price 3.")
        print("current price sits btw quartile 50% and 62.5%.")
      }
      if(between(current_cp, s1_quartile[4], s1_quartile[5])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 4 and support price 3.")
        print("current price sits btw quartile 37.5% and 50%.")
      }
      if(between(current_cp, s1_quartile[3], s1_quartile[4])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 4 and support price 3.")
        print("current price sits btw quartile 25% and 37.5%.")
      }
      if(between(current_cp, s1_quartile[2], s1_quartile[3])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 4 and support price 3.")
        print("current price sits btw quartile 12.5% and 25%.")
      }
      if(between(current_cp, s1_quartile[1], s1_quartile[2])){
        sl = s1_quartile[9] - s4
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw support price 4 and support price 3.")
        print("current price sits btw quartile 0% and 12.5%.")
      }
    }
    if(current_cp<=s4){
      if(length(trades>=0)){
        if(trade_m15 == 1){
          trade_m15 = 0
        }
        if(trade_m15 == 4){
          trade_m15 = 0
        }
      } 
      print("current price less than support price s4.")
    }
  }
  if(current_cp > pivot_point){
    if(between(current_cp, pivot_point, r1)){
      r1_range = seq(from = pivot_point, to = r1, by = 0.0001)
      r1_quartile = quantile(r1_range, c(0.0,0.125, 0.25, 0.375, 0.50, 0.625, 0.75, 0.875, 1.0))
      if(between(current_cp, r1_quartile[8], r1_quartile[9])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw pivot point and the resistence price 1.")
        print("current price sits btw quartile 87.5% and 100%.")
      }
      if(between(current_cp, r1_quartile[7], r1_quartile[8])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw pivot point and the resistence price 1.")
        print("current price sits btw quartile 75% and 87.5%.")
      }
      if(between(current_cp, r1_quartile[6], r1_quartile[7])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw pivot point and the resistence price 1.")
        print("current price sits btw quartile 62.5% and 75%.")
      }
      if(between(current_cp, r1_quartile[5], r1_quartile[6])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw pivot point and the resistence price 1.")
        print("current price sits btw quartile 50% and 62.5%.")
      }
      if(between(current_cp, r1_quartile[4], r1_quartile[5])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw pivot point and the resistence price 1.")
        print("current price sits btw quartile 37.5% and 50%.")
      }
      if(between(current_cp, r1_quartile[3], r1_quartile[4])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw pivot point and the resistence price 1.")
        print("current price sits btw quartile 25% and 37.5%.")
      }
      if(between(current_cp, r1_quartile[2], r1_quartile[3])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw pivot point and the resistence price 1.")
        print("current price sits btw quartile 12.5% and 25%.")
      }
      if(between(current_cp, r1_quartile[1], r1_quartile[2])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw pivot point and the resistence price 1.")
        print("current price sits btw quartile 0% and 12.5%.")
      }
    }
    if(between(current_cp, r1, r2)){
      r1_range = seq(from = r1, to = r2, by = 0.0001)
      r1_quartile = quantile(r1_range, c(0.0,0.125, 0.25, 0.375, 0.50, 0.625, 0.75, 0.875, 1.0))
      if(between(current_cp, r1_quartile[8], r1_quartile[9])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 1 and the resistence price 2.")
        print("current price sits btw quartile 87.5% and 100%.")
      }
      if(between(current_cp, r1_quartile[7], r1_quartile[8])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw resistence price 1 and the resistence price 2.")
        print("current price sits btw quartile 75% and 87.5%.")
      }
      if(between(current_cp, r1_quartile[6], r1_quartile[7])){
        sl =  r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw resistence price 1 and the resistence price 2.")
        print("current price sits btw quartile 62.5% and 75%.")
      }
      if(between(current_cp, r1_quartile[5], r1_quartile[6])){
        sl =  r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw resistence price 1 and the resistence price 2.")
        print("current price sits btw quartile 50% and 62.5%.")
      }
      if(between(current_cp, r1_quartile[4], r1_quartile[5])){
        sl =  r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw resistence price 1 and the resistence price 2.")
        print("current price sits btw quartile 37.5% and 50%.")
      }
      if(between(current_cp, r1_quartile[3], r1_quartile[4])){
        sl =  r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw resistence price 1 and the resistence price 2.")
        print("current price sits btw quartile 25% and 37.5%.")
      }
      if(between(current_cp, r1_quartile[2], r1_quartile[3])){
        sl =  r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw resistence price 1 and the resistence price 2.")
        print("current price sits btw quartile 12.5% and 25%.")
      }
      if(between(current_cp, r1_quartile[1], r1_quartile[2])){
        sl =  r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw resistence price 1 and the resistence price 2.")
        print("current price sits btw quartile 0% and 12.5%.")
      }
    }
    if(between(current_cp, r2, r3)){
      r1_range = seq(from = r2, to = r3, by = 0.0001)
      r1_quartile = quantile(r1_range, c(0.0,0.125, 0.25, 0.375, 0.50, 0.625, 0.75, 0.875, 1.0))
      if(between(current_cp, r1_quartile[8], r1_quartile[9])){
        sl =  r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 2 and the resistence price 3.")
        print("current price sits btw quartile 87.5% and 100%.")
      }
      if(between(current_cp, r1_quartile[7], r1_quartile[8])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 2 and the resistence price 3.")
        print("current price sits btw quartile 75% and 87.5%.")
      }
      if(between(current_cp, r1_quartile[6], r1_quartile[7])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 2 and the resistence price 3.")
        print("current price sits btw quartile 62.5% and 75%.")
      }
      if(between(current_cp, r1_quartile[5], r1_quartile[6])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 2 and the resistence price 3.")
        print("current price sits btw quartile 50% and 62.5%.")
      }
      if(between(current_cp, r1_quartile[4], r1_quartile[5])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 2 and the resistence price 3.")
        print("current price sits btw quartile 37.5% and 50%.")
      }
      if(between(current_cp, r1_quartile[3], r1_quartile[4])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 2 and the resistence price 3.")
        print("current price sits btw quartile 25% and 37.5%.")
      }
      if(between(current_cp, r1_quartile[2], r1_quartile[3])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 2 and the resistence price 3.")
        print("current price sits btw quartile 12.5% and 25%.")
      }
      if(between(current_cp, r1_quartile[1], r1_quartile[2])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 2 and the resistence price 3.")
        print("current price sits btw quartile 0% and 12.5%.")
      }
    }
    if(between(current_cp, r3, r4)){
      r1_range = seq(from = r3, to = r4, by = 0.0001)
      r1_quartile = quantile(r1_range, c(0.0,0.125, 0.25, 0.375, 0.50, 0.625, 0.75, 0.875, 1.0))
      if(between(current_cp, r1_quartile[8], r1_quartile[9])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 3 and the resistence price 4.")
        print("current price sits btw quartile 87.5% and 100%.")
      }
      if(between(current_cp, r1_quartile[7], r1_quartile[8])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 3 and the resistence price 4.")
        print("current price sits btw quartile 75% and 87.5%.")
      }
      if(between(current_cp, r1_quartile[6], r1_quartile[7])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 3 and the resistence price 4.")
        print("current price sits btw quartile 62.5% and 75%.")
      }
      if(between(current_cp, r1_quartile[5], r1_quartile[6])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 3 and the resistence price 4.")
        print("current price sits btw quartile 50% and 62.5%.")
      }
      if(between(current_cp, r1_quartile[4], r1_quartile[5])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 3 and the resistence price 4.")
        print("current price sits btw quartile 37.5% and 50%.")
      }
      if(between(current_cp, r1_quartile[3], r1_quartile[4])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 3 and the resistence price 4.")
        print("current price sits btw quartile 25% and 37.5%.")
      }
      if(between(current_cp, r1_quartile[2], r1_quartile[3])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 3 and the resistence price 4.")
        print("current price sits btw quartile 12.5% and 25%.")
      }
      if(between(current_cp, r1_quartile[1], r1_quartile[2])){
        sl = r4-r1_quartile[1]
        print(paste0("the range of the pivot level is ", sl))
        if(sl <= 0.00125){
          sl = 12.5
        } else {
          sl = sl*10000
        }
        print("current price btw the resistence price 3 and the resistence price 4.")
        print("current price sits btw quartile 0% and 12.5%.")
      }
    }
    if(current_cp>=r4){
      if(length(trades>=0)){
        if(trade_m15 == 1){
          trade_m15 = 0
        }
        if(trade_m15 == 4){
          trade_m15 = 0
        }
      } 
      print("current price greater than the resistence price r4.")
    }
  }
}

if(sl < 100){
  sl = 100
}