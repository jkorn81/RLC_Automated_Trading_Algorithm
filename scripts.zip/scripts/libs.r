# Libraries ----
if (!require("readr")) {
  install.packages("readr")
  library(readr)
}
if (!require("readxl")) {
  install.packages("readxl")
  library(readxl)
}
if (!require("dplyr")) {
  install.packages("dplyr")
  library(dplyr)
}
if (!require("data.table")) {
  install.packages("data.table")
  library(data.table)
}
if (!require("magrittr")) {
  install.packages("magrittr")
  library(magrittr)
}
if (!require("stringr")) {
  install.packages("stringr")
  library(stringr)
}
if (!require("stringi")) {
  install.packages("stringi")
  library(stringi)
}
if (!require("reticulate")) {
  install.packages("reticulate")
  library(reticulate)
}
if (!require("quantmod")) {
  install.packages("quantmod")
  library(quantmod)
}
if (!require("TTR")) {
  install.packages("TTR")
  library(TTR)
}
if (!require("caret")) {
  install.packages("caret")
  library(caret)
}
if (!require("openxlsx")) {
  install.packages("openxlsx")
  library(openxlsx)
}
if (!require("parallel")) {
  install.packages("parallel")
  library(parallel)
}
if (!require("doParallel")) {
  install.packages("doParallel")
  library(doParallel)
}
if (!require("bsts")) {
  install.packages("bsts")
  library(bsts)
}