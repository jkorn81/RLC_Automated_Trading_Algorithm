if(trade_m15 == 1){
  if(prev_cp < prev_bb_low & between(current_cp,bb_low,bb_mid)){
    data_entry = 1
    print("open buy, potential reversal.")
  } else if(prev_sma < current_sma & current_cp > bb_2_high){
    data_entry = 2
    print("open buy, potential double pattern in a buy zone.")
  } else {
    data_entry = 0
    print("do not open sell, price does not meet the requirements.")
  }
} else if(trade_m15 == 4){
  if(prev_cp > prev_bb_high & between(current_cp, bb_mid, bb_high)){
    data_entry = -1
    print("open sell, potential reversal.")
  } else if(prev_sma > current_sma & current_cp < bb_2_low){
    data_entry = -2
    print("open sell, potential double pattern in a sell zone.")
  } else {
    data_entry = 0
    print("do not open sell, price does not meet the requirements.")
  }
} else {
  data_entry = 0
  print("do not run band entry check, there is no trade signal to confirm.")
}