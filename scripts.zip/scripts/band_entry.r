#######################################################################################
#######################################################################################
#######################################################################################
dir = getwd()
setwd(dir)


#######################################################################################
#######################################################################################
#######################################################################################
#######################################################################################
bb_width = round(bb_high-bb_low,4)
if(bb_width > 0.0000){
  print(paste0("predicted trend direction is ", correction))
  print(paste0("predicted bar direction is ", bar_signal))
}
print(paste0("the bb_width is ", bb_width))
print(paste0("the sideways indicator is ", sidewaysB))
if(trade_m15 != 0 || trade_m15 != 98 || trade_m15 != 99){
  if(length(trades) == 0){
    if(trade_m15 == 1){
      if(correction == 1 & bar_signal == 1){
        trade_m15 = trade_m15
        trade_type = "double"
        write.csv(trade_type,"outputs/trade_type/trade_type.csv", row.names = FALSE)
        print("open buy, signals met the requirements.")
      } else {
        trade_m15 = 0
        print("do not open buy, signals do not meet the requirements.")
      }
    }
    if(trade_m15 == 4){
      if(correction == -1 & bar_signal == -1){
        trade_m15 = trade_m15
        trade_type = "double"
        write.csv(trade_type,"outputs/trade_type/trade_type.csv", row.names = FALSE)
        print("open sell, signals met the requirements.")
      } else {
        trade_m15 = 0
        print("do not open sell, signals do not meet the requirements.")
      }
    }
  }
}