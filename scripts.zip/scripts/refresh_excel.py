# Importing the pywin32 module
import win32com.client
# Opening Excel software using the win32com
File = win32com.client.Dispatch("Excel.Application")
# Optional line to show the Excel software
File.Visible = 0
############################################################################
############################################################################
File = win32com.client.Dispatch("Excel.Application")
# Optional line to show the Excel software
File.Visible = 0
# Opening your workbook
Workbook = File.Workbooks.open('C:/Users/Jonathan Korn/Desktop/rl_mps_secure/scripts/position_checks/marker_values.xlsx')
# Refeshing all the shests
Workbook.RefreshAll()
# Saving the Workbook
Workbook.Save()
# Closing the Excel File
File.Quit()
############################################################################
############################################################################
File = win32com.client.Dispatch("Excel.Application")
# Optional line to show the Excel software
File.Visible = 0
# Opening your workbook
Workbook = File.Workbooks.open('C:/Users/Jonathan Korn/Desktop/rl_mps_secure/scripts/position_checks/marker_values2.xlsx')
# Refeshing all the shests
Workbook.RefreshAll()
# Saving the Workbook
Workbook.Save()
# Closing the Excel File
File.Quit()
############################################################################
############################################################################
File = win32com.client.Dispatch("Excel.Application")
# Optional line to show the Excel software
File.Visible = 0
# Opening your workbook
Workbook = File.Workbooks.open('C:/Users/Jonathan Korn/Desktop/rl_mps_secure/scripts/position_checks/marker_values3.xlsx')
# Refeshing all the shests
Workbook.RefreshAll()
# Saving the Workbook
Workbook.Save()
# Closing the Excel File
File.Quit()
