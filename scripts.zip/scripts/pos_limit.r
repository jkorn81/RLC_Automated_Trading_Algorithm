#######################################################################################
#######################################################################################
#######################################################################################
dir = getwd()
setwd(dir)
#######################################################################################
#######################################################################################
#######################################################################################
#######################################################################################
if(length(trades)>=1){
  if(trade_m15 != 98 || trade_m15 != 99){
    if(trade_type == "reversal"){
      if(trade_m15 == 1 & last(ext,1) == 1){
        trade_m15 = 0
        print("do not open buy, an existing buy is open, check existing buy progress.")
      }
      if(trade_m15 == 4 & last(ext,1) == 4){
        trade_m15 = 0
        print("do not open sell, an existing buy is open, check existing sell progress.")
      }
    }
  }
}
if(length(trades)>=1){
  if(trade_m15 != 98 || trade_m15 != 99){
    if(trade_type == "double"){
      if(trade_m15 == 1 & last(ext,1) == 1){
        trade_m15 = 0
        print("do not open buy, an existing buy is open, check existing buy progress.")
      }
      if(trade_m15 == 4 & last(ext,1) == 4){
        trade_m15 = 0
        print("do not open sell, an existing buy is open, check existing sell progress.")
      }
    }
  }
}
if(length(trades)>=1){
  if(trade_m15 != 98 || trade_m15 != 99){
    if(trade_type == "trend"){
      if(trade_m15 == 1 & last(ext,1) == 1){
        trade_m15 = 0
        print("do not open buy, an existing buy is open, check existing buy progress.")
      }
      if(trade_m15 == 4 & last(ext,1) == 1){
        trade_m15 = 0
        print("do not open sell, an existing buy is open, check existing buy progress.")
      }
      if(trade_m15 == 4 & last(ext,1) == 4){
        trade_m15 = 0
        print("do not open sell, an existing sell is open, check existing sell progress.")
      }
      if(trade_m15 == 1 & last(ext,1) == 4){
        trade_m15 = 0
        print("do not open buy, an existing sell is open, check existing buy progress.")
      }
    }
  }
}