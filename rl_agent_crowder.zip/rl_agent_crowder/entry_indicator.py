# -*- coding: utf-8 -*-
"""
Created on Wed Aug 31 16:38:30 2022

@author: Jonathan Korn
"""

import numpy as np
import pandas as pd
import csv
import os

import warnings

warnings.filterwarnings("ignore")

os.chdir('C:/Users/Jonathan Korn/Desktop/rl_mps_secure/rl_agent_crowder')

#Import the Data...
data = pd.read_csv("./data/df_rates_p2.csv")


data['TP'] = (data['Close'] + data['Low'] + data['High'])/3
data['std'] = data['TP'].rolling(20).std(ddof=0)
data['MA-TP'] = data['TP'].rolling(20).mean()
data['BOLU'] = data['MA-TP'] + 2*data['std']
data['BOLD'] = data['MA-TP'] - 2*data['std']
data['MA-TP_2'] = data['TP'].rolling(20).mean()
data['BOLU_2'] = data['MA-TP'] + 1*data['std']
data['BOLD_2'] = data['MA-TP'] - 1*data['std']

prev_data = data.shift(1)



num_bars = len(data['Close'])
rang = range(0,num_bars)

# Reversal Buy Entry 
rev_buy_entry = []
for i in rang:
    if(prev_data['Close'][i] < prev_data['BOLD'][i] and data['BOLD'][i] < data['Close'][i] < data['MA-TP'][i]):
        rev_buy_entry.append(1)
    else: 
        rev_buy_entry.append(0)
        
# Double Buy Entry 
db_buy_entry = []
for i in rang:
    if(prev_data['MA-TP'][i] < data['MA-TP'][i] and data['Close'][i] > data['BOLU_2'][i]):
        db_buy_entry.append(1)
    else: 
        db_buy_entry.append(0)
        
#prev_cp > prev_bb_high & between(current_cp, bb_mid, bb_high)
#prev_sma > current_sma & current_cp < bb_2_low

# Reversal Sell Entry 
rev_sell_entry = []
for i in rang:
    if(prev_data['Close'][i] > prev_data['BOLU'][i] and data['MA-TP'][i] < data['Close'][i] < data['BOLU'][i]):
        rev_sell_entry.append(1)
    else: 
        rev_sell_entry.append(0)
        
# Double Sell Entry 
db_sell_entry = []
for i in rang:
    if(prev_data['MA-TP'][i] > data['MA-TP'][i] and data['Close'][i] < data['BOLD_2'][i]):
        db_sell_entry.append(1)
    else: 
        db_sell_entry.append(0)
        
data['rev_buy_entry'] = rev_buy_entry
data['rev_sell_entry'] = rev_sell_entry
data['db_buy_entry'] = db_buy_entry
data['db_sell_entry'] = db_sell_entry

# 1= Rev Buy 
# 2 = DB Buy
#-1 = Rev Sell
#-2 = DB Sell
entry_signal = []
for i in rang:
    if(data['rev_buy_entry'][i] == 1 and data['rev_sell_entry'][i] == 0 and data['db_buy_entry'][i] == 0 and data['db_sell_entry'][i] == 0):
        entry_signal.append(1)
    elif(data['rev_buy_entry'][i] == 0 and data['rev_sell_entry'][i] == 0 and data['db_buy_entry'][i] == 1 and data['db_sell_entry'][i] == 0):
        entry_signal.append(2)
    elif(data['rev_buy_entry'][i] == 0 and data['rev_sell_entry'][i] == 1 and data['db_buy_entry'][i] == 0 and data['db_sell_entry'][i] == 0):
        entry_signal.append(-1)
    elif(data['rev_buy_entry'][i] == 0 and data['rev_sell_entry'][i] == 0 and data['db_buy_entry'][i] == 0 and data['db_sell_entry'][i] == 1):
        entry_signal.append(-2)
    else:
        entry_signal.append(0)
data['entry_signal'] = entry_signal

data.to_csv('data/data.csv')
