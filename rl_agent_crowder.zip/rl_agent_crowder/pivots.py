import numpy as np
import pandas as pd
import csv
import os

os.chdir('C:/Users/Jonathan Korn/Desktop/rl_mps_secure/rl_agent_crowder')

#Import the Data...
data_ohlc = pd.read_csv("./outputs/daily.csv")

data_ohlc['Pivot'] = (data_ohlc['High'] + data_ohlc['Low'] + data_ohlc['Close'])/3
data_ohlc['R1'] = (2*data_ohlc['Pivot']) - data_ohlc['Low']
data_ohlc['S1'] = (2*data_ohlc['Pivot']) - data_ohlc['High']
data_ohlc['R2'] = (data_ohlc['Pivot']) + (data_ohlc['High'] - data_ohlc['Low'])
data_ohlc['S2'] = (data_ohlc['Pivot']) - (data_ohlc['High'] - data_ohlc['Low'])
data_ohlc['R3'] = (data_ohlc['R1']) + (data_ohlc['High'] - data_ohlc['Low'])
data_ohlc['S3'] = (data_ohlc['S1']) - (data_ohlc['High'] - data_ohlc['Low'])
data_ohlc['R4'] = (data_ohlc['R3']) + (data_ohlc['R2'] - data_ohlc['R1'])
data_ohlc['S4'] = (data_ohlc['S3']) - (data_ohlc['S1'] - data_ohlc['S2'])

data_ohlc.to_excel("./outputs/pivots/pivots.xlsx", index=False) # Export to Excel
