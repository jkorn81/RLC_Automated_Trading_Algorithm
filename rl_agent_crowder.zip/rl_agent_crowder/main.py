# Main...
import numpy as np
import pandas as pd
import os
import shutil
import matplotlib.pyplot as plt
from os import walk
import time 
import glob
import csv
import warnings

warnings.filterwarnings("ignore")

os.chdir('C:/Users/jonat/Desktop/rl_mps_secure/rl_agent_crowder')
np.random.seed(0)

# Import Data
exec(open('./scripts/import_data.py').read())
print("Data Imported...")
print(btc.shape)


print("------------------------------------------------------------------")
print("------------------------------------------------------------------")
print("------------------------------------------------------------------")
print("------------------------------------------------------------------")
print("Implementing Model...")
time.sleep(2)
print("Train/Test Split...")
train_btc = btc[0:500]
predict_btc = btc[501:600]
    
# Process Train and Predict Data
exec(open('./scripts/proc_train.py').read())
exec(open('./scripts/proc_predict.py').read())
print("Data Processed...")
print(rets_train.shape)
print(rets_predict.shape)

pc = pd.read_csv("./outputs/pc.csv")
pc = pc['x']
pc = pc[0]

mods = range(0, 10)
for x in mods:
    mod_id = str(x)
    # Load Modeling
    exec(open('./functions/functions.py').read())
    # Train Models
    exec(open('./scripts/train.model.py').read())
    # List Sharpe Ratios in order from file and load
    mypath = './train_outputs/sharpe_ratio/'
    filenames = next(walk(mypath), (None, None, []))[2]  # [] if no file
    # Load sharpe_ratios for conditional
    sharpe_check = pd.DataFrame(pd.read_csv('./train_outputs/sharpe_ratio/'+str(filenames[-1])))
    sharpe_check = sharpe_check.columns[-1]
    if(pc >= 0):
        if(float(sharpe_check)>1.0):
            exec(open('./scripts/predict.model.py').read())
        else:
            print('The Models Sharpe is not above 1.0')
    if(pc < 0):
        if(float(sharpe_check)>1.0):
            exec(open('./scripts/predict.model.py').read())
        else:
            print('The Models Sharpe is not above 1.0')

def exists(var):
     return var in globals()
x_test_status = exists("x_test")
if(x_test_status == False):
    # Shape the Data...
    x = np.array(rets_predict) #Dimensions of the Data 
    x_test = x
    std = np.std(x_test)
    mean = np.mean(x_test)
    x_test = (x_test - mean) / std #new data to capture returns on...
    #Note: In Meta Trader we will have to capture each new data point every trading period

print("------------------------------------------------------------------")
print("------------------------------------------------------------------")
print("------------------------------------------------------------------")
print("------------------------------------------------------------------")
print("Check Accepted Model Negative States...")
# List acm theta in order from file and load
mypath = './deploy_outputs/neg_theta/'
filenames = next(walk(mypath), (None, None, []))[2]  # [] if no file
len_acm = len(filenames)   
acm = list(range(0, len_acm))
for d in acm:
    if not d:
        pass
    # Load Modeling
    exec(open('./functions/functions.py').read())
    acm_id = d
    # Load acm theta for running conditional check of acm states 
    mypath = './deploy_outputs/neg_theta/'
    filenames = next(walk(mypath), (None, None, []))[2]  # [] if no file
    deploy_theta = pd.DataFrame(pd.read_csv('./deploy_outputs/neg_theta/'+str(filenames[acm_id])))
    deploy_theta = deploy_theta.columns.tolist()
    deploy_theta = [float(d) for d in deploy_theta]
    positions = positions(x_test, deploy_theta)
    returns = returns(positions, x_test, commission) #capturing the returns on new data...
    culsum_returns = returns.cumsum()
    print("Sharpe Ratio of ACM RL Model Deployed Returns", str(filenames[acm_id]), ": ",sharpe_ratio(returns))
    print("ACM RL Model Current Deployed Position", str(filenames[acm_id]), ": ",positions[-1])
    print("ACM RL Model Current Deployed Culsum Returns", str(filenames[acm_id]), ": ",culsum_returns[-1])
    if(float(culsum_returns[-1])<=0):
        mypath = './deploy_outputs/neg_theta/'
        filenames = next(walk(mypath), (None, None, []))[2]  # [] if no file
        file = str('./deploy_outputs/neg_theta/'+str(filenames[acm_id]))
        shutil.copy(file, str('./deploy_outputs/failed_neg_theta/'+str(filenames[acm_id])))
        mypath = './deploy_outputs/neg_positions/'
        filenames = next(walk(mypath), (None, None, []))[2]  # [] if no file
        file = str('./deploy_outputs/neg_positions/'+str(filenames[acm_id]))
        shutil.copy(file, str('./deploy_outputs/failed_neg_positions/'+str(filenames[acm_id])))
        print('Deployed ACM Negative State Failed')
    else: 
        print('Deployed ACM Negative State Passed')
# Remove Failed States 
mypath = './deploy_outputs/failed_neg_theta/'
filenames = next(walk(mypath), (None, None, []))[2]  # [] if no file
len_acm = len(filenames)   
acm = range(0, len_acm)
for d in acm:
    acm_id = d
    file = str('./deploy_outputs/neg_theta/'+str(filenames[acm_id]))
    os.remove(file)
mypath = './deploy_outputs/failed_neg_positions/'
filenames = next(walk(mypath), (None, None, []))[2]  # [] if no file
len_acm = len(filenames)   
acm = range(0, len_acm)
for d in acm:
    acm_id = d
    file = str('./deploy_outputs/neg_positions/'+str(filenames[acm_id]))
    os.remove(file)
print("------------------------------------------------------------------")
print("------------------------------------------------------------------")
print("------------------------------------------------------------------")
print("------------------------------------------------------------------")
print("Check Accepted Model Positive States...")
# List acm theta in order from file and load
mypath = './deploy_outputs/pos_theta/'
filenames = next(walk(mypath), (None, None, []))[2]  # [] if no file
len_acm = len(filenames)   
acm = list(range(0, len_acm))
for d in acm:
    if not d:
        pass
    # Load Modeling
    exec(open('./functions/functions.py').read())
    acm_id = d
    # Load acm theta for running conditional check of acm states 
    mypath = './deploy_outputs/pos_theta/'
    filenames = next(walk(mypath), (None, None, []))[2]  # [] if no file
    deploy_theta = pd.DataFrame(pd.read_csv('./deploy_outputs/pos_theta/'+str(filenames[acm_id])))
    deploy_theta = deploy_theta.columns.tolist()
    deploy_theta = [float(d) for d in deploy_theta]
    positions = positions(x_test, deploy_theta)
    returns = returns(positions, x_test, commission) #capturing the returns on new data...
    culsum_returns = returns.cumsum()
    print("Sharpe Ratio of ACM RL Model Deployed Returns", str(filenames[acm_id]), ": ",sharpe_ratio(returns))
    print("ACM RL Model Current Deployed Position", str(filenames[acm_id]), ": ",positions[-1])
    print("ACM RL Model Current Deployed Culsum Returns", str(filenames[acm_id]), ": ",culsum_returns[-1])
    if(float(culsum_returns[-1])<=0):
        mypath = './deploy_outputs/pos_theta/'
        filenames = next(walk(mypath), (None, None, []))[2]  # [] if no file
        file = str('./deploy_outputs/pos_theta/'+str(filenames[acm_id]))
        shutil.copy(file, str('./deploy_outputs/failed_pos_theta/'+str(filenames[acm_id])))
        mypath = './deploy_outputs/pos_positions/'
        filenames = next(walk(mypath), (None, None, []))[2]  # [] if no file
        file = str('./deploy_outputs/pos_positions/'+str(filenames[acm_id]))
        shutil.copy(file, str('./deploy_outputs/failed_pos_positions/'+str(filenames[acm_id])))
        print('Deployed ACM Positive State Failed')
    else: 
        print('Deployed ACM Positive State Passed')
# Remove Failed States 
mypath = './deploy_outputs/failed_pos_theta/'
filenames = next(walk(mypath), (None, None, []))[2]  # [] if no file
len_acm = len(filenames)   
acm = range(0, len_acm)
for d in acm:
    acm_id = d
    file = str('./deploy_outputs/pos_theta/'+str(filenames[acm_id]))
    os.remove(file)
mypath = './deploy_outputs/failed_pos_positions/'
filenames = next(walk(mypath), (None, None, []))[2]  # [] if no file
len_acm = len(filenames)   
acm = range(0, len_acm)
for d in acm:
    acm_id = d
    file = str('./deploy_outputs/pos_positions/'+str(filenames[acm_id]))
    os.remove(file)
print("------------------------------------------------------------------")
print("------------------------------------------------------------------")
print("------------------------------------------------------------------")
print("------------------------------------------------------------------")
# Calculate the Number of Models, Avg Signal, Number of Buys/Sells in csv (overwrite file each time)
# use glob to get all the csv files 
# in the folder
print('Save Position Files')
path = './deploy_outputs/neg_positions/'
filenames = glob.glob(path + "/*.csv")

dfs = []
for filename in filenames:
    dfs.append(pd.read_csv(filename))

path = './deploy_outputs/pos_positions/'
filenames = glob.glob(path + "/*.csv")

for filename in filenames:
    dfs.append(pd.read_csv(filename))

# Concatenate all data into one DataFrame
pos_even = pd.DataFrame([0])
pos_minus = pd.DataFrame([0])
if(len(dfs) > 0):
    pos_frame = pd.concat(dfs, ignore_index=True)
    pos_list = pos_frame.columns
    pos_list = [i for i in pos_list if i != '0']
    pos_list = list(map(float, pos_list))
    pos_even = pd.DataFrame([i for i in pos_list if i > 0])
    pos_even.to_csv('./deploy_outputs/pos_positive'+'.csv')
    pos_minus = pd.DataFrame([i for i in pos_list if i < 0])
    pos_minus.to_csv('./deploy_outputs/pos_negative'+'.csv')
else:
    pos_even = pd.DataFrame([0])
    pos_even.to_csv('./deploy_outputs/pos_positive'+'.csv')
    pos_neg = pd.DataFrame([0])
    pos_minus.to_csv('./deploy_outputs/pos_negative'+'.csv')
print("------------------------------------------------------------------")
print("------------------------------------------------------------------")
print("------------------------------------------------------------------")
print("------------------------------------------------------------------")
