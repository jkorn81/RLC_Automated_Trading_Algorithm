#Technique 1: Using mean to impute the missing values
missing_col = ['Close']
for i in missing_col:
 train_btc.loc[train_btc.loc[:,i].isnull(),i]=train_btc.loc[:,i].mean()
# Use median to impute outlier values
median = float(train_btc['Close'].median())
train_btc['Close'] = np.where(train_btc['Close'] > median, median, train_btc['Close'])
# Scale the values 
column = 'Close'
train_btc[column] = (train_btc[column] - train_btc[column].mean()) / train_btc[column].std()   

#Technique 1: Using mean to impute the missing values
missing_col = ['Open']
for i in missing_col:
 train_btc.loc[train_btc.loc[:,i].isnull(),i]=train_btc.loc[:,i].mean()
 # Use median to impute outlier values
median = float(train_btc['Open'].median())
train_btc['Open'] = np.where(train_btc['Open'] > median, median, train_btc['Close'])
# Scale the values 
column = 'Open'
train_btc[column] = (train_btc[column] - train_btc[column].mean()) / train_btc[column].std() 

# Remove Varibles and Prepare Series  
train_btc["date"] = train_btc["Date"].astype(str)
train_btc['date'] = train_btc['date'].astype('datetime64[ns]')
train_btc = train_btc.drop('Date', 1)
train_btc = train_btc.drop('High',1)
train_btc = train_btc.drop('Low',1)
train_btc = train_btc.set_index('date')
train_btc.index = pd.to_datetime(train_btc.index, unit='s')
train_btc = train_btc.shift(periods=1)
train_btc = train_btc[1:]
rets_train = train_btc['Close']- train_btc['Open']

