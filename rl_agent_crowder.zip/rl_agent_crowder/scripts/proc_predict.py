#Technique 1: Using mean to impute the missing values
missing_col = ['Close']
for i in missing_col:
 predict_btc.loc[predict_btc.loc[:,i].isnull(),i]=predict_btc.loc[:,i].mean()
# Use median to impute outlier values
median = float(predict_btc['Close'].median())
predict_btc['Close'] = np.where(predict_btc['Close'] > median, median, predict_btc['Close'])
# Scale the values 
column = 'Close'
predict_btc[column] = (predict_btc[column] - predict_btc[column].mean()) / predict_btc[column].std()  

#Technique 1: Using mean to impute the missing values
missing_col = ['Open']
for i in missing_col:
 predict_btc.loc[predict_btc.loc[:,i].isnull(),i]=predict_btc.loc[:,i].mean()
#Technique 1: Using mean to impute the missing values
median = float(predict_btc['Open'].median())
predict_btc['Open'] = np.where(predict_btc['Open'] > median, median, predict_btc['Close'])
# Scale the values 
column = 'Open'
predict_btc[column] = (predict_btc[column] - predict_btc[column].mean()) / predict_btc[column].std() 

# Remove Varibles and Prepare Series  
predict_btc["date"] = predict_btc["Date"].astype(str) 
predict_btc['date'] = predict_btc['date'].astype('datetime64[ns]')
predict_btc = predict_btc.drop('Date', 1)
predict_btc = predict_btc.drop('High',1)
predict_btc = predict_btc.drop('Low',1)
predict_btc = predict_btc.set_index('date')
predict_btc.index = pd.to_datetime(predict_btc.index, unit='s')
rets_predict = predict_btc['Close']-predict_btc['Open']

