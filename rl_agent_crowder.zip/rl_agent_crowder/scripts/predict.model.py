import numpy as np
import pandas as pd
from random import randint
import csv
import os
import datetime
import string
from os import walk

os.chdir('C:/Users/jonat/Desktop/rl_mps_secure/rl_agent_crowder')
np.random.seed(0)
exec(open('./functions/functions.py').read())

print("Predicting w/ Trained RL Model...")

# Date 
ldate = str(rets_predict.index[-1])
ldate = ldate.replace(":", "-")
ldate = ldate.replace(" ", "")

# Shape the Data...
x = np.array(rets_predict) #Dimensions of the Data 
x_test = x
std = np.std(x_test)
mean = np.mean(x_test)
x_test = (x_test - mean) / std #new data to capture returns on...
#Note: In Meta Trader we will have to capture each new data point every trading period to predict on... 
print("New Data Shaped")
print(x_test.shape)

#Capture the Position Prediction...
mypath = './train_outputs/theta/'
filenames = next(walk(mypath), (None, None, []))[2]  # [] if no file  
predict_theta = pd.DataFrame(pd.read_csv('./train_outputs/theta/'+str(filenames[-1])))
predict_theta = predict_theta.columns.tolist()
predict_theta = [float(x) for x in predict_theta]
positions = positions(x_test, predict_theta)
pos_ratio = [0,positions[-1]]
dt = str(datetime.datetime.now())
dt = dt.replace(":", "_")
dt = dt.replace(" ", "_")
dt = dt.replace("-", "_")
dt = dt.replace(".", "_")
f = open('./train_outputs/pos_ratio/pos_ratio'+dt+'_'+'_'+mod_id+'.csv', 'w')
# create the csv writer
writer = csv.writer(f)
# write a row to the csv file
writer.writerow(pos_ratio)
# close the file
f.close()
returns = returns(positions, x_test, commission) #capturing the returns on new data...
culsum_returns = returns.cumsum()
print("Sharpe Ratio of RL Models Predicted Returns: ",sharpe_ratio(returns))
print("RL Models Current Predicted Position: ",positions[-1])
print("RL Models Current Predicted Culsum Returns: ",culsum_returns[-1])
if(float(culsum_returns[-1])>=0 and positions[-1]<0):
    print('Predicted Culsum of Returns > 1 and Negtive State')
    f = open('./deploy_outputs/neg_theta/theta'+dt+'_'+'_'+mod_id+'_'+ldate+'.csv', 'w')
    # create the csv writer
    writer = csv.writer(f)
    # write a row to the csv file
    writer.writerow(train_theta)
    # close the file
    f.close()
    f = open('./deploy_outputs/neg_positions/positions'+dt+'_'+'_'+mod_id+'_'+ldate+'.csv', 'w')
    # create the csv writer
    writer = csv.writer(f)
    # write a row to the csv file
    writer.writerow(pos_ratio)
    # close the file
    f.close()
elif(float(culsum_returns[-1])<0 and positions[-1]<0): 
    print('Predicted Culsum of Returns < 1 and Negative Position State')
elif(float(culsum_returns[-1])>=0 and positions[-1]>0):
    print('Predicted Culsum of Returns > 1 and Positive State')
    f = open('./deploy_outputs/pos_theta/theta'+dt+'_'+'_'+mod_id+'_'+ldate+'.csv', 'w')
    # create the csv writer
    writer = csv.writer(f)
    # write a row to the csv file
    writer.writerow(train_theta)
    # close the file
    f.close()
    f = open('./deploy_outputs/pos_positions/positions'+dt+'_'+'_'+mod_id+'_'+ldate+'.csv', 'w')
    # create the csv writer
    writer = csv.writer(f)
    # write a row to the csv file
    writer.writerow(pos_ratio)
    # close the file
    f.close()
elif(float(culsum_returns[-1])<0 and positions[-1]>0): 
    print('Predicted Culsum of Returns < 1 and Positive Position State')
