import numpy as np
import pandas as pd
import csv
import os

os.chdir('C:/Users/jonat/Desktop/rl_mps_secure/rl_agent_crowder')

#Import the Data...
btc = pd.read_csv("./data/df_rates_p2.csv")
