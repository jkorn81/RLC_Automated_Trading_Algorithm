import numpy as np
import pandas as pd
import random
from random import randint
from random import randrange
import csv
import os
import datetime
import string

os.chdir('C:/Users/jonat/Desktop/rl_mps_secure/rl_agent_crowder')
np.random.seed(0)
exec(open('./functions/functions.py').read())
print("------------------------------------------------------------------")
print("------------------------------------------------------------------")
print("Training a RL Model_"+mod_id)

# Shape the Data...
x = np.array(rets_train) #Dimensions of the Data 
x_train = x
std = np.std(x_train)
mean = np.mean(x_train)
x_train = (x_train - mean) / std #data to train on (history)...
#Note: In Meta Trader we will have to capture each new data point every trading period to predict on... 
print("Data Shaped")
print(x_train.shape)

#Train a Model...
epochs = randint(10,1500)
M = randint(10,50)
#commission=float(random.randrange(1, 10))/10000
commission=0.0025
learning_rate=float(random.randrange(1, 3000))/10000
print("Model Training Parameters: ","epochs=",epochs,"M=",M,"commission=",commission,"learning_rate=",learning_rate)
train_theta, sharpes = train(x_train, epochs=epochs, M=M, 
                 commission=commission, learning_rate=learning_rate) #training the model...
#Note: In Meta Trader we will have to update the RL Model every number of periods...
#Save the Data...
# open the file in the write mode
sharpe_ratio = [0,sharpes[-1]]
dt = str(datetime.datetime.now())
dt = dt.replace(":", "_")
dt = dt.replace(" ", "_")
dt = dt.replace("-", "_")
dt = dt.replace(".", "_")
f = open('./train_outputs/sharpe_ratio/sharpe_ratio'+dt+'_'+'_'+mod_id+'.csv', 'w')
# create the csv writer
writer = csv.writer(f)
# write a row to the csv file
writer.writerow(sharpe_ratio)
# close the file
f.close()
f = open('./train_outputs/theta/theta'+dt+'_'+'_'+mod_id+'.csv', 'w')
# create the csv writer
writer = csv.writer(f)
# write a row to the csv file
writer.writerow(train_theta)
# close the file
f.close()
print("RL Model Trained Sharpe Ratio: ",sharpes[-1])
print("------------------------------------------------------------------")
print("------------------------------------------------------------------")
